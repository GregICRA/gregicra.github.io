#!/usr/bin/env python3
"""Queue-based parallel Bench2Drive evaluation.

Shared route queue plus a fixed pool of GPU "slots"; each slot pulls the next route and runs
it via run_single_route.sh. A route is only accepted as final if leaderboard_evaluator.py
actually evaluated the driving (a driving-criterion status); other failures (agent setup,
simulation crash, invalid sensors, agent crash, timeout, missing record) are requeued up to
--max-retries. Slots sharing a GPU also share --gpu-rank, so leaderboard_evaluator.py's
crash-cleanup kill can take down a sibling slot's healthy process; that shows up as another
infra failure and is retried the same way.
"""
import argparse
import json
import os
import queue
import signal
import subprocess
import sys
import threading
import time
import xml.etree.ElementTree as ET
from dataclasses import dataclass

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
TEAM_AGENT_DIR = os.path.dirname(SCRIPT_DIR)
RUN_SCRIPT = os.path.join(SCRIPT_DIR, "run_single_route.sh")
DEFAULT_ROUTES_FILE = None  # resolved inside run_single_route.sh (dev10 set) unless overridden

# Non-driving failure-status substrings from statistics_manager.FAILURE_MESSAGES, as opposed
# to a driving-criterion outcome (Perfect / Completed / Failed - <criterion>).
INFRA_FAILURE_MARKERS = (
    "Agent couldn't be set up",   # Agent_init: exception during agent.setup() (e.g. bad ckpt path, OOM)
    "Simulation crashed",         # Simulation: CARLA/scenario runner itself died
    "Agent's sensors were invalid",  # Sensors: SensorConfigurationInvalid
    "Agent crashed",              # Agent_runtime: AgentError raised during run_step
)


def log(msg):
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


# Registry of in-flight subprocess groups so Ctrl-C / SIGTERM tears all of them down instead of
# killing only this process and orphaning the CARLA / leaderboard_evaluator children.
_active_pgids = set()
_active_pgids_lock = threading.Lock()
abort_event = threading.Event()


def _signal_handler(signum, frame):
    abort_event.set()
    with _active_pgids_lock:
        pgids = list(_active_pgids)
    for pgid in pgids:
        try:
            os.killpg(pgid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    log(f"Received signal {signum}: killed {len(pgids)} in-flight process group(s), shutting down.")


signal.signal(signal.SIGINT, _signal_handler)
signal.signal(signal.SIGTERM, _signal_handler)


def parse_route_ids(routes_file):
    tree = ET.parse(routes_file)
    return [r.attrib["id"] for r in tree.getroot().findall("route")]


DEFAULT_GPU_ADAPTER_MAP = {1: 3}


def parse_adapter_map(spec):
    """'1:3,4:6' -> {1: 3, 4: 6}. GPUs not listed default to an identity mapping (adapter == gpu)."""
    m = {}
    for pair in (spec or "").split(","):
        pair = pair.strip()
        if not pair:
            continue
        g, a = pair.split(":")
        m[int(g)] = int(a)
    return m


@dataclass
class Slot:
    name: str
    gpu: int
    adapter: int
    port: int
    tm_port: int


def build_slots(gpu_ids, slots_per_gpu, adapter_map):
    slots = []
    i = 0
    for gpu in gpu_ids:
        for j in range(slots_per_gpu):
            slots.append(Slot(
                name=f"gpu{gpu}-{j}",
                gpu=gpu,
                adapter=adapter_map.get(gpu, gpu),
                port=30100 + i * 20,
                tm_port=50100 + i * 20,
            ))
            i += 1
    return slots


def detect_gpu_ids():
    out = subprocess.run(["nvidia-smi", "-L"], capture_output=True, text=True, timeout=10)
    n = len([l for l in out.stdout.splitlines() if l.strip()])
    if n == 0:
        raise RuntimeError("nvidia-smi reported 0 GPUs; pass --gpus explicitly")
    return list(range(n))


def graceful_kill(proc):
    try:
        pgid = os.getpgid(proc.pid)
    except ProcessLookupError:
        return
    try:
        os.killpg(pgid, signal.SIGINT)
    except ProcessLookupError:
        return
    try:
        proc.wait(timeout=25)
        return
    except subprocess.TimeoutExpired:
        pass
    try:
        os.killpg(pgid, signal.SIGKILL)
    except ProcessLookupError:
        pass


def cleanup_port(port):
    try:
        out = subprocess.run(["lsof", "-ti", f":{port}"], capture_output=True, text=True, timeout=10)
    except Exception:
        return
    pids = [p for p in out.stdout.split() if p.strip()]
    for pid in pids:
        subprocess.run(["kill", "-9", pid], capture_output=True)
    time.sleep(1)
    for pid in pids:
        alive = subprocess.run(["ps", "-p", pid], capture_output=True).returncode == 0
        if alive:
            log(f"WARNING: pid {pid} still bound to port {port} after kill -9")


def run_attempt(slot, route_id, attempt, checkpoint_path, run_name, timeout_s, routes_file,
                 blackout="none"):
    env = os.environ.copy()
    env.update({
        "EVAL_ROUTE_ID": str(route_id),
        "EVAL_PORT": str(slot.port),
        "EVAL_TM_PORT": str(slot.tm_port),
        "EVAL_GPU": str(slot.gpu),
        "EVAL_ADAPTER": str(slot.adapter),
        "EVAL_CHECKPOINT": checkpoint_path,
        "EVAL_RUN_NAME": run_name,
    })
    if routes_file:
        env["EVAL_ROUTES_FILE"] = routes_file
    if blackout != "none":
        env["GREG_BLACKOUT_LEVEL"] = blackout

    log_path = checkpoint_path + ".log"
    with open(log_path, "wb") as logf:
        proc = subprocess.Popen(
            ["bash", RUN_SCRIPT], env=env, stdout=logf, stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        pgid = os.getpgid(proc.pid)
        with _active_pgids_lock:
            _active_pgids.add(pgid)
        timed_out = False
        try:
            ret = proc.wait(timeout=timeout_s)
        except subprocess.TimeoutExpired:
            timed_out = True
            graceful_kill(proc)
            ret = proc.wait()
        finally:
            with _active_pgids_lock:
                _active_pgids.discard(pgid)
    cleanup_port(slot.port)
    return ret, timed_out, log_path


def classify_attempt(checkpoint_path, timed_out, returncode):
    if os.path.exists(checkpoint_path):
        records = None
        try:
            with open(checkpoint_path) as f:
                data = json.load(f)
            records = data.get("_checkpoint", {}).get("records", [])
        except Exception:
            pass
        if records:
            rec = records[0]
            status = rec.get("status", "")
            for marker in INFRA_FAILURE_MARKERS:
                if marker in status:
                    return "infra", status, rec
            return "final", status, rec
    if timed_out:
        return "infra", f"timeout (exit {returncode})", None
    if not os.path.exists(checkpoint_path):
        return "infra", f"no_checkpoint_written (exit {returncode})", None
    return "infra", f"no_route_record (exit {returncode})", None


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--routes-file", default=None,
                     help="Routes XML (default: Bench2Drive dev10 set, resolved by run_single_route.sh)")
    ap.add_argument("--route-ids", default=None,
                     help="Comma-separated route ids to run instead of every route in --routes-file")
    ap.add_argument("--gpus", default=None, help="Comma-separated physical GPU indices (default: all detected)")
    ap.add_argument("--slots-per-gpu", type=int, default=2, help="Concurrent processes per GPU (default: 2)")
    ap.add_argument("--gpu-adapter-map", default=None,
                     help="Override physical-GPU-to-Vulkan-adapter mapping, e.g. '1:3,4:6' "
                          f"(default: {DEFAULT_GPU_ADAPTER_MAP}, see DEFAULT_GPU_ADAPTER_MAP comment)")
    ap.add_argument("--max-retries", type=int, default=3,
                     help="Max attempts per route before giving up as infra_failure_exhausted (default: 3)")
    ap.add_argument("--timeout", type=int, default=1800,
                     help="Per-attempt wall-clock timeout, seconds (default: 1800). Under 2-per-GPU "
                          "contention a route can legitimately take ~20min; classify_attempt() still "
                          "recovers a valid result even if this fires right as one finishes, but a "
                          "timeout that's comfortably longer than a real run avoids the wasted retry.")
    ap.add_argument("--out-dir", default=None, help="Output dir (default: team_agent/eval_results/<timestamp>)")
    ap.add_argument("--blackout", choices=["none", "low", "high"], default="none",
                     help="Camera corruption severity applied to every route in this run via "
                          "BlackOut (none=off/default, low/high=corruption presets). Each "
                          "route gets a random-but-fixed corruption family, chosen deterministically "
                          "from its route id -- see BlackOut/family_select.py.")
    args = ap.parse_args()

    gpu_ids = [int(g) for g in args.gpus.split(",")] if args.gpus else detect_gpu_ids()
    adapter_map = parse_adapter_map(args.gpu_adapter_map) if args.gpu_adapter_map else DEFAULT_GPU_ADAPTER_MAP
    slots = build_slots(gpu_ids, args.slots_per_gpu, adapter_map)

    if args.route_ids:
        route_ids = [r.strip() for r in args.route_ids.split(",") if r.strip()]
    else:
        routes_file = args.routes_file or os.path.join(
            os.environ.get("B2D_ROOT", ""), "leaderboard/data/drivetransformer_bench2drive_dev10.xml")
        if not args.routes_file:
            # Same default resolution as run_single_route.sh; need B2D_ROOT from team_agent/.env
            # if it's not already exported in this shell.
            env_path = os.path.join(TEAM_AGENT_DIR, ".env")
            b2d_root = os.environ.get("B2D_ROOT")
            if not b2d_root and os.path.exists(env_path):
                for line in open(env_path):
                    if line.startswith("B2D_ROOT="):
                        b2d_root = line.strip().split("=", 1)[1]
            if not b2d_root:
                sys.exit("Could not resolve B2D_ROOT to find the default routes file; pass --routes-file")
            routes_file = os.path.join(b2d_root, "leaderboard/data/drivetransformer_bench2drive_dev10.xml")
        route_ids = parse_route_ids(routes_file)

    ts = time.strftime("%Y%m%d_%H%M%S")
    out_dir = args.out_dir or os.path.join(TEAM_AGENT_DIR, "eval_results", ts)
    attempts_dir = os.path.join(out_dir, "attempts")
    os.makedirs(attempts_dir, exist_ok=True)

    log(f"GPUs: {gpu_ids}  slots/gpu: {args.slots_per_gpu}  total slots: {len(slots)}")
    log(f"GPU->adapter map (identity unless listed): {adapter_map}")
    log(f"Routes to evaluate: {len(route_ids)} -> {route_ids}")
    log(f"Max retries/route: {args.max_retries}  per-attempt timeout: {args.timeout}s")
    log(f"Blackout: {args.blackout}")
    log(f"Output dir: {out_dir}")

    work_q = queue.Queue()
    for rid in route_ids:
        work_q.put(rid)

    attempts_used = {rid: 0 for rid in route_ids}
    attempts_lock = threading.Lock()
    results = {}
    results_lock = threading.Lock()
    print_lock = threading.Lock()

    def worker(slot):
        while True:
            if abort_event.is_set():
                return
            try:
                route_id = work_q.get_nowait()
            except queue.Empty:
                return
            with attempts_lock:
                attempts_used[route_id] += 1
                attempt = attempts_used[route_id]

            run_name = f"queue_r{route_id}_a{attempt}_{ts}_{slot.name}"
            ckpt_path = os.path.join(attempts_dir, f"r{route_id}_a{attempt}.json")
            with print_lock:
                log(f"[{slot.name}] route {route_id} attempt {attempt}/{args.max_retries} starting "
                    f"(gpu={slot.gpu} port={slot.port})")

            t0 = time.time()
            ret, timed_out, log_path = run_attempt(
                slot, route_id, attempt, ckpt_path, run_name, args.timeout, args.routes_file,
                blackout=args.blackout)
            dt = time.time() - t0

            if abort_event.is_set():
                # Interrupted mid-attempt: don't classify/requeue/record -- just stop. The route
                # stays unresolved in `results` (reported as INTERRUPTED in the final summary).
                work_q.task_done()
                return

            category, detail, rec = classify_attempt(ckpt_path, timed_out, ret)

            if category == "infra":
                with print_lock:
                    log(f"[{slot.name}] route {route_id} attempt {attempt} INFRA FAILURE "
                        f"({detail}, {dt:.0f}s) -- log: {log_path}")
                if attempt >= args.max_retries:
                    with print_lock:
                        log(f"[{slot.name}] route {route_id} EXHAUSTED {args.max_retries} retries, "
                            f"giving up (last: {detail})")
                    with results_lock:
                        results[route_id] = {
                            "route_id": route_id, "final_category": "infra_failure_exhausted",
                            "attempts": attempt, "last_detail": detail, "record": rec,
                        }
                else:
                    work_q.put(route_id)
            else:
                score = (rec or {}).get("scores", {}).get("score_composed")
                with print_lock:
                    log(f"[{slot.name}] route {route_id} DONE status='{detail}' score={score} "
                        f"({dt:.0f}s, attempt {attempt})")
                with results_lock:
                    results[route_id] = {
                        "route_id": route_id, "final_category": "evaluated",
                        "attempts": attempt, "status": detail, "record": rec,
                    }
            work_q.task_done()

    threads = [threading.Thread(target=worker, args=(s,), name=s.name) for s in slots]
    t_start = time.time()
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    total_dt = time.time() - t_start

    evaluated = [r for r in results.values() if r["final_category"] == "evaluated"]
    exhausted = [r for r in results.values() if r["final_category"] == "infra_failure_exhausted"]
    scores = [r["record"]["scores"]["score_composed"] for r in evaluated if r.get("record")]
    total_attempts = sum(r["attempts"] for r in results.values())

    summary = {
        "routes_requested": len(route_ids),
        "evaluated": len(evaluated),
        "infra_failure_exhausted": len(exhausted),
        "total_attempts": total_attempts,
        "retries_used": total_attempts - len(route_ids),
        "wall_clock_seconds": round(total_dt, 1),
        "mean_score_composed": round(sum(scores) / len(scores), 3) if scores else None,
        "results": results,
    }
    with open(os.path.join(out_dir, "summary.json"), "w") as f:
        json.dump(summary, f, indent=2)

    log("=" * 70)
    log(f"Done in {total_dt:.0f}s. {len(evaluated)}/{len(route_ids)} evaluated, "
        f"{len(exhausted)} gave up after infra failures, {summary['retries_used']} total retries used.")
    for rid in route_ids:
        r = results.get(rid)
        if not r:
            log(f"  route {rid}: {'INTERRUPTED' if abort_event.is_set() else 'MISSING (bug -- never processed)'}")
        elif r["final_category"] == "evaluated":
            sc = (r["record"] or {}).get("scores", {}).get("score_composed")
            log(f"  route {rid}: {r['status']:<45} score={sc} (attempts={r['attempts']})")
        else:
            log(f"  route {rid}: INFRA_FAILURE_EXHAUSTED last='{r['last_detail']}' (attempts={r['attempts']})")
    log(f"Summary written to {os.path.join(out_dir, 'summary.json')}")

    sys.exit(1 if exhausted else 0)


if __name__ == "__main__":
    main()

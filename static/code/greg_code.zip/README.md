# GREG

Imitation learning (IL) and reinforcement learning (RL) policy training setup for CARLA
autonomous driving.

## Layout

| Directory | What it is |
| --- | --- |
| `Greg_IL/` | Imitation pre-training of the policy |
| `Greg_RL/GREG_RL_Trainer/` | Centralized RL learner, replay buffer, data server |
| `Greg_RL/GREG_RL_worker/` | Rollout workers driving CARLA |
| `team_agent/` | Evaluation agent and route runners |
| `Agile/` | Adversarial scenario benchmark harness |
| `BlackOut/` | Camera-corruption robustness benchmark |
| `HugSim/` | Zero-shot HugSim evaluation |
| `tools/` | Dataset generation and benchmark scripts |

## Configuration

**No path, host, or account is hard-coded anywhere in this repo.** Every machine-specific
value is read from the environment, so a fresh checkout runs without editing source files.

Start from the example files:

```bash
cp .env.example .env                                   # shared paths
cp Greg_RL/GREG_RL_Trainer/.env.example Greg_RL/GREG_RL_Trainer/.env
cp Greg_RL/GREG_RL_worker/.env.example  Greg_RL/GREG_RL_worker/.env
cp team_agent/.env.example team_agent/.env
cp Agile/.env.example      Agile/.env                  # only if running the benchmark
cp HugSim/.env.example     HugSim/.env                 # only if running HugSim
```

Then fill each in. Python entry points load their nearest `.env` via `python-dotenv`;
shell scripts source theirs. A variable written as `${VAR:?...}` in a script is required,
and the script exits with that message if it is unset.

Note that `load_dotenv()` stops at the **nearest** `.env` rather than merging upward, which
is why a few values (`HF_TOKEN`, `CARLA_ROOT`) are repeated across files.

## Requirements

Two conda environments, one for imitation pre-training and one for everything that talks to a
simulator:

```bash
conda env create -f Greg_IL/env.yml     # greg_il -- Greg_IL/ only
conda env create -f Greg_RL/env.yml     # greg_rl -- RL trainer/worker, team_agent, HugSim, Agile
```

Both pin CUDA 12.1 builds of `torch`; on a different CUDA version install the matching wheels
from the PyTorch index after creating the environment.

CARLA, the Bench2Drive datasets, and the HugSim server are external and not vendored here;
point the variables above at your own copies.

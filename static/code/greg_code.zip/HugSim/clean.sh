#!/bin/bash
# Based on clean.sh from the upstream HugSim setup (see HugSim/README.md).
# Kills/removes docker containers and frees ports left by a previous run_test.sh invocation.
set -e

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
set -a
[ -f "${REPO_ROOT}/.env" ] && source "${REPO_ROOT}/.env"
set +a
sudo_run() { echo "${localmachinePass:-}" | sudo -S "$@"; }

NAME_PREFIX="hugsim_server_greg"
GPUS_CSV="0"
BASE_PORT="8065"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --gpus) GPUS_CSV="${2:?}"; shift 2 ;;
    --base-port) BASE_PORT="${2:?}"; shift 2 ;;
    --name-prefix) NAME_PREFIX="${2:?}"; shift 2 ;;
    --save-output|--no-save-output|--wait) shift 2 ;;
    *) echo "Unknown arg: $1" >&2; exit 2 ;;
  esac
done

echo "Cleaning up containers for GPUs: $GPUS_CSV starting at Port: $BASE_PORT..."

IFS=',' read -r -a GPU_LIST <<< "${GPUS_CSV}"

for i in "${!GPU_LIST[@]}"; do
  gpu_id="${GPU_LIST[$i]}"
  HOST_PORT="$((BASE_PORT + gpu_id))"
  CONTAINER_NAME="${NAME_PREFIX}_${gpu_id}"

  echo "Checking cleanup for GPU $gpu_id (Port $HOST_PORT)..."

  if [ "$(sudo_run docker ps -a -q -f name=^/${CONTAINER_NAME}$)" ]; then
    echo "  - Removing container named: ${CONTAINER_NAME}"
    sudo_run docker rm -f "${CONTAINER_NAME}" >/dev/null
  fi

  PORT_CONTAINERS="$(sudo_run docker ps -a -q --filter "publish=${HOST_PORT}" || true)"
  if [ -n "${PORT_CONTAINERS}" ]; then
    echo "  - Releasing port ${HOST_PORT} (killing container: ${PORT_CONTAINERS})"
    sudo_run docker rm -f ${PORT_CONTAINERS} >/dev/null
  fi
done

echo "Cleanup Complete."

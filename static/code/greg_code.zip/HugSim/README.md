# HugSim closed-loop eval for GREG

[HugSim](https://github.com/hyzhou404/HUGSIM) is a Gaussian-splat-based closed-loop driving
simulator. The heavy install (docker image, scene dataset, run logs) lives outside this repo at
`$HUGSIM_ROOT/`.

## Setting this up on a new machine

1. **GPUs + Docker.** Needs an NVIDIA GPU with `--gpus` support in Docker and enough VRAM for one
   DINOv3-ViT-L + Gaussian-splat render pass per worker (a single RTX 3090, 24G, is enough for one
   worker).

   If `nvidia-cuda-mps-control -d` is running on the machine, it must be stopped before Docker
   starts (MPS conflicts with `docker run --gpus`). `run_test.sh` handles this automatically
   (stops MPS at start, restarts on exit only if it found MPS already running).
2. **Conda env.** Needs the `greg_rl` conda env, created with
   `conda env create -f ../Greg_RL/env.yml` — the same one `team_agent/`'s Bench2Drive eval uses.
3. **Server code + docker recipe** (`code/`, `docker/`) — copy from an existing install:
   ```bash
   rsync -av <host>:/path/to/HUGSIM_Local_Server/code/   $HUGSIM_ROOT/code/
   rsync -av <host>:/path/to/HUGSIM_Local_Server/docker/ $HUGSIM_ROOT/docker/
   ```
4. **Scene dataset.** Public dataset:
   [`XDimLab/HUGSIM` on HuggingFace](https://huggingface.co/datasets/XDimLab/HUGSIM) (MIT
   license, ~61G).
   ```python
   from huggingface_hub import snapshot_download
   snapshot_download(repo_id='XDimLab/HUGSIM', repo_type='dataset', revision='main',
                      local_dir='$HUGSIM_ROOT/HUGSIM_data')
   ```
   Lay it out the way `web_server_1.py` expects and unzip everything in place:
   ```bash
   cd $HUGSIM_ROOT/HUGSIM_data
   mkdir -p ss/scenes && mv scenes/* ss/scenes/ && rmdir scenes
   mkdir -p ss/scenarios && unzip -o scenarios.zip -d ss/scenarios
   unzip -o nusc_map_cache.zip -d nusc_map_cache
   find . -type f -name "*.zip" | while read f; do
       dir=$(dirname "$f"); name=$(basename "${f%.zip}"); out="$dir/$name"
       mkdir -p "$out" && unzip -o "$f" -d "$out"
       [ -d "$out/$name" ] && mv "$out/$name"/* "$out"/ && rmdir "$out/$name"
   done
   ```
   If an existing install is available, rsync is faster than re-downloading (exclude `.git` if the
   source is a git-lfs checkout):
   ```bash
   rsync -av --exclude='.git' <host>:/path/to/HUGSIM_data/ $HUGSIM_ROOT/HUGSIM_data/
   ```
5. **Build the docker image** (needs a `.dockerignore` excluding `HUGSIM_data/` and `logs/`):
   ```bash
   cd $HUGSIM_ROOT
   sudo docker build . -f ./docker/web_server_dockerfile -t hugsim_server:local
   ```
6. **Checkpoints + HF token** — see below.
7. Run `./HugSim/run_test.sh` from the repo root.

## Checkpoints

`run_test.sh` defaults to the current GREG checkpoints, synced from `Greg_RL/GREG_RL_Trainer/`:

| Role | Path |
|---|---|
| IL base | `Greg_RL/GREG_RL_Trainer/checkpoints/greg_dino.ckpt` |
| RL overlay | `Greg_RL/GREG_RL_Trainer/model_pth/sac_checkpoint.pth` |

Set `ORIGINAL_CHECKPOINT=True` in `.env` to run IL-only (no RL/RSSM overlay); the default
(`False`) runs the full IL+RL+RSSM policy.

To swap in a different checkpoint pair without editing the script:
```bash
IL_CHECKPOINT=/path/to/some.ckpt RL_CHECKPOINT=/path/to/some_sac_checkpoint.pth ./HugSim/run_test.sh
```

## Configuration (`.env`)

Repo-root `.env` needs:
- `HF_TOKEN` — gates the `facebook/dinov3-vitl16-pretrain-lvd1689m` download (cached under
  `Greg_RL/dinov3_large_cache/` after the first run, ~1.2G).
- `localmachinePass` — this machine's sudo password, used for the `docker` commands in
  `run_test.sh`/`clean.sh`.

## Running it

```bash
./HugSim/run_test.sh                            # GPU 0, full IL+RL+RSSM policy
GPUS=0,1 ./HugSim/run_test.sh                    # spread across 2 GPUs
ORIGINAL_CHECKPOINT=True ./HugSim/run_test.sh    # IL-only, no RL/RSSM overlay
```

Each GPU gets its own docker container (`hugsim_server_greg_<gpu>`, port `8065+gpu`) and its own
`e2e_client_greg.py` process. Logs: `worker_<gpu>.log`, `docker_server_<gpu>.log` under
`$HUGSIM_ROOT/`.

`./HugSim/clean.sh --gpus 0,1 --base-port 8065` tears down containers/frees ports without
restarting.

## RL worker

`HugSim/rl_worker/hugsim_rl_worker.py` + `HugSim/run_rl_worker.sh` is a HugSim rollout worker for
`GREG_RL_Trainer`. Needs a `GREG_RL_Trainer` instance running separately (`data_server.py` +
`learner.py`), with `MASTER_IP`/`DATA_SERVER_PORT` reachable:

```bash
MASTER_IP=<trainer host> ./HugSim/run_rl_worker.sh                 # GPU 0, default batch cadence
GPUS=1 SEND_EVERY_DECISIONS=5 ./HugSim/run_rl_worker.sh             # GPU 1, send smaller/faster batches
```

`MASTER_IP` can also come from `Greg_RL/GREG_RL_Trainer/.env` (sourced automatically if present).
`SEND_EVERY_DECISIONS` (default 50) controls how many policy decisions accumulate in the worker's
local buffer before it POSTs a batch and pulls fresh weights.

Running multiple GPU workers: pass a comma-separated `GPUS` list
(`GPUS=0,1,2 ./HugSim/run_rl_worker.sh`), or launch separate invocations per GPU.

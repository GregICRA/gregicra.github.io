#!/usr/bin/env python3
"""Build a curated HugSim data root (subset of scenarios) to bind-mount as /app/app_datas/,
since web_server_1.py's _get_scene_list() globs the full dataset dir per data_type with no
subset-selection HTTP API.

Non-scenario data (scenes/, 3DRealCar/, nusc_map_cache/) is symlinked, not copied, since it's
tens of GB; scenario yamls resolve model_path against the (symlinked) ss/scenes/ dir regardless
of which yamls are present.

Symlinks use absolute host paths into $HUGSIM_ROOT/HUGSIM_data. Any docker run using a curated
root must also bind-mount the real data root at the SAME absolute path inside the container, so
the symlink targets resolve, e.g.:
  -v $HUGSIM_ROOT/HUGSIM_data:$HUGSIM_ROOT/HUGSIM_data:ro

Usage: curate_scenarios.py <label> <dataset:scenario_stub> [<dataset:scenario_stub> ...]
  e.g. curate_scenarios.py batch10 kitti360:scene-250_450-easy-00 waymo:scene-100613054308-easy-00
Prints the curated root path on stdout.
"""
import os
import sys

HUGSIM_ROOT = os.environ.get("HUGSIM_ROOT", "./HugSim_Local_Server")  # set in .env
REAL_DATA = os.path.join(HUGSIM_ROOT, "HUGSIM_data")


def build(label, dataset_scenarios):
    """dataset_scenarios: dict[dataset_type] -> list[scenario_stub] (no .yaml suffix)."""
    curated = os.path.join(HUGSIM_ROOT, f"HUGSIM_data_curated_{label}")
    ss_dir = os.path.join(curated, "ss")
    scenarios_dir = os.path.join(ss_dir, "scenarios")
    os.makedirs(scenarios_dir, exist_ok=True)

    # Whole-dir symlinks for everything scenario yamls / base configs resolve against.
    for name in ["scenes", "nusc_map_cache"]:
        link = os.path.join(ss_dir, name)
        target = os.path.join(REAL_DATA, "ss", name)
        if not os.path.islink(link) and not os.path.exists(link):
            os.symlink(target, link)
    top_link = os.path.join(curated, "3DRealCar")
    if not os.path.islink(top_link) and not os.path.exists(top_link):
        os.symlink(os.path.join(REAL_DATA, "3DRealCar"), top_link)

    for dataset_type, stubs in dataset_scenarios.items():
        out_dir = os.path.join(scenarios_dir, dataset_type)
        os.makedirs(out_dir, exist_ok=True)
        for stub in stubs:
            src = os.path.join(REAL_DATA, "ss", "scenarios", dataset_type, f"{stub}.yaml")
            if not os.path.exists(src):
                raise FileNotFoundError(src)
            dst = os.path.join(out_dir, f"{stub}.yaml")
            if not os.path.islink(dst) and not os.path.exists(dst):
                os.symlink(src, dst)
    return curated


if __name__ == "__main__":
    label = sys.argv[1]
    dataset_scenarios = {}
    for arg in sys.argv[2:]:
        dataset_type, stub = arg.split(":", 1)
        dataset_scenarios.setdefault(dataset_type, []).append(stub)
    print(build(label, dataset_scenarios))

#!/usr/bin/env bash
# Runs the GREG-vs-HugSim closed-loop eval locally: starts the HugSim server in a docker
# container per GPU, then a Python client (client/e2e_client_greg.py) that drives GREG against it
# over HTTP. See HugSim/README.md for setup.
set -u

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
HUGSIM_ROOT="${HUGSIM_ROOT:?set HUGSIM_ROOT in .env: path to your HugSim server checkout}"

# =========================
# 1. Environment & Paths
# =========================
CONDA_BASE_PATH="${CONDA_BASE_PATH:?set CONDA_BASE_PATH in .env: your conda install prefix}"
source "${CONDA_BASE_PATH}/bin/activate"
conda activate greg_rl
PYTHON_EXE="${CONDA_BASE_PATH}/envs/greg_rl/bin/python"

set -a
[ -f "${REPO_ROOT}/.env" ] && source "${REPO_ROOT}/.env"
set +a
: "${HF_TOKEN:?Set HF_TOKEN in ${REPO_ROOT}/.env}"
: "${localmachinePass:?Set localmachinePass in ${REPO_ROOT}/.env (used for the sudo docker calls below)}"
SUDO="sudo -S"
sudo_run() { echo "$localmachinePass" | ${SUDO} "$@"; }

export PYTHONPATH="${REPO_ROOT}/Greg_RL/GREG_RL_worker:${REPO_ROOT}:${PYTHONPATH:-}"

BLACKOUT="${BLACKOUT:-none}"
case "$BLACKOUT" in
    none|low|high) ;;
    *) echo "BLACKOUT must be none, low, or high (got '$BLACKOUT')"; exit 1 ;;
esac
export GREG_BLACKOUT_LEVEL="$BLACKOUT"

MPS_WAS_RUNNING=0
if pgrep -f nvidia-cuda-mps-control >/dev/null 2>&1; then
    MPS_WAS_RUNNING=1
    echo "Stopping nvidia-cuda-mps-control for this run (Docker can't use it; will restart on exit)..."
    echo "quit" | nvidia-cuda-mps-control >/dev/null 2>&1 || true
    sleep 1
fi

echo "Killing previous processes..."
trap 'echo "Shutting down..."; if [ "$MPS_WAS_RUNNING" = "1" ]; then echo "Restarting nvidia-cuda-mps-control..."; nvidia-cuda-mps-control -d; fi; kill 0' SIGINT SIGTERM EXIT

"${REPO_ROOT}/HugSim/clean.sh" --name-prefix hugsim_server_greg --gpus "${GPUS:-0}" --base-port "${BASE_PORT:-8065}" || true
sleep 3

echo "Cleaning logs and fixing permissions..."
rm -f "${HUGSIM_ROOT}"/worker_*.log
sudo_run rm -rf "${HUGSIM_ROOT}"/output_*
sudo_run rm -rf "${HUGSIM_ROOT}"/challenge_output
CODE_DIR="${HUGSIM_ROOT}/code"
sudo_run chmod -R 777 "$CODE_DIR"

IMAGE_NAME="hugsim_server:local"
NAME_PREFIX="hugsim_server_greg"
DATA_DIR="${HUGSIM_ROOT}/HUGSIM_data"
BASE_OUTPUT_DIR="${HUGSIM_ROOT}"
BASE_PORT="${BASE_PORT:-8065}"

IL_CHECKPOINT="${IL_CHECKPOINT:-${REPO_ROOT}/Greg_RL/GREG_RL_Trainer/checkpoints/greg_dino.ckpt}"
RL_CHECKPOINT="${RL_CHECKPOINT:-${REPO_ROOT}/Greg_RL/GREG_RL_Trainer/model_pth/sac_checkpoint.pth}"
ORIGINAL_CHECKPOINT="${ORIGINAL_CHECKPOINT:-False}"

monitor_worker() {
    local gpu_id=$1
    local host_port=$((BASE_PORT + gpu_id))
    local container_name="${NAME_PREFIX}_${gpu_id}"
    local output_dir="${BASE_OUTPUT_DIR}/output_${host_port}"
    local log_file="${HUGSIM_ROOT}/worker_${gpu_id}.log"

    echo "[GPU ${gpu_id}] Monitor started. Logs -> ${log_file}"

    while true; do
        echo "[GPU ${gpu_id}] >>> (Re)Starting Deployment <<<" >> "$log_file"

        sudo_run docker rm -f "${container_name}" >/dev/null 2>&1 || true
        pkill -f "e2e_client_greg.py.*--server.*:${host_port}" || true

        mkdir -p "${output_dir}"
        sudo_run docker run --gpus "device=${gpu_id}" -d \
          --user root \
          -p "${host_port}:8065" \
          -e "WORKER_ID=${gpu_id}" \
          -v "${DATA_DIR}:/app/app_datas/" \
          -v "${CODE_DIR}:/app/code" \
          -v "/app/code/submodules/simple-knn/build" \
          -v "/app/code/submodules/simple-knn/simple_knn.egg-info" \
          -v "/app/code/sim/hugsim_env.egg-info" \
          -v "${output_dir}:/app/app_datas/env_output" \
          --name "${container_name}" \
          "${IMAGE_NAME}" \
          tail -f /dev/null >/dev/null

        sleep 15

        sudo_run docker exec -d "${container_name}" bash -lc "cd /app && pixi run python code/web_server_1.py"
        sudo_run docker logs -f "${container_name}" > "${HUGSIM_ROOT}/docker_server_${gpu_id}.log" 2>&1 &

        echo "[GPU ${gpu_id}] Waiting for server at port ${host_port}..." >> "$log_file"
        local retries=0
        local max_retries=60
        local server_ready=0

        while [ $retries -lt $max_retries ]; do
            if curl -m 5 -sSf "http://127.0.0.1:${host_port}/submition_info" > /dev/null 2>&1; then
                server_ready=1
                break
            fi
            if ! sudo_run docker ps -q -f "name=^/${container_name}$" >/dev/null; then
                echo "[GPU ${gpu_id}] CONTAINER DIED during boot." >> "$log_file"
                break
            fi
            sleep 5
            retries=$((retries+1))
        done

        if [ $server_ready -eq 0 ]; then
            echo "[GPU ${gpu_id}] TIMEOUT. Cooling down 60s before restart..." >> "$log_file"
            sudo_run docker logs "${container_name}" >> "$log_file" 2>&1
            sleep 60
            continue
        fi

        echo "[GPU ${gpu_id}] Server Ready. Launching Client..." >> "$log_file"

        CUDA_VISIBLE_DEVICES=${gpu_id} ${PYTHON_EXE} "${REPO_ROOT}/HugSim/client/e2e_client_greg.py" \
            --output "${HUGSIM_ROOT}/challenge_output" \
            --il-checkpoint "${IL_CHECKPOINT}" \
            --rl-checkpoint "${RL_CHECKPOINT}" \
            --original-checkpoint "${ORIGINAL_CHECKPOINT}" \
            --server "http://127.0.0.1:${host_port}" >> "$log_file" 2>&1 &

        local client_pid=$!

        while true; do
            sleep 30
            if ! kill -0 $client_pid 2>/dev/null; then
                echo "[GPU ${gpu_id}] Client died. Restarting worker..." >> "$log_file"
                break
            fi
            if ! sudo_run docker ps -q -f "name=^/${container_name}$" >/dev/null; then
                echo "[GPU ${gpu_id}] Container disappeared. Restarting worker..." >> "$log_file"
                break
            fi
        done

        sleep 10
    done
}

IFS=',' read -r -a GPU_LIST <<< "${GPUS:-0}"
for gpu in "${GPU_LIST[@]}"; do
    monitor_worker "$gpu" &
    echo "Waiting for GPU $gpu to stabilize before starting next..."
    sleep 20
done

wait

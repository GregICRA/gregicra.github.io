import os
import torch
import numpy as np
from PIL import Image
import cv2
import math
from torchvision import transforms as T
from collections import OrderedDict

from Greg.model import Greg, RSSMBelief
from Greg.config import GlobalConfig

from transformers import AutoModel
import torch

RSSM_BURNIN_K = 16
RSSM_BURNIN_L = RSSM_BURNIN_K - 1
RSSM_OBS_DIM = 512 + 10        # [frozen IL embedding, 10-d route scalars]
RSSM_DETER_DIM = 256
RSSM_STOCH_GROUPS = 16
RSSM_STOCH_CLASSES = 16
RSSM_HIDDEN = 512
RSSM_UNIMIX = 0.01

TRAIN_DECISION_EVERY = 4
STOP_SPEED_THRESH = 0.1
STOP_MEMORY_CAP = 10.0


class GregHugSimWrapper:
    """Greg model wrapper for HugSim (IL + optional RL/RSSM)."""

    def __init__(self, checkpoint_path, rl_checkpoint_path=None, original_format=True, hf_token=None):
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.config = GlobalConfig()

        my_hf_token = hf_token or os.environ.get("HF_TOKEN", "")

        pretrained_model_name = "facebook/dinov3-vitl16-pretrain-lvd1689m"
        custom_cache_path = os.environ.get(
            "DINOV3_CACHE_DIR",
            os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
                         "Greg_RL", "dinov3_large_cache"),
        )
        vit_base = AutoModel.from_pretrained(
            pretrained_model_name,
            token=my_hf_token,
            cache_dir=custom_cache_path
        )

        self.net = Greg(self.config, vit_base_model=vit_base)

        ckpt = torch.load(checkpoint_path, map_location=self.device)
        ckpt = ckpt["state_dict"]
        new_state_dict = OrderedDict()
        for key, value in ckpt.items():
            new_key = key.replace("model.", "").replace("_orig_mod.", "")
            new_state_dict[new_key] = value

        il_missing, il_unexpected = self.net.load_state_dict(new_state_dict, strict=False)
        allowed_missing = [k for k in il_missing if any(
            tag in k for tag in ('route_adapter', 'policy_adapters', 'embed_denoiser', 'belief_proj')
        )]
        bad_missing = [k for k in il_missing if k not in allowed_missing]
        if bad_missing:
            raise RuntimeError(f"IL checkpoint missing unexpected keys: {bad_missing}")
        if il_unexpected:
            raise RuntimeError(f"IL checkpoint has unexpected extra keys: {il_unexpected}")

        self.rssm = None
        if not original_format:
            if rl_checkpoint_path is None:
                raise ValueError("original_format=False requires rl_checkpoint_path")
            print(f"Loading RL weights from {rl_checkpoint_path} ...")
            RL_ckpt = torch.load(rl_checkpoint_path, map_location=self.device)
            self.load_rl_weights(RL_ckpt)

        self.net.to(self.device)
        self.net.eval()

        self._im_transform = T.Compose([
            T.ToTensor(),
            T.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])

        print(f"Greg Model loaded successfully on {self.device}")

    def load_rl_weights(self, RL_ckpt):
        """Overlay RL policy and optional RSSM onto IL backbone."""
        if 'policy_net_state_dict' in RL_ckpt:
            policy_sd = RL_ckpt['policy_net_state_dict']
            rssm_sd = RL_ckpt.get('rssm_state_dict', None)
            rssm_burnin_k = RL_ckpt.get('rssm_burnin_k', None)
        else:
            policy_sd = dict(RL_ckpt)
            rssm_sd = policy_sd.pop('rssm_state_dict', None)
            rssm_burnin_k = policy_sd.pop('rssm_burnin_k', None)
        rl_missing, rl_unexpected = self.net.load_state_dict(policy_sd, strict=False)
        if rl_unexpected:
            raise RuntimeError(f"RL weights have unexpected extra keys: {rl_unexpected}")
        print(f"Loaded RL weights ({len(policy_sd)} tensors).")

        if rssm_sd is not None:
            checkpoint_burnin_k = 4 if rssm_burnin_k is None else int(rssm_burnin_k)
            if checkpoint_burnin_k != RSSM_BURNIN_K:
                raise RuntimeError(
                    f"RSSM burn-in mismatch: checkpoint K={checkpoint_burnin_k}, "
                    f"wrapper K={RSSM_BURNIN_K}")
            if self.rssm is None:
                self.rssm = RSSMBelief(embed_dim=RSSM_OBS_DIM, action_dim=7,
                                        deter_dim=RSSM_DETER_DIM, stoch_groups=RSSM_STOCH_GROUPS,
                                        stoch_classes=RSSM_STOCH_CLASSES, hidden=RSSM_HIDDEN,
                                        unimix=RSSM_UNIMIX).to(self.device)
            rssm_missing, rssm_unexpected = self.rssm.load_state_dict(rssm_sd, strict=False)
            bad_rssm_missing = [k for k in rssm_missing if not k.startswith('safety_horizon_head.')]
            if bad_rssm_missing or rssm_unexpected:
                raise RuntimeError(
                    f"Unexpected RSSM weight mismatch: missing={sorted(bad_rssm_missing)}, "
                    f"unexpected={sorted(rssm_unexpected)}")
            self.rssm.eval()
            print(f"Loaded RSSM (recurrent K={RSSM_BURNIN_K} belief active).")
        else:
            print("No rssm_state_dict in weights -> belief-less (pre-RSSM policy).")

    def process_hugsim_images(self, raw_images):
        """Process HugSim multi-view images into Foundation Model Mosaic format (2x3 tile, 512x896)."""
        def _to_uint8(img):
            if img is None:
                return None
            arr = np.array(img)
            if arr.dtype == np.uint8:
                return arr
            return (arr * 255).astype(np.uint8) if arr.size and arr.max() <= 1.0 else arr.astype(np.uint8)

        def _is_totally_black_uint8(img_uint8, max_threshold=0):
            if img_uint8 is None:
                return True
            if not isinstance(img_uint8, np.ndarray) or img_uint8.size == 0:
                return True
            try:
                return int(img_uint8.max()) <= int(max_threshold)
            except ValueError:
                return True

        front_img = _to_uint8(raw_images.get('CAM_FRONT'))
        front_left_img = _to_uint8(raw_images.get('CAM_FRONT_LEFT'))
        front_right_img = _to_uint8(raw_images.get('CAM_FRONT_RIGHT'))

        back_img = _to_uint8(raw_images.get('CAM_BACK'))
        back_left_img = _to_uint8(raw_images.get('CAM_BACK_LEFT'))
        back_right_img = _to_uint8(raw_images.get('CAM_BACK_RIGHT'))

        use_back = not _is_totally_black_uint8(back_img)
        use_back_left = not _is_totally_black_uint8(back_left_img)
        use_back_right = not _is_totally_black_uint8(back_right_img)

        encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), 20]

        def _compress(img):
            if img is None:
                return None
            _, encoded = cv2.imencode('.jpg', img, encode_param)
            return cv2.imdecode(encoded, cv2.IMREAD_COLOR)

        front_img = _compress(front_img)
        front_left_img = _compress(front_left_img)
        front_right_img = _compress(front_right_img)

        back_img = _compress(back_img) if use_back else None
        back_left_img = _compress(back_left_img) if use_back_left else None
        back_right_img = _compress(back_right_img) if use_back_right else None

        if front_img is not None and front_img.shape[1] == 1600:
            front_img = front_img[:, 200:1400, :]
        if front_left_img is not None and front_left_img.shape[1] == 1600:
            front_left_img = front_left_img[:, :1400, :]
        if front_right_img is not None and front_right_img.shape[1] == 1600:
            front_right_img = front_right_img[:, 200:, :]

        tile_h, tile_w = 256, 300
        blank_tile = np.zeros((tile_h, tile_w, 3), dtype=np.uint8)

        def _resize_or_blank(img, is_valid):
            if is_valid and img is not None:
                return cv2.resize(img, (tile_w, tile_h))
            return blank_tile.copy()

        tile_fl = _resize_or_blank(front_left_img, True)
        tile_f = _resize_or_blank(front_img, True)
        tile_fr = _resize_or_blank(front_right_img, True)

        tile_bl = _resize_or_blank(back_left_img, use_back_left)
        tile_b = _resize_or_blank(back_img, use_back)
        tile_br = _resize_or_blank(back_right_img, use_back_right)

        top_row = np.concatenate((tile_fl, tile_f, tile_fr), axis=1)
        bottom_row = np.concatenate((tile_bl, tile_b, tile_br), axis=1)

        mosaic_img = np.concatenate((top_row, bottom_row), axis=0)

        rgb = torch.from_numpy(mosaic_img).permute(2, 0, 1).unsqueeze(0).float()
        rgb = torch.nn.functional.interpolate(rgb, size=(512, 896), mode='bilinear', align_corners=False)
        rgb = rgb.squeeze(0).permute(1, 2, 0).byte().numpy()

        return rgb

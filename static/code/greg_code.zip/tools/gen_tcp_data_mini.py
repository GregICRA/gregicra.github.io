import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gen_tcp_data as g

ROOT = os.environ.get('B2D_MINI_ROOT', './Bench2Drive-mini')  # set via the environment

# 8/2 train/val split over the 10 mini routes (none of these appear in
# gen_tcp_data.py's full-dataset val_list, so that list can't be reused here).
VAL_ROUTES = {
	'ControlLoss_Town11_Route401_Weather11',
	'DynamicObjectCrossing_Town02_Route13_Weather6',
}

if __name__ == '__main__':
	routes = sorted(os.listdir(ROOT))
	splits = {
		'train': [r for r in routes if r not in VAL_ROUTES],
		'val': [r for r in routes if r in VAL_ROUTES],
	}

	for split_name, split_routes in splits.items():
		g.TRAIN = (split_name == 'train')
		count = __import__('multiprocessing').Value('d', 0)
		seq_data_list = [g.gen_single_route(os.path.join(ROOT, r), count) for r in split_routes]
		g.gen_sub_folder(seq_data_list)

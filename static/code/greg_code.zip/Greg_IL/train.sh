#!/usr/bin/env bash
pkill -9 python
sleep 10

conda activate greg_il
cd "$(dirname "$0")"
export PYTHONPATH=$PYTHONPATH:$(pwd)
python train.py --gpus 2
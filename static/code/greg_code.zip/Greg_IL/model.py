import copy
from collections import deque
import numpy as np
import torch
from torch import nn
import torch.nn.functional as F
from resnet import *

class DINOv3MultiBranchBackbone(nn.Module):
    def __init__(self, vit_model, k=2, early_layer_idx=3, embed_dim=384, target_channels=512):
        super().__init__()
        
        # 1. Store and freeze the foundation model completely
        self.vit = vit_model
        
        if hasattr(self.vit, 'config'):
            self.vit.config.output_hidden_states = True
            
        for param in self.vit.parameters():
            param.requires_grad = False
            
        # 2. Resolve the backbone's transformer blocks across HF naming variants.
        if hasattr(self.vit, 'layers'):
            source_blocks = self.vit.layers
        elif hasattr(self.vit, 'blocks'):
            source_blocks = self.vit.blocks
        elif hasattr(self.vit, 'encoder') and hasattr(self.vit.encoder, 'layer'):
            source_blocks = self.vit.encoder.layer
        elif hasattr(self.vit, 'encoder') and hasattr(self.vit.encoder, 'layers'):
            source_blocks = self.vit.encoder.layers
        else:
            source_blocks = next((m for m in self.vit.modules() if isinstance(m, nn.ModuleList)), None)
            if source_blocks is None:
                raise AttributeError("Could not dynamically locate the transformer blocks!")

        total_layers = len(source_blocks)
        self.early_idx = early_layer_idx
        self.split_idx = total_layers - k
        
        # 3. Trainable twin branch: deep copies of the last (total - split_idx) blocks.
        trainable_blocks = []
        for i in range(self.split_idx, total_layers):
            trainable_blocks.append(copy.deepcopy(source_blocks[i]))
        self.trainable_blocks = nn.ModuleList(trainable_blocks)
        
        # captures the frozen model's RoPE position embeddings so the trainable twin branch can reuse them
        self._rope_cache = None

        def capture_rope_hook(module, args, kwargs):
            if 'position_embeddings' in kwargs:
                self._rope_cache = kwargs['position_embeddings']
            elif len(args) >= 4:
                self._rope_cache = args[3]
            else:
                self._rope_cache = None

        # Register the hook on the very first block of the frozen model
        source_blocks[0].register_forward_pre_hook(capture_rope_hook, with_kwargs=True)

        # 4. Resolve the backbone's final norm across HF naming variants.
        if hasattr(self.vit, 'layernorm'):
            source_norm = self.vit.layernorm
        elif hasattr(self.vit, 'norm'):
            source_norm = self.vit.norm
        elif hasattr(self.vit, 'layer_norm'):
            source_norm = self.vit.layer_norm
        else:
            raise AttributeError("Could not dynamically locate the final LayerNorm!")
            
        self.trainable_norm = copy.deepcopy(source_norm)
        
        # Ensure the cloned blocks and norm are actively tracking gradients
        for param in self.trainable_blocks.parameters():
            param.requires_grad = True
        for param in self.trainable_norm.parameters():
            param.requires_grad = True

        # 5. Spatial Adapter 
        in_channels = embed_dim * 3 
        self.spatial_adapter = nn.Sequential(
            nn.Conv2d(in_channels, target_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(target_channels),
            nn.ReLU(inplace=True)
        )
        self.global_pool = nn.AdaptiveAvgPool2d((1, 1))

    @torch.compiler.disable
    def _get_frozen_features(self, img):
        self._rope_cache = None
        
        with torch.no_grad():
            outputs = self.vit(img, return_dict=True)
            early_emb = outputs.hidden_states[self.early_idx + 1] 
            late_emb = outputs.last_hidden_state
            branch_input = outputs.hidden_states[self.split_idx]
            
        return early_emb, late_emb, branch_input, self._rope_cache

    def forward(self, img):
        B, _, H, W = img.shape
        grid_h, grid_w = H // 16, W // 16
        
        # 1. Safely extract the frozen features AND the intercepted RoPE embeddings
        early_emb, late_emb, branch_input, rope_embeddings = self._get_frozen_features(img)

        # 2. Trainable twin branch
        x = branch_input
        for block in self.trainable_blocks:
            # Pass the intercepted RoPE embeddings so the block keeps its spatial awareness.
            block_out = block(x, position_embeddings=rope_embeddings)
            x = block_out[0] if isinstance(block_out, tuple) else block_out
            
        trainable_emb = self.trainable_norm(x)
        
        # FUSION & ADAPTATION
        fused_tokens = torch.cat([early_emb, late_emb, trainable_emb], dim=-1)
        patches = fused_tokens[:, 5:, :]
        
        spatial_features = patches.transpose(1, 2).view(B, -1, grid_h, grid_w)
        cnn_feature = self.spatial_adapter(spatial_features)
        feature_emb = self.global_pool(cnn_feature).flatten(1)
        
        return feature_emb, cnn_feature






Discrete_Actions_DICT = {
	0:  (0, 1, False),
	1:  (0.0, 0, False),
	2: (0.3, 0, False),
	3: (0.7, 0.0, False),
	4: (1.0, 0, False),
	5: (0.5, 0, True),
	}


class ResidualBlock(nn.Module):
    def __init__(self, dim, dropout=0.1):
        super().__init__()
        self.fc = nn.Sequential(
            nn.Linear(dim, dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(dim, dim)
        )
        self.norm = nn.LayerNorm(dim)
        self.activation = nn.GELU()

    def forward(self, x):
        return self.activation(self.norm(x + self.fc(x)))  # skip connection

class PIDController(object):
	def __init__(self, K_P=1.0, K_I=0.0, K_D=0.0, n=20):
		self._K_P = K_P
		self._K_I = K_I
		self._K_D = K_D

		self._window = deque([0 for _ in range(n)], maxlen=n)
		self._max = 0.0
		self._min = 0.0

	def step(self, error):
		self._window.append(error)
		self._max = max(self._max, abs(error))
		self._min = -abs(self._max)

		if len(self._window) >= 2:
			integral = np.mean(self._window)
			derivative = (self._window[-1] - self._window[-2])
		else:
			integral = 0.0
			derivative = 0.0

		return self._K_P * error + self._K_I * integral + self._K_D * derivative

class Greg(nn.Module):
	def __init__(self, config, vit_base_model):
		super().__init__()
		self.config = config

		self.turn_controller = PIDController(K_P=config.turn_KP, K_I=config.turn_KI, K_D=config.turn_KD, n=config.turn_n)
		self.speed_controller = PIDController(K_P=config.speed_KP, K_I=config.speed_KI, K_D=config.speed_KD, n=config.speed_n)

		# 1. Perception Backbone
		self.perception = DINOv3MultiBranchBackbone(vit_base_model, k=2, early_layer_idx=3, embed_dim=1024, target_channels=512)

		# 2. Transformer Engine parameters
		d_model = 512
		nhead = 8
		num_layers = 3
		self.pred_len = self.config.pred_len
		self.num_accel_actions = len(Discrete_Actions_DICT)

		# 3. State & Query Embedding
		self.state_embed = nn.Sequential(
			nn.Linear(1 + 2 + 6 + 2, 256), 
			nn.GELU(),
			nn.Linear(256, d_model),
			nn.LayerNorm(d_model)
		)
		self.spatial_pos_embed = nn.Parameter(torch.randn(1, 32 * 56, d_model) * 0.02)
		self.time_query_embed = nn.Parameter(torch.randn(1, self.pred_len + 1, d_model) * 0.02)

		# 4. Transformer Decoder (Pre-LN)
		decoder_layer = nn.TransformerDecoderLayer(
			d_model=d_model, 
			nhead=nhead, 
			dim_feedforward=2048, 
			dropout=0.1,
			activation="gelu",    # matches the DINOv3 backbone
			batch_first=True, 
			norm_first=True       # pre-LayerNorm blocks
		)
		# Final norm on the decoder output, for stability
		self.transformer = nn.TransformerDecoder(decoder_layer, num_layers=num_layers, norm=nn.LayerNorm(d_model))

		# 5. Prediction Heads
		self.value_head = nn.Sequential(nn.Linear(d_model, 256), nn.GELU(), nn.Dropout(0.1), nn.Linear(256, 1))
		self.feature_head = nn.Sequential(nn.Linear(d_model, 1536), nn.GELU())
		self.speed_head = nn.Sequential(nn.Linear(d_model, 256), nn.GELU(), nn.Dropout(0.1), nn.Linear(256, 1))
		self.wp_head = nn.Sequential(nn.Linear(d_model, 256), nn.GELU(), nn.Linear(256, 2))

		# 6. Deep Policy Engine
		self.rl_policy_engine = nn.Sequential(
			nn.LayerNorm(d_model),
			nn.Linear(d_model, 512),
			nn.GELU(),
			ResidualBlock(512),
			ResidualBlock(512), 
			ResidualBlock(512), 
			nn.Linear(512, 256),
			nn.GELU()
		)
		
		self.steer_mu = nn.Linear(256, 1)
		self.steer_sigma = nn.Linear(256, 1)
		self.accel_logits = nn.Linear(256, self.num_accel_actions)

	def forward(self, img, state, target_point):
		B, _, H, W = img.shape
		
		# 1. Image Perception
		_, cnn_feature = self.perception(img) 
		
		# Unroll spatial grid: [B, 512, 1792] -> [B, 1792, 512]
		memory = cnn_feature.flatten(2).transpose(1, 2)
		memory = memory + self.spatial_pos_embed

		# 2. State & Query Preparation
		context = torch.cat([state, target_point], dim=-1)
		state_tokens = self.state_embed(context).unsqueeze(1)
		tgt = self.time_query_embed.expand(B, -1, -1) + state_tokens

		# 3. Transformer Cross-Attention
		tf_out = self.transformer(tgt=tgt, memory=memory)

		# 4. Route Output Tokens to Heads
		token_curr = tf_out[:, 0, :]
		tokens_future = tf_out[:, 1:, :] 
		
		outputs = {}
		
		# Current Global Predictions 
		outputs['pred_speed'] = self.speed_head(token_curr)
		outputs['pred_value_traj'] = self.value_head(token_curr)
		outputs['pred_features_traj'] = self.feature_head(token_curr)
		outputs['pred_value_ctrl'] = self.value_head(token_curr)
		outputs['pred_features_ctrl'] = self.feature_head(token_curr)
		
		# RL State Extraction (Lightweight summary for Replay Buffer)
		outputs['join_ctrl_inp'] = token_curr 

		# Current Deep RL Forward Pass
		curr_policy = self.rl_policy_engine(token_curr)
		steer_mu = self.steer_mu(curr_policy)
		steer_sigma = self.steer_sigma(curr_policy)
		L, U = 1.0 + 1e-6, 60.0 
		steer_mu = (U - L) * 0.5 * (torch.tanh(steer_mu) + 1.0) + L
		steer_sigma  = (U - L) * 0.5 * (torch.tanh(steer_sigma) + 1.0) + L
		
		outputs['steer_mu'] = steer_mu
		outputs['steer_sigma'] = steer_sigma
		outputs['accel_logits'] = self.accel_logits(curr_policy)

		# Future Predictions 
		wp_offsets = self.wp_head(tokens_future)
		outputs['pred_wp'] = torch.cumsum(wp_offsets, dim=1) 
		
		future_policies = self.rl_policy_engine(tokens_future.reshape(B * self.pred_len, -1)).view(B, self.pred_len, -1)
		
		f_steer_mu = self.steer_mu(future_policies)
		f_steer_sigma = self.steer_sigma(future_policies)
		f_steer_mu = (U - L) * 0.5 * (torch.tanh(f_steer_mu) + 1.0) + L
		f_steer_sigma = (U - L) * 0.5 * (torch.tanh(f_steer_sigma) + 1.0) + L
		f_accel_logits = self.accel_logits(future_policies)
		f_features = self.feature_head(tokens_future)

		# Format as lists to maintain PyTorch Lightning loss calculation compatibility
		outputs['future_feature'] = [f_features[:, i, :] for i in range(self.pred_len)]
		outputs['future_steer_mu'] = [f_steer_mu[:, i, :] for i in range(self.pred_len)]
		outputs['future_steer_sigma'] = [f_steer_sigma[:, i, :] for i in range(self.pred_len)]
		outputs['future_accel_logits'] = [f_accel_logits[:, i, :] for i in range(self.pred_len)]

		return outputs

	def process_action(self, pred, command, speed, target_point):
		steer = self._get_action_beta(pred['steer_mu'], pred['steer_sigma'])
		steer = steer.cpu().numpy().flatten()[0]
		
		accel_logits = pred['accel_logits']
		accel_category = torch.argmax(accel_logits, dim=-1).cpu().item()
		
		throttle, brake, reverse = Discrete_Actions_DICT[accel_category][:3]
		
		steer = np.clip(steer, -1.0, 1.0)
		throttle = np.clip(throttle, 0.0, 1.0)
		brake = np.clip(brake, 0.0, 1.0)
		
		metadata = {
			'speed': float(speed.cpu().numpy().astype(np.float64)),
			'steer': float(steer),
			'throttle': float(throttle),
			'brake': float(brake),
			'command': command,
			'target_point': tuple(target_point[0].data.cpu().numpy().astype(np.float64)),
			'accel_category': accel_category,
		}
		return steer, throttle, brake, reverse, metadata

	def _get_action_beta(self, alpha, beta):
		x = (alpha-1+1e-3)/(alpha+beta-2+2e-3)
		x = x * 2 - 1
		return x

	def control_pid(self, waypoints, velocity, target):
		assert(waypoints.size(0)==1)
		waypoints = waypoints[0].data.cpu().numpy()
		target = target.squeeze().data.cpu().numpy()

		waypoints[:, [0, 1]] = waypoints[:, [1, 0]]  
		target[[0, 1]] = target[[1, 0]]

		num_pairs = len(waypoints) - 1
		best_norm = 1e5
		desired_speed = 0
		aim = waypoints[0]
		for i in range(num_pairs):
			desired_speed += np.linalg.norm(waypoints[i+1] - waypoints[i]) * 2.0 / num_pairs
			norm = np.linalg.norm((waypoints[i+1] + waypoints[i]) / 2.0)
			if abs(self.config.aim_dist-best_norm) > abs(self.config.aim_dist-norm):
				aim = waypoints[i]
				best_norm = norm

		aim_last = waypoints[-1] - waypoints[-2]
		angle = np.degrees(np.pi / 2 - np.arctan2(aim[1], aim[0])) / 90
		angle_last = np.degrees(np.pi / 2 - np.arctan2(aim_last[1], aim_last[0])) / 90
		angle_target = np.degrees(np.pi / 2 - np.arctan2(target[1], target[0])) / 90

		use_target_to_aim = np.abs(angle_target) < np.abs(angle)
		use_target_to_aim = use_target_to_aim or (np.abs(angle_target-angle_last) > self.config.angle_thresh and target[1] < self.config.dist_thresh)
		if use_target_to_aim:
			angle_final = angle_target
		else:
			angle_final = angle

		steer = self.turn_controller.step(angle_final)
		steer = np.clip(steer, -1.0, 1.0)

		speed = velocity[0].data.cpu().numpy()
		brake = desired_speed < self.config.brake_speed or (speed / desired_speed) > self.config.brake_ratio

		delta = np.clip(desired_speed - speed, 0.0, self.config.clip_delta)
		throttle = self.speed_controller.step(delta)
		throttle = np.clip(throttle, 0.0, self.config.max_throttle)
		throttle = throttle if not brake else 0.0

		metadata = {
			'speed': float(speed.astype(np.float64)),
			'steer': float(steer),
			'throttle': float(throttle),
			'brake': float(brake),
			'wp_4': tuple(waypoints[3].astype(np.float64)),
			'wp_3': tuple(waypoints[2].astype(np.float64)),
			'wp_2': tuple(waypoints[1].astype(np.float64)),
			'wp_1': tuple(waypoints[0].astype(np.float64)),
			'aim': tuple(aim.astype(np.float64)),
			'target': tuple(target.astype(np.float64)),
			'desired_speed': float(desired_speed.astype(np.float64)),
			'angle': float(angle.astype(np.float64)),
			'angle_last': float(angle_last.astype(np.float64)),
			'angle_target': float(angle_target.astype(np.float64)),
			'angle_final': float(angle_final.astype(np.float64)),
			'delta': float(delta.astype(np.float64)),
		}
		return steer, throttle, brake, metadata

	def get_action(self, mu, sigma):
		action = self._get_action_beta(mu, sigma)
		acc, steer = action[:, 0], action[:, 1]
		throttle = torch.clamp(acc, 0, 1)
		brake = torch.clamp(-acc, 0, 1)
		throttle = torch.clamp(throttle, 0, 1)
		steer = torch.clamp(steer, -1, 1)
		brake = torch.clamp(brake, 0, 1)
		return throttle, steer, brake

	def get_dist_params(self, j_ctrl):
		x = self.rl_policy_engine(j_ctrl)
		
		alpha = self.steer_mu(x)
		beta = self.steer_sigma(x)
		L, U = 1.0 + 1e-6, 60.0
		alpha = (U - L) * 0.5 * (torch.tanh(alpha) + 1.0) + L
		beta  = (U - L) * 0.5 * (torch.tanh(beta) + 1.0) + L

		accel_logits = self.accel_logits(x)

		if torch.isnan(accel_logits).any():
			accel_logits = torch.nan_to_num(accel_logits, nan=0.0)
		accel_logits = torch.clamp(accel_logits, min=-10.0, max=10.0)
		
		return alpha, beta, accel_logits

	def get_dist(self, j_ctrl):
		alpha, beta, accel_logits = self.get_dist_params(j_ctrl)
		steer_dist = torch.distributions.Beta(alpha, beta)
		accel_dist = torch.distributions.Categorical(logits=accel_logits)
		return steer_dist, accel_dist
		
	def get_deterministic_action(self, pred):
		steer_mu = pred['steer_mu']
		steer_sigma = pred['steer_sigma']
		steer = self._get_action_beta(steer_mu, steer_sigma).item()

		accel_logits = pred['accel_logits']
		accel_category = torch.argmax(accel_logits, dim=-1).item()
		
		throttle, brake, reverse = Discrete_Actions_DICT[accel_category][:3]

		steer = np.clip(steer, -1.0, 1.0)
		throttle = np.clip(throttle, 0.0, 1.0)
		brake = np.clip(brake, 0.0, 1.0)
		
		return steer, throttle, brake, reverse
		
	def get_actionrl(self, j_ctrl, return_alphabeta=False, deterministic=False):
		steer_dist, accel_dist = self.get_dist(j_ctrl)
		
		steer_action = steer_dist.sample()
		accel_action = accel_dist.sample()

		accel_action = torch.clamp(accel_action, min=0, max=self.num_accel_actions - 1)  # prevent CUDA gather crash on OOB index

		action = torch.cat([steer_action, accel_action.unsqueeze(-1).float()], dim=-1)
		log_prob = steer_dist.log_prob(steer_action).sum(dim=-1) + accel_dist.log_prob(accel_action)
		entropy = steer_dist.entropy().sum(dim=-1) + accel_dist.entropy()
		
		if deterministic:
			accel_logits = accel_dist.logits
			steer_sigma = steer_dist.concentration0
			steer_mu = steer_dist.concentration1
			accel_det = torch.argmax(accel_logits, dim=-1)

			accel_one_hot = F.one_hot(accel_det, num_classes=self.num_accel_actions).float()
			
			steer = ((self._get_action_beta(steer_mu, steer_sigma)+1)/2)
			action = torch.cat([steer, accel_one_hot, accel_det.unsqueeze(-1)], dim=-1)
			
		if return_alphabeta:
			alpha, beta, _ = self.get_dist_params(j_ctrl)
			return action, log_prob, entropy, alpha, beta
			
		return action, log_prob, entropy

	def log_prob(self, j_ctrl, action):
		steer_dist, accel_dist = self.get_dist(j_ctrl)

		steer_action = action[:, 0].unsqueeze(-1)
		accel_action = action[:, 1].long()  # Categorical needs long type

		steer_log_prob = steer_dist.log_prob(steer_action).sum(dim=-1)
		accel_log_prob = accel_dist.log_prob(accel_action)
		
		return steer_log_prob + accel_log_prob

	def entropy(self, j_ctrl):
		steer_dist, accel_dist = self.get_dist(j_ctrl)

		steer_entropy = steer_dist.entropy().sum(dim=-1)
		accel_entropy = accel_dist.entropy()

		return steer_entropy + accel_entropy
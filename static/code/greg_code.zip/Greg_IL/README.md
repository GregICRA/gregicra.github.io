# Greg_IL

Imitation-learning training setup for GREG (DINOv3 backbone + PyTorch Lightning trainer).

## Setup
- Conda env `greg_il`: `conda env create -f env.yml`
- `config.py`'s `root_dir_all` points at the Bench2Drive-mini dataset root (`$B2D_MINI_ROOT`
  by default). `train_data` / `val_data` name the index files (`greg_bench2drive-train.npy` /
  `-val.npy`) that list the samples inside it; generate them with `tools/gen_tcp_data_mini.py`.
- `HF_TOKEN` — gates the `facebook/dinov3-vitl16-pretrain-lvd1689m` download (cached under
  `dinov3_large_cache/` after the first run). `train.py` calls `load_dotenv()`, which resolves to
  the nearest `.env` it finds walking up from this folder (the repo-root `.env` has it if none
  exists here).

## Training
```bash
./train.sh                  # conda activate greg_il; python train.py --gpus 2
# or directly, with more control:
python train.py --gpus <n> --epochs 100 --batch_size 16 --lr 3e-4 --id <run_name>
```
Checkpoints save under `<logdir>/<id>/` (`--logdir`, default `loglargedino/`, gitignored).

## Quick eval

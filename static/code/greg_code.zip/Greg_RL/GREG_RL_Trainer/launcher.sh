#!/bin/bash
nvidia-cuda-mps-control -d
source ~/miniconda3/bin/activate
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# All machine-specific config (CARLA_ROOT, MASTER_IP, ports, ...) lives in .env, not here.
# Copy .env.example to .env and fill it in.
set -a
[ -f "$SCRIPT_DIR/.env" ] && source "$SCRIPT_DIR/.env"
set +a
: "${CARLA_ROOT:?Set CARLA_ROOT in $SCRIPT_DIR/.env}"
: "${MASTER_IP:?Set MASTER_IP in $SCRIPT_DIR/.env}"

export WORK_DIR="$(cd "${SCRIPT_DIR}/../GREG_RL_worker" && pwd)"
export CARLA_ROOT
export CARLA_SERVER=${CARLA_ROOT}/CarlaUE4.sh
export SCENARIO_RUNNER_ROOT=${WORK_DIR}/scenario_runner
export LEADERBOARD_ROOT=${WORK_DIR}/leaderboard
export PYTHONPATH="${CARLA_ROOT}/PythonAPI/carla/":"${SCENARIO_RUNNER_ROOT}":"${LEADERBOARD_ROOT}":${PYTHONPATH}



conda activate greg_rl
export CUDA_VISIBLE_DEVICES=2
ROOT_CENTER="$SCRIPT_DIR"
# --- Configuration ---
NUM_WORKERS=0
PYTHON_CMD="python -u "

# --- Process Identifiers (unique strings to find these processes) ---
SERVER_ID=$ROOT_CENTER/"data_server.py"
LEARNER_ID=$ROOT_CENTER/"learner.py" 
WORKER_ID_BASE=$ROOT_CENTER/"worker.py" 

# --- Log file locations ---
LOG_DIR=$ROOT_CENTER/"logs"
mkdir -p $LOG_DIR

echo "--- 🚀 Starting System Supervisor ---"
echo "--- Log files will be saved in the '$LOG_DIR' directory ---"

# --- Main Supervisor Loop ---
while true; do
    # 1. Check and start the Master Data Server
    if ! pgrep -f "$SERVER_ID" > /dev/null; then
        echo "$(date): ⚠️ [SUPERVISOR] Data Server is down. Restarting..."
        nohup $PYTHON_CMD $SERVER_ID > "$LOG_DIR/server.log" 2>&1 &
    fi

    # 2. Check and start the Master Learner
    if ! pgrep -f "$LEARNER_ID" > /dev/null; then
        echo "$(date): 🧠 [SUPERVISOR] Learner is down. Restarting..."
        nohup $PYTHON_CMD $LEARNER_ID > "$LOG_DIR/learner.log" 2>&1 &
    fi

    # 3. Check and start each Worker
    for i in $(seq 0 $(($NUM_WORKERS-1))); do
        WORKER_ID="$WORKER_ID_BASE $i" # e.g., "worker.py 0"
        if ! pgrep -f "$WORKER_ID" > /dev/null; then
            echo "$(date): 🤖 [SUPERVISOR] Worker $i is down. Restarting..."
            nohup $PYTHON_CMD $WORKER_ID_BASE $i $MASTER_IP > "$LOG_DIR/worker_$i.log" 2>&1 &  # 2nd arg = master IP
        fi
    done

    # Wait for a few seconds before checking again.
    sleep 10
done
    


#!/bin/bash

# --- This script supervises a single CARLA benchmark worker ---
# It takes one argument: a unique worker ID (e.g., 1, 2, 3...).
# It runs the benchmark_runner.sh script in an infinite loop,
# ensuring it restarts automatically if the Python agent crashes.

# --- 1. SCRIPT SETUP AND VALIDATION ---

# Exit immediately if any command fails.
set -e

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
set -a
[ -f "$SCRIPT_DIR/.env" ] && source "$SCRIPT_DIR/.env"
set +a
CARLA_PORT_BASE="${CARLA_PORT_BASE:-30200}"

# Check if a worker ID was provided.
if [ -z "$1" ]; then
    echo "Usage: ./run_worker.sh <WORKER_ID>"
    echo "This script is intended to be called by launch_all_workers.sh"
    exit 1
fi

WORKER_ID=$1
num=$((WORKER_ID+1))


if [ "$num" -le 24 ]; then
    carla_port=$((CARLA_PORT_BASE+10*(num-1)))
else
    carla_port=$((CARLA_PORT_BASE+10*(num-1)+3))
fi
# Base name of the CARLA benchmark script.
BASE_BENCHMARK_SCRIPT="GREG_RL_Trainer/run_SAC_worker_dino.sh"
PROCESS_IDENTIFIER="leaderboard_trainer.py.*--port=${carla_port}"

# --- 2. MAIN SUPERVISOR LOOP ---
echo "✅ [Supervisor for Worker ${WORKER_ID}] Starting up..."

while true; do
    # Check if the specific Python process for this worker is running.
    # The `-f` flag allows pgrep to check the full command line arguments.
    if ! pgrep -f "$PROCESS_IDENTIFIER" > /dev/null; then
        
        echo "-----------------------------------------------------"
        echo "⚠️  [Supervisor for Worker ${WORKER_ID}] Python process not found. Restarting benchmark..."
        echo "Timestamp: $(date)"
        echo "-----------------------------------------------------"
        
        # Run the benchmark script from within its unique directory.
        # A subshell `(...)` changes directory without affecting the supervisor's CWD.
        # The `../` correctly points back to where the base benchmark script is located.
        ./"$BASE_BENCHMARK_SCRIPT" "$WORKER_ID"
        
        echo "🛑 [Supervisor for Worker ${WORKER_ID}] Benchmark script exited. Will check for restart in 10 seconds."
    fi

    # Wait for a few seconds before checking again to avoid excessive CPU usage.
    sleep 10
done


# GREG_RL_Trainer

Central learner/data-server for the RL stage: `launcher.sh` supervises `data_server.py`,
`learner.py`, and `worker.py` (worker loop is currently disabled via `NUM_WORKERS=0` in
`launcher.sh`). Actor rollouts happen on the worker side, in `../GREG_RL_worker`.

## Layout
- `launcher.sh` / `launch_all_workers.sh` / `run_worker.sh` / `run_SAC_worker_dino.sh` — process
  supervisors, meant to run with cwd = `Greg_RL/` (the parent of this folder and `GREG_RL_worker`).
- `data_server.py`, `learner.py`, `worker.py`, `readds.py` — the trainer processes.

## Configuration (`.env`)
`CARLA_ROOT`, `MASTER_IP`, ports, checkpoint/route paths, and the wandb API key all live in `.env`
(gitignored). Copy `.env.example` to `.env` and fill it in; the shell scripts `source` it, and the
Python processes load it via `python-dotenv` (`load_dotenv()`). Requires `python-dotenv` in the
`greg_rl` conda env, created with `conda env create -f ../env.yml`.

`HF_TOKEN` (used by `learner.py` to load the DINOv3 backbone) must also be set here —
python-dotenv stops at the nearest `.env` it finds and does not fall back further up the tree.

The remote sync server list `learner.py`'s `config_readds` reads (IPs/paths/usernames of machines
it pulls experience data from) lives in `sync_servers.json` (gitignored; see
`sync_servers.json.example`), pointed to by `RL_SYNC_SERVERS_FILE` in `.env`.

## Before running
- **`pass.txt` / `pass2.txt`** — plaintext SSH passwords `readds.py` reads to pull experience data
  from the hosts listed in `sync_servers.json`. Not committed; create them locally.
- `GREG_IL_CKPT` and `ROUTES_FILE` in `.env` point at files external to this repo (the IL
  warm-start checkpoint and the merged route file) — set them to wherever those files live.

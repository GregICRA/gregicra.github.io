import os

# Root of the carla_garage demonstration data; set via the CARLA_GARAGE_DATA environment variable.
CARLA_GARAGE_DATA = os.environ.get('CARLA_GARAGE_DATA', './carla_garage/data')

class GlobalConfig:

	root_dir = []
	data_roots = []
	val_towns = []

	train_data = './greg_bench2drive-train.npy'
	val_data = './greg_bench2drive-val.npy'
	carla_fps = 20
	data_save_freq = 5
	skip_first = int(2.5 * 20) // 5
	num_repetitions = 1

	pixels_per_meter = 4.0
	pixels_per_meter_collection = 2.0
	min_x = -32
	max_x = 32
	min_y = -32
	max_y = 32

	weight_decay = 0.01

	augment = True
	augment_percentage = 0.5
	seq_len = 1
	pred_len = 4
	train_sampling_rate = 1
	ignore_sides = True
	ignore_rear = True

	input_resolution = 256
	scale = 1
	crop = 256

	lr = 1e-4

	turn_KP = 0.75
	turn_KI = 0.75
	turn_KD = 0.3
	turn_n = 40

	speed_KP = 5.0
	speed_KI = 0.5
	speed_KD = 1.0
	speed_n = 40

	max_throttle = 0.75
	brake_speed = 0.4
	brake_ratio = 1.1
	clip_delta = 0.25

	aim_dist = 4.0
	angle_thresh = 0.3
	dist_thresh = 10

	speed_weight = 0.05
	value_weight = 0.001
	features_weight = 0.05

	rl_ckpt = "roach/log/ckpt_11833344.pth"
	img_aug = True

	use_sampled_val = False
	sampled_val_dirs = []

	def __init__(self, **kwargs):
		self.lidar_resolution_width = 256
		self.lidar_resolution_height = 256
		self.ego_extent_x = 2.4508416652679443
		self.ego_extent_y = 1.0641621351242065
		self.ego_extent_z = 0.7553732395172119
		self.bev_classes_list = [
		[0, 0, 0],  # unlabeled
		[200, 200, 200],  # road
		[255, 255, 255],  # sidewalk
		[255, 255, 0],  # road line
		[50, 234, 157],  # road line broken
		[160, 160, 0],  # stop sign
		[0, 255, 0],  # light green
		[255, 255, 0],  # light yellow
		[255, 0, 0],  # light red
		[250, 170, 30],  # vehicle
		[0, 255, 0],  # pedestrian
		]
		for k,v in kwargs.items():
			setattr(self, k, v)

	def initialize(self, root_dir='', setting='all', **kwargs):
		for k, v in kwargs.items():
			setattr(self, k, v)

		if isinstance(root_dir, str):
			self.root_dir = [root_dir]
		else:
			self.root_dir = root_dir

		self.val_towns = []
		self.use_sampled_val = False
		self.sampled_val_dirs = [
				f"{CARLA_GARAGE_DATA}/AccidentTwoWays/Town12_Rep0_26_0_route0_11_08_18_12_42",
				f"{CARLA_GARAGE_DATA}/ConstructionObstacleTwoWays/Town12_Rep0_406_0_route0_11_08_18_28_38",
				f"{CARLA_GARAGE_DATA}/ControlLoss/Town01_Rep0_Town01_Scenario1_0_route0_11_08_09_42_02",
				f"{CARLA_GARAGE_DATA}/EnterActorFlowV2/Town12_Rep0_975_0_route0_11_08_03_02_20",
				f"{CARLA_GARAGE_DATA}/MergerIntoSlowTrafficV2/Town12_Rep0_968_0_route0_11_08_11_46_58",
				f"{CARLA_GARAGE_DATA}/NonSignalizedJunctionLeftTurn",
				f"{CARLA_GARAGE_DATA}/OppositeVehicleRunningRedLight",
				f"{CARLA_GARAGE_DATA}/SignalizedJunctionLeftTurn",
				f"{CARLA_GARAGE_DATA}/VehicleOpensDoorTwoWays",
				f"{CARLA_GARAGE_DATA}/YieldToEmergencyVehicle",
				f"{CARLA_GARAGE_DATA}/MergerIntoSlowTrafficV2/Town13_Rep0_1249_8_route0_11_09_01_55_10", f"{CARLA_GARAGE_DATA}/HighwayCutIn/Town13_Rep0_1283_6_route0_11_08_04_08_48", f"{CARLA_GARAGE_DATA}/SignalizedJunctionLeftTurn/Town03_Rep0_Town03_Scenario7_61_route0_11_09_09_06_04", f"{CARLA_GARAGE_DATA}/noScenarios/Town04_Rep0_Town04_lr_0_route0_11_08_11_10_37", f"{CARLA_GARAGE_DATA}/Accident/Town13_Rep0_5_0_route0_11_09_11_24_14", f"{CARLA_GARAGE_DATA}/OppositeVehicleRunningRedLight/Town05_Rep0_Town05_Scenario8_29_route0_11_08_16_48_02", f"{CARLA_GARAGE_DATA}/noScenarios/Town04_Rep0_Town04_lr_39_route0_11_09_04_59_30", f"{CARLA_GARAGE_DATA}/VehicleTurningRoutePedestrian/Town12_Rep0_3009_0_route0_11_08_20_47_51", f"{CARLA_GARAGE_DATA}/EnterActorFlow/Town12_Rep0_4138_4_route0_11_08_00_53_01", f"{CARLA_GARAGE_DATA}/YieldToEmergencyVehicle/Town13_Rep0_1391_4_route0_11_08_22_18_17", f"{CARLA_GARAGE_DATA}/DynamicObjectCrossing/Town10_Rep0_Town10HD_Scenario3_12_route0_11_09_02_30_09", f"{CARLA_GARAGE_DATA}/StaticCutIn/Town13_Rep0_1705_1_route0_11_08_00_24_45", f"{CARLA_GARAGE_DATA}/SignalizedJunctionRightTurn/Town04_Rep0_Town04_Scenario9_21_route0_11_09_11_50_19", f"{CARLA_GARAGE_DATA}/Accident/Town12_Rep0_2226_0_route0_11_09_06_57_17", f"{CARLA_GARAGE_DATA}/SignalizedJunctionRightTurn/Town05_Rep0_Town05_Scenario9_156_route0_11_09_05_30_30", f"{CARLA_GARAGE_DATA}/SignalizedJunctionLeftTurn/Town13_Rep0_1235_2_route0_11_08_12_58_15", f"{CARLA_GARAGE_DATA}/SignalizedJunctionLeftTurn/Town10_Rep0_Town10HD_Scenario7_11_route0_11_08_21_16_22", f"{CARLA_GARAGE_DATA}/ConstructionObstacle/Town13_Rep0_66_2_route0_11_09_02_42_14", f"{CARLA_GARAGE_DATA}/VehicleTurningRoute/Town01_Rep0_Town01_Scenario4_31_route0_11_08_09_37_44", f"{CARLA_GARAGE_DATA}/SignalizedJunctionRightTurn/Town03_Rep0_Town03_Scenario9_66_route0_11_09_06_22_44", f"{CARLA_GARAGE_DATA}/HighwayExit/Town12_Rep0_964_1_route0_11_09_02_52_26", f"{CARLA_GARAGE_DATA}/HazardAtSideLane/Town13_Rep0_1710_2_route0_11_09_02_52_27", f"{CARLA_GARAGE_DATA}/DynamicObjectCrossing/Town13_Rep0_1752_0_route0_11_08_11_14_06", f"{CARLA_GARAGE_DATA}/SignalizedJunctionRightTurn/Town13_Rep0_1072_1_route0_11_09_06_38_13", f"{CARLA_GARAGE_DATA}/Accident/Town13_Rep0_1073_0_route0_11_08_11_52_59", f"{CARLA_GARAGE_DATA}/SignalizedJunctionRightTurn/Town13_Rep0_2_1_route0_11_08_03_30_17", f"{CARLA_GARAGE_DATA}/PriorityAtJunction/Town13_Rep0_1095_0_route0_11_08_14_19_22", f"{CARLA_GARAGE_DATA}/BlockedIntersection/Town13_Rep0_1443_0_route0_11_08_06_24_34", f"{CARLA_GARAGE_DATA}/VehicleOpensDoorTwoWays/Town12_Rep0_4175_0_route0_11_09_11_37_18", f"{CARLA_GARAGE_DATA}/VehicleTurningRoute/Town13_Rep0_1167_0_route0_11_09_11_27_37", f"{CARLA_GARAGE_DATA}/HighwayCutIn/Town13_Rep0_1586_14_route0_11_08_18_56_50", f"{CARLA_GARAGE_DATA}/NonSignalizedJunctionLeftTurn/Town13_Rep0_1523_0_route0_11_08_21_36_09", f"{CARLA_GARAGE_DATA}/Accident/Town13_Rep0_1272_2_route0_11_08_04_45_24", f"{CARLA_GARAGE_DATA}/InterurbanActorFlow/Town13_Rep0_1304_22_route0_11_08_02_58_26", f"{CARLA_GARAGE_DATA}/Accident/Town12_Rep0_3990_1_route0_11_09_06_54_24", f"{CARLA_GARAGE_DATA}/VehicleTurningRoute/Town04_Rep0_Town04_Scenario4_15_route0_11_08_10_24_40", f"{CARLA_GARAGE_DATA}/InterurbanAdvancedActorFlow/Town12_Rep0_3546_7_route0_11_08_16_07_09", f"{CARLA_GARAGE_DATA}/ControlLoss/Town13_Rep0_1408_0_route0_11_08_12_19_51", f"{CARLA_GARAGE_DATA}/NonSignalizedJunctionLeftTurn/Town12_Rep0_96_0_route0_11_08_09_37_15", f"{CARLA_GARAGE_DATA}/ParkingExit/Town13_Rep0_99_8_route0_11_08_20_47_53", f"{CARLA_GARAGE_DATA}/HazardAtSideLane/Town12_Rep0_3124_3_route0_11_09_12_01_05", f"{CARLA_GARAGE_DATA}/NonSignalizedJunctionLeftTurn/Town13_Rep0_1354_0_route0_11_08_12_30_49", f"{CARLA_GARAGE_DATA}/SignalizedJunctionRightTurn/Town05_Rep0_Town05_Scenario9_23_route0_11_08_23_22_13", f"{CARLA_GARAGE_DATA}/SignalizedJunctionLeftTurn/Town05_Rep0_Town05_Scenario7_116_route0_11_09_06_21_11", f"{CARLA_GARAGE_DATA}/VehicleTurningRoutePedestrian/Town13_Rep0_1219_1_route0_11_08_15_48_38", f"{CARLA_GARAGE_DATA}/Accident/Town13_Rep0_1224_2_route0_11_09_10_32_52", f"{CARLA_GARAGE_DATA}/MergerIntoSlowTraffic/Town13_Rep0_1230_4_route0_11_08_11_21_47", f"{CARLA_GARAGE_DATA}/ControlLoss/Town10_Rep0_Town10HD_Scenario1_3_route0_11_08_03_16_51", f"{CARLA_GARAGE_DATA}/OppositeVehicleRunningRedLight/Town13_Rep0_1047_2_route0_11_08_02_51_02", f"{CARLA_GARAGE_DATA}/OppositeVehicleRunningRedLight/Town12_Rep0_3921_0_route0_11_09_07_31_47", f"{CARLA_GARAGE_DATA}/SignalizedJunctionRightTurn/Town05_Rep0_Town05_Scenario9_177_route0_11_08_12_48_58", f"{CARLA_GARAGE_DATA}/SignalizedJunctionRightTurn/Town12_Rep0_3866_0_route0_11_09_03_07_52", f"{CARLA_GARAGE_DATA}/InterurbanAdvancedActorFlow/Town12_Rep0_417_7_route0_11_08_15_11_23"
				

				# Additional explicit folders may be added here.
			]

		if setting == 'all':
			pass
		elif setting == '12_only':
			self.val_towns.extend([1, 2, 3, 4, 5, 6, 7, 10, 11, 13, 15])
			
		# Sampled Validation Mode
		elif setting == 'sampled_val':
			self.use_sampled_val = True
			self.sampled_val_dirs = [
				f"{CARLA_GARAGE_DATA}/AccidentTwoWays/Town12_Rep0_26_0_route0_11_08_18_12_42",
				f"{CARLA_GARAGE_DATA}/ConstructionObstacleTwoWays/Town12_Rep0_406_0_route0_11_08_18_28_38",
				f"{CARLA_GARAGE_DATA}/ControlLoss/Town01_Rep0_Town01_Scenario1_0_route0_11_08_09_42_02",
				f"{CARLA_GARAGE_DATA}/EnterActorFlowV2/Town12_Rep0_975_0_route0_11_08_03_02_20",
				f"{CARLA_GARAGE_DATA}/MergerIntoSlowTrafficV2/Town12_Rep0_968_0_route0_11_08_11_46_58",
				f"{CARLA_GARAGE_DATA}/NonSignalizedJunctionLeftTurn",
				f"{CARLA_GARAGE_DATA}/OppositeVehicleRunningRedLight",
				f"{CARLA_GARAGE_DATA}/SignalizedJunctionLeftTurn",
				f"{CARLA_GARAGE_DATA}/VehicleOpensDoorTwoWays",
				f"{CARLA_GARAGE_DATA}/YieldToEmergencyVehicle"
			]
		elif setting == 'eval':
			return
		else:
			raise ValueError(f'Error: Selected setting: {setting} does not exist.')

		print('Setting:', setting)
		
		self.data_roots = []
		for td_path in self.root_dir:
			if os.path.exists(td_path):
				self.data_roots = self.data_roots + [
					os.path.join(td_path, name) 
					for name in os.listdir(td_path) 
					if os.path.isdir(os.path.join(td_path, name))
				]
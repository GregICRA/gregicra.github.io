import os
import requests
import time
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Normal
import io
import sys
from dotenv import load_dotenv

load_dotenv()

from Greg.model import Greg, Critic, ForwardModel
from Greg.config import GlobalConfig
from collections import OrderedDict
import copy

MASTER_IP = os.environ["MASTER_IP"]  # set in .env
MASTER_PORT = int(os.environ.get('DATA_SERVER_PORT', 34543)) # must match GREG_RL_Trainer's data_server.py
BATCH_UPLOAD_SIZE = 100
RETRY_DELAY = 5
POLICY_UPDATE_INTERVAL = 15

# must match the learner's config
STATE_DIM = 640
ACTION_DIM = 2

IL_CHECKPOINT = os.environ.get("GREG_IL_CKPT", "log/greg/last.ckpt")  # IL warm-start checkpoint
ORIGINAL = True

def update_policy_from_master(worker_id, actor_model, master_weights_url):
    while True:
        try:
            response = requests.get(master_weights_url, timeout=5)
            response.raise_for_status()

            weights = torch.load(io.BytesIO(response.content), map_location=torch.device('cpu'))
            actor_model.load_state_dict(weights)
            print(f"✅ [Worker {worker_id}] Policy updated successfully.")
            break
        except requests.exceptions.RequestException:
            pass  # common at startup before the learner has saved a model yet
        except Exception as e:
            print(f"❌ [Worker {worker_id}] Error loading downloaded model: {e}")

def send_batch_to_master(worker_id, batch, master_url):
    payload = [
        {"state":s.tolist(),"action":a.tolist(),"reward":r,"next_state":ns.tolist(),"done":d}
        for s, a, r, ns, d in batch
    ]
    print()
    while True:
        try:
            requests.post(master_url, json=payload, timeout=10).raise_for_status()
            return
        except requests.exceptions.RequestException as e:
            print(f"⚠️ [Worker {worker_id}] Could not send batch to master ({e}). Retrying in {RETRY_DELAY}s...")
            time.sleep(RETRY_DELAY)

def run_worker(worker_id: int, master_ip: str):
    master_batch_url = f"http://{master_ip}:{MASTER_PORT}/add_batch/"
    master_weights_url = f"http://{master_ip}:{MASTER_PORT}/get_latest_weights/"
    print(f"🤖 [Worker {worker_id}] Started. Master at {master_ip}:{MASTER_PORT}")

    config = GlobalConfig()
    actor = Greg(config)
    actor.cuda()
    actor.eval()

    local_buffer = []
    state = np.random.randn(STATE_DIM).astype(np.float32)
    last_policy_update = 0

    while True:
        if time.time() - last_policy_update > POLICY_UPDATE_INTERVAL:
            update_policy_from_master(worker_id, actor, master_weights_url)
            last_policy_update = time.time()

        state_tensor = torch.FloatTensor(state).unsqueeze(0).cuda()
        action, _= actor.sample(state_tensor)
        action = action.detach().cpu().numpy().flatten()

        # fake random env transition -- no real CARLA rollout in this worker
        next_state = np.random.randn(STATE_DIM).astype(np.float32)
        reward = float(np.random.randn())
        is_terminal = np.random.rand() < 0.01

        local_buffer.append((state, action, reward, next_state, is_terminal))

        state = next_state
        if is_terminal:
            state = np.random.randn(STATE_DIM).astype(np.float32)

        if len(local_buffer) >= BATCH_UPLOAD_SIZE:
            send_batch_to_master(worker_id, local_buffer, master_batch_url)
            local_buffer.clear()

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python worker.py <worker_id> <master_ip>")
        sys.exit(1)
        
    worker_id = int(sys.argv[1])
    master_ip = sys.argv[2]
    run_worker(worker_id, master_ip)


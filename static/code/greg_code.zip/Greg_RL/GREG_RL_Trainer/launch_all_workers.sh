#!/bin/bash
nvidia-cuda-mps-control -d
# launches N worker supervisors in the background

if [ -z "$1" ]; then
    echo "Usage: ./launch_all_workers.sh <NUM_WORKERS>"
    echo "Example: ./launch_all_workers.sh 4"
    exit 1
fi

NUM_WORKERS=$1
LOG_DIR="GREG_RL_Trainer/logs"
SUPERVISOR_SCRIPT="./GREG_RL_Trainer/run_worker.sh" # run from Greg_RL/ (parent of GREG_RL_Trainer)

mkdir -p "$LOG_DIR"
echo "$NUM_WORKERS" > "number.txt"  # each benchmark_runner.sh reads this for the total instance count

echo "🚀 Launching ${NUM_WORKERS} worker supervisors..."

for i in $(seq 1 $NUM_WORKERS); do
    WORKER_ID=$i
    LOG_FILE="${LOG_DIR}/worker_${WORKER_ID}_supervisor.log"
    
    echo "   -> Starting supervisor for Worker ${WORKER_ID}. Log file: ${LOG_FILE}"

    nohup "$SUPERVISOR_SCRIPT" "$WORKER_ID" > "$LOG_FILE" 2>&1 &
done

echo "✅ All worker supervisors have been launched in the background."
echo "You can monitor their individual logs in the '${LOG_DIR}' directory."
echo "   Example: tail -f logs/worker_1_supervisor.log"
echo "To see the status of running supervisor processes, use: pgrep -f run_worker.sh"
echo "To stop all supervisors and their child processes, use: pkill -f run_worker.sh"


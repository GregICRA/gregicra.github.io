import os
import subprocess
import time
from datetime import datetime
import schedule
import wandb
from dotenv import load_dotenv

load_dotenv()

# W&B run to read back; set in .env.
HARDCODED_RUN_ID = os.environ.get("WANDB_RUN_ID") or None
wandb.login(key=os.environ.get("WANDB_API_KEY"))


TIME_FORMAT = '%Y-%m-%d-%H-%M'
START_TIME_FILE = 'GREG_RL_Trainer/start_time.txt'

def save_current_time(file_path, time_format):
    now = datetime.now()
    formatted_time = now.strftime(time_format)
    
    try:
        with open(file_path, 'w') as f:
            f.write(formatted_time)
        print(f"Successfully saved start time to '{file_path}': {formatted_time}")
    except IOError as e:
        print(f"Error: Could not write to file '{file_path}'. Reason: {e}")

def get_start_time(file_path, time_format):
    try:
        with open(file_path, 'r') as f:
            time_str = f.read().strip()
            start_time = datetime.strptime(time_str, time_format)
            print(f"Successfully read start time from '{file_path}': {start_time.strftime('%Y-%m-%d %H:%M:%S')}")
            return start_time
    except FileNotFoundError:
        print(f"Warning: '{file_path}' not found. Using current time as the start time.")
    except (ValueError, IndexError):
        print(f"Warning: Could not parse the time from '{file_path}'. Using current time as the start time.")
    
    return datetime.now()  # Fallback to current time


def delete_generated_files(config, start_time_file):
    print("--- Deleting generated files ---")
    merged_path = config.get('merged_file_path')
    
    # Delete merged file
    if merged_path and os.path.exists(merged_path):
        try:
            os.remove(merged_path)
            print(f"Successfully deleted '{merged_path}'")
        except OSError as e:
            print(f"Error deleting file '{merged_path}': {e}")
    else:
        if merged_path:
            print(f"Merged file '{merged_path}' not found, skipping.")
        
    # Delete start time file
    if os.path.exists(start_time_file):
        try:
            os.remove(start_time_file)
            print(f"Successfully deleted '{start_time_file}'")
        except OSError as e:
            print(f"Error deleting file '{start_time_file}': {e}")
    else:
        print(f"Start time file '{start_time_file}' not found, skipping.")
    print("--------------------------------")

class FileSynchronizer:
    # periodically scp's files from remote servers, filters by start time, reports new data

    def __init__(self, config, run_id='temp'):
        self.config = config
        self.previously_merged_lines = self._load_initial_state()
        self.run_wandb = wandb.init(
            entity=os.environ.get("WANDB_ENTITY") or None,
            project=os.environ.get("WANDB_PROJECT", "greg-rl"),
            id=run_id,
            resume="allow",
        )

        # Ensure the local directory for downloaded files exists.
        os.makedirs(self.config['local_dir'], exist_ok=True)
        print("FileSynchronizer initialized.")
        print(f"Watching for files with timestamps after: {self.config['start_time'].strftime('%Y-%m-%d %H:%M:%S')}")

    def _load_initial_state(self):
        merged_path = self.config.get('merged_file_path')
        initial_lines = set()
        if not merged_path or not os.path.exists(merged_path):
            return initial_lines

        print(f"Loading initial state from '{merged_path}'...")
        try:
            with open(merged_path, 'r') as f:
                for line in f:
                    line = line.strip()
                    if line:
                        initial_lines.add(line)
            print(f"  -> Loaded {len(initial_lines)} existing lines.")
            return initial_lines
        except IOError as e:
            print(f"Warning: Could not read initial state from '{merged_path}'. Starting fresh. Reason: {e}")
            return set()

    def _read_password(self, password_file):
        try:
            with open(password_file, 'r') as f:
                return f.read().strip()
        except FileNotFoundError:
            print(f"Error: Password file not found at '{password_file}'")
            return None
        except Exception as e:
            print(f"An error occurred while reading the password file '{password_file}': {e}")
            return None

    def _download_files_from_server(self, server_config, password):
        # SECURITY WARNING: sshpass is less secure than SSH keys; prefer passwordless key auth
        remote_user = server_config['user']
        remote_host = server_config['host']
        remote_path = server_config['path']

        # unique local filename to prevent overwrites, e.g. "10.0.0.1_DS.txt"
        base_filename = os.path.basename(remote_path)
        local_filename = f"{remote_host}_{base_filename}"
        local_filepath = os.path.join(self.config['local_dir'], local_filename)

        print(f"Attempting to download file from {remote_user}@{remote_host} to {local_filepath}...")

        # The command uses sshpass to provide the password to scp.
        command = [
            'sshpass',
            '-p', password,
            'scp',
            # This option automatically adds new host keys. Use with caution.
            '-o', 'StrictHostKeyChecking=no',
            f"{remote_user}@{remote_host}:{remote_path}",
            local_filepath  # Destination is the uniquely named file path
        ]

        try:
            subprocess.run(command, check=True, capture_output=True, text=True, timeout=30)
            print(f"  -> Download from {remote_host} successful.")
            return True
        except FileNotFoundError:
            print("Error: 'sshpass' command not found. Please install it on your system.")
            print("  (e.g., 'sudo apt-get install sshpass' or 'brew install sshpass')")
            return False
        except subprocess.TimeoutExpired:
            print(f"Error: Download from {remote_host} timed out. Skipping.")
            return False
        except subprocess.CalledProcessError as e:
            print(f"Error during file download from {remote_host}.")
            print(f"  Return code: {e.returncode}")
            print(f"  Stderr: {e.stderr.strip()}")
            return False
            
    def _download_from_all_servers(self):
        all_successful = True
        for server in self.config['servers']:
            password = self._read_password(server['password_file'])
            if not password:
                print(f"Could not read password for {server['host']}. Skipping.")
                all_successful = False
                continue

            if not self._download_files_from_server(server, password):
                all_successful = False
        return all_successful

    def _merge_and_filter(self):
        valid_lines = set()
        print(f"Processing files in '{self.config['local_dir']}'...")

        for filename in os.listdir(self.config['local_dir']):
            filepath = os.path.join(self.config['local_dir'], filename)
            if os.path.isfile(filepath):
                with open(filepath, 'r') as f:
                    for line in f:
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            parts = line.split(' | ')
                            if len(parts) >= 4:
                                timestamp_str = parts[-1]
                                line_dt = datetime.strptime(timestamp_str, '%Y-%m-%d-%H-%M')

                                if line_dt > self.config['start_time']:
                                    if float(parts[0]) > 0.00001 and len(parts) > 3:
                                        valid_lines.add(line)
                            
                        except (ValueError, IndexError):
                            print(f"  - Skipping line with invalid format in {filename}: {line}")
        return valid_lines

    def _save_merged_file(self, lines_to_save):
        merged_path = self.config.get('merged_file_path')
        if not merged_path:
            print("Warning: 'merged_file_path' not defined in config. Skipping save.")
            return

        print(f"Saving {len(lines_to_save)} total lines to '{merged_path}'...")
        
        sorted_lines = []
        try:
            # sort by the timestamp in the last column
            sorted_lines = sorted(
                list(lines_to_save),
                key=lambda line: datetime.strptime(line.split(' | ')[-1], TIME_FORMAT)
            )
        except (IndexError, ValueError) as e:
            print(f"Warning: Could not sort lines by time due to a format error: {e}. Writing with default sort.")
            sorted_lines = sorted(list(lines_to_save))  # fallback: alphabetical

        try:
            with open(merged_path, 'w') as f:
                for line in sorted_lines:
                    f.write(line + '\n')
            print("  -> Merged file saved successfully.")
        except IOError as e:
            print(f"Error: Could not write to merged file at '{merged_path}'. Reason: {e}")


    def run_task(self):
        print(f"\n--- Running task at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} ---")

        if not self._download_from_all_servers():
            print("Aborting task due to download failure(s), but will try again next cycle.")

        downloaded_lines = self._merge_and_filter()
        new_lines = downloaded_lines - self.previously_merged_lines

        print(f"Task complete. Found {len(new_lines)} new elements.")
        if new_lines:
            print("--- New Data ---")
            for line in sorted(list(new_lines)):
                line_list = line.strip().split(' | ')
                if float(line_list[0]) < 0.00001:
                    continue
                timestamp_str = line_list[-1]
                line_dt = datetime.strptime(timestamp_str, TIME_FORMAT)

                # line_dt is logged alongside metrics so wandb uses it for the x-axis
                self.run_wandb.log({
                    "Driving/score_route": float(line_list[0]),
                    "Driving/score_penalty": float(line_list[1]),
                    "Driving/score_composed": float(line_list[2]),
                    "Driving/driving_time": float(line_list[3]),
                    "Driving/event_time": line_dt
                })
                print(line)
            print("----------------")

        all_lines = self.previously_merged_lines.union(new_lines)
        self._save_merged_file(all_lines)
        self.previously_merged_lines = all_lines

    def start(self):
        print("Starting the scheduler. The task will run once immediately, then every 120 seconds.")
        self.run_task()
        schedule.every(self.config['interval_seconds']).seconds.do(self.run_task)

        while True:
            schedule.run_pending()
            time.sleep(1)


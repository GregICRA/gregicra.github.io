import torch
import torch.nn as nn
import torch.nn.functional as F

from collections import deque
# Actor-Critic Model
import numpy as np
import torch
import torch.nn as nn
import torch.nn.init as init
import torch.distributions as D

from torch.special import digamma, log_softmax

def beta_distribution_entropy(alpha, beta):
    """
    Calculates the exact entropy of a Beta distribution using the digamma function.

    Args:
        alpha: The alpha parameter of the Beta distribution (tensor).
        beta: The beta parameter of the Beta distribution (tensor).

    Returns:
        The entropy of the Beta distribution (tensor).
    """
    log_beta = torch.lgamma(alpha) + torch.lgamma(beta) - torch.lgamma(alpha + beta)
    entropy = (
        log_beta
        - (alpha - 1) * digamma(alpha)
        - (beta - 1) * digamma(beta)
        + (alpha + beta - 2) * digamma(alpha + beta)
    )
    return entropy




class Value(nn.Module):
    def __init__(self, state_dim, hidden_dim=256):
        super(Value, self).__init__()
        

        # Run init routine
        self._init_weights()



        self.fc1 = nn.Linear(state_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.fc3 = nn.Linear(hidden_dim, hidden_dim)
        self.fc4 = nn.Linear(hidden_dim, hidden_dim)
        self.fc5 = nn.Linear(hidden_dim, 1)
        self.relu = nn.LeakyReLU(negative_slope=0.01)

        nn.init.orthogonal_(self.fc1.weight, np.sqrt(2))
        nn.init.zeros_(self.fc1.bias)
        nn.init.orthogonal_(self.fc2.weight, np.sqrt(2))
        nn.init.zeros_(self.fc2.bias)
        nn.init.orthogonal_(self.fc3.weight, np.sqrt(2))
        nn.init.zeros_(self.fc3.bias)
        nn.init.orthogonal_(self.fc4.weight, np.sqrt(2))
        nn.init.zeros_(self.fc4.bias)
        nn.init.orthogonal_(self.fc5.weight, 1.0)
        nn.init.zeros_(self.fc5.bias)

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                # orthogonal initialization with gain (= std) = 1.0
                nn.init.orthogonal_(m.weight, np.sqrt(2))
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    def forward(self, state):
    

        x = self.relu(self.fc1(state))
        x = self.relu(self.fc2(x))
        x = self.relu(self.fc3(x))
        x = self.relu(self.fc4(x))
        x = self.fc5(x)
        return x
    def get_value(self, state):
        return self.forward(state)

class EnvironmentModelVAE(nn.Module):
    """
    This model predicts:
      - Delta: the difference between the actual next state and the last state.
      - Reward: a scalar value.
      - Final predictions: the next state (directly) and reward from additional heads.
    
    Architecture:
      - A transformer encoder processes the state sequence.
      - A transformer decoder uses the action (projected into a query) to attend over the encoder outputs.
      - A VAE bottleneck maps the decoder output to latent distribution parameters (mu and logvar), from which a latent vector is sampled.
      - Two VAE decoders:
           * Delta branch: predicts the state delta.
           * Reward branch: predicts the reward.
      - Additional final heads directly predict the next state and reward.
      
    Note: The last state is extracted from the input sequence.
    """
    def __init__(self, seq_length, state_dim, action_dim, hidden_dim=128, d_model=256, latent_dim=64):
        super(EnvironmentModelVAE, self).__init__()
        # Transformer Encoder for the state sequence.
        self.encoder = TimeSeriesTransformer(
            seq_len=seq_length,
            feature_dim=state_dim,
            d_model=d_model,
            nhead=8,
            num_layers=3,
            dim_feedforward=256,
            out_dim=d_model  # Ensures compatibility with the decoder.
        )
        # Map the action into a query for the decoder.
        self.fc_action = nn.Linear(action_dim, d_model)
        self.state_dim = state_dim
        # Transformer Decoder: uses the action as a query to attend over encoder outputs.
        decoder_layer = nn.TransformerDecoderLayer(d_model=d_model, nhead=8, dim_feedforward=256)
        self.decoder = nn.TransformerDecoder(decoder_layer, num_layers=3)
        
        # VAE bottleneck: map decoder output to latent distribution parameters.
        self.fc_mu = nn.Linear(d_model, latent_dim)
        self.fc_logvar = nn.Linear(d_model, latent_dim)
        
        # VAE decoder for delta prediction.
        self.fc_delta1 = nn.Linear(latent_dim, hidden_dim)
        self.fc_delta2 = nn.Linear(hidden_dim, hidden_dim)
        self.delta_head = nn.Linear(hidden_dim, state_dim)
        
        # VAE decoder for reward prediction.
        self.fc_reward1 = nn.Linear(latent_dim, hidden_dim)
        self.fc_reward2 = nn.Linear(hidden_dim, hidden_dim)
        self.reward_head = nn.Linear(hidden_dim, 1)
        
        # Additional final heads:
        # This head directly predicts the next state from the latent vector and the last state.
        self.next_state_head = nn.Sequential(
            nn.Linear(latent_dim + state_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, state_dim)
        )
        # This head directly predicts the reward from the latent vector.
        self.final_reward_head = nn.Sequential(
            nn.Linear(latent_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1)
        )
    
    def reparameterize(self, mu, logvar):
        """Reparameterization trick: sample z from N(mu, sigma)."""
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std
    
    def forward(self, state_seq, action):
        """
        Args:
            state_seq: Tensor of shape (batch_size, seq_length, state_dim)
            action: Tensor of shape (batch_size, action_dim)
        Returns:
            delta: Predicted delta (next_state - last_state) from the VAE branch.
            reward: Predicted reward from the VAE branch.
            final_next_state: Directly predicted next state from the additional head.
            final_reward: Directly predicted reward from the additional head.
            mu, logvar: Latent distribution parameters.
        """
        # --- Encoder ---
        state_seq = state_seq.reshape(state_seq.shape[0],-1, self.state_dim)
        encoder_output = self.encoder(state_seq)
        # If the encoder aggregates the sequence to a single embedding, ensure it has a sequence dimension.
        if encoder_output.dim() == 2:
            encoder_output = encoder_output.unsqueeze(1)  # (batch_size, 1, d_model)
        # Transformer expects memory shape: (source_seq_length, batch_size, d_model)
        memory = encoder_output.transpose(0, 1)
        
        # --- Decoder ---
        # Map the action to a query vector.
        query = self.fc_action(action).unsqueeze(0)  # (1, batch_size, d_model)
        decoder_output = self.decoder(query, memory)   # (1, batch_size, d_model)
        decoder_output = decoder_output.squeeze(0)       # (batch_size, d_model)
        
        # --- VAE Bottleneck ---
        mu = self.fc_mu(decoder_output)       # (batch_size, latent_dim)
        logvar = self.fc_logvar(decoder_output) # (batch_size, latent_dim)
        z = self.reparameterize(mu, logvar)     # (batch_size, latent_dim)
        
        # --- Delta Branch (VAE-based) ---
        x_delta = F.relu(self.fc_delta1(z))
        x_delta = F.relu(self.fc_delta2(x_delta))
        delta = self.delta_head(x_delta)
        
        # --- Reward Branch (VAE-based) ---
        x_reward = F.relu(self.fc_reward1(z))
        x_reward = F.relu(self.fc_reward2(x_reward))
        reward = self.reward_head(x_reward)
        
        # --- Additional Final Heads ---
        # Extract the last state from the input sequence.
        last_state = state_seq[:, -1, :]  # (batch_size, state_dim)
        # Directly predict the next state from the latent vector and the last state.
        final_next_state = self.next_state_head(torch.cat([z, last_state], dim=-1))
        # Directly predict reward from the latent vector.
        final_reward = self.final_reward_head(z)
        
        return delta, reward, final_next_state, final_reward, mu, logvar
    
    def get_env_next(self, state_seq, action):
        delta, reward, final_next_state, final_reward, mu, logvar = self.forward(state_seq, action)
        return final_next_state, final_reward

    def compute_loss(self, predicted_delta, actual_delta, predicted_reward, actual_reward,
                 final_next_state, actual_next_state, final_reward, 
                 mu, logvar, reward_weight=1.0, final_state_weight=1.0, final_reward_weight=1.0):
        """
        Computes the overall loss, which includes:
        - Delta reconstruction loss (MSE between predicted and actual delta).
        - Reward reconstruction loss for the VAE branch (Huber loss).
        - Final next-state reconstruction loss (MSE between predicted and actual next state).
        - Final reward reconstruction loss for the final head (Huber loss).
        - KL divergence loss from the VAE.
        
        Args:
            predicted_delta: Tensor (batch_size, state_dim) from the delta branch.
            actual_delta: Tensor (batch_size, state_dim) representing (next_state - last_state).
            predicted_reward: Tensor (batch_size, 1) from the reward branch.
            actual_reward: Tensor (batch_size, 1)
            final_next_state: Tensor (batch_size, state_dim) from the additional head.
            actual_next_state: Tensor (batch_size, state_dim) representing the actual next state.
            final_reward: Tensor (batch_size, 1) from the additional head.
            mu, logvar: Latent distribution parameters.
            reward_weight: Weight for the reward reconstruction loss (VAE branch).
            final_state_weight: Weight for the final next-state reconstruction loss.
            final_reward_weight: Weight for the final reward reconstruction loss.
        Returns:
            loss: Total loss.
            delta_loss: MSE loss for delta prediction.
            reward_loss: Huber loss for reward prediction (VAE branch).
            final_state_loss: MSE loss for final next state prediction.
            final_reward_loss: Huber loss for final reward prediction.
            kl_loss: KL divergence loss.
        """
        # Delta reconstruction loss using MSE.
        delta_loss = F.mse_loss(predicted_delta, actual_delta)
        
        # Reward reconstruction losses using Huber (smooth L1) loss.
        reward_loss = F.smooth_l1_loss(predicted_reward, actual_reward)
        final_reward_loss = F.smooth_l1_loss(final_reward, actual_reward)
        
        # Final next-state reconstruction loss using MSE.
        final_state_loss = F.mse_loss(final_next_state, actual_next_state)
        
        # KL divergence loss.
        kl_loss = -0.5 * torch.mean(1 + logvar - mu.pow(2) - logvar.exp())
        
        # Combine losses.
        loss = delta_loss + reward_weight * reward_loss + kl_loss
        loss += final_state_weight * final_state_loss + final_reward_weight * final_reward_loss
        
        return loss, delta_loss, reward_loss, final_state_loss, final_reward_loss, kl_loss

    
class EnvironmentModel(nn.Module):
    """
    This network takes a sequence of states and an action and outputs:
      - a predicted next state (of dimension state_dim)
      - a predicted reward (scalar)
    
    The architecture consists of:
      - An encoder that processes the state sequence.
      - A decoder that uses a learned embedding of the action as a query to attend over the encoded states.
      - Final fully connected layers to predict the outputs.
    """
    def __init__(self, seq_length, state_dim, action_dim, hidden_dim=128, d_model=256):
        super(EnvironmentModel, self).__init__()
        # Transformer Encoder for the state sequence.
        # Ensure that the encoder outputs a feature dimension equal to d_model.
        self.encoder = TimeSeriesTransformer(
            seq_len=seq_length,
            feature_dim=state_dim,
            d_model=d_model,
            nhead=8,
            num_layers=3,
            dim_feedforward=256,
            out_dim=d_model  # set out_dim to match d_model for compatibility with the decoder
        )
        # Map the action into a query token for the decoder.
        self.fc_action = nn.Linear(action_dim, d_model)
        self.state_dim = state_dim
        # Transformer Decoder: it will attend over the encoder outputs.
        decoder_layer = nn.TransformerDecoderLayer(d_model=d_model, nhead=8, dim_feedforward=256)
        self.decoder = nn.TransformerDecoder(decoder_layer, num_layers=3)
        
        # Final processing layers.
        self.fc1 = nn.Linear(d_model, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.state_head = nn.Linear(hidden_dim, state_dim)
        self.reward_head = nn.Linear(hidden_dim, 1)

    def forward(self, state_seq, action):
        """
        Args:
            state_seq: Tensor of shape (batch_size, seq_length, state_dim)
            action: Tensor of shape (batch_size, action_dim)
        Returns:
            next_state: Tensor of shape (batch_size, state_dim)
            reward: Tensor of shape (batch_size, 1)
        """
        # --- Encoder ---
        # Process the state sequence.
        # The encoder is assumed to return a tensor of shape (batch_size, seq_length, d_model).
        x = state_seq.reshape(state_seq.shape[0],-1, self.state_dim)
        encoder_output = self.encoder.get_seq_env(x)
        # Transformer modules expect the memory in shape (seq_length, batch_size, d_model).
        memory = encoder_output.transpose(0, 1)
        
        # --- Decoder ---
        # Use the action to form a query for the decoder.
        # Map action into d_model dimension and add a sequence dimension.
        query = self.fc_action(action).unsqueeze(0)  # shape: (1, batch_size, d_model)
        # The decoder will attend to the encoder outputs (memory) using the query.
        decoder_output = self.decoder(query, memory)  # shape: (1, batch_size, d_model)
        decoder_output = decoder_output.squeeze(0)      # shape: (batch_size, d_model)
        
        # --- Prediction Heads ---
        # Process the decoder's output through fully connected layers.
        x = F.relu(self.fc1(decoder_output))
        x = F.relu(self.fc2(x))
        next_state = self.state_head(x)
        reward = self.reward_head(x)
        
        return next_state, reward


class ForwardModel(nn.Module):
    def __init__(self, state_dim, action_dim, hidden_dim=128):
        super(ForwardModel, self).__init__()
        self.gru = nn.GRU(input_size=state_dim, hidden_size=128, num_layers=2, batch_first=True, bidirectional=True)
        self.batch_norm = nn.BatchNorm1d(state_dim)
        self.fc1 = nn.Linear(4*128, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim+64, hidden_dim)
        self.fc_action = nn.Linear(action_dim, 64)
        self.fc_out = nn.Linear(hidden_dim, state_dim)
        self.state_dim = state_dim
        self.relu = nn.LeakyReLU(negative_slope=0.01)


        # Initialize weights and biases to zero
        
        nn.init.xavier_uniform_(self.fc1.weight)
        nn.init.zeros_(self.fc1.bias)
        nn.init.xavier_uniform_(self.fc2.weight)
        nn.init.zeros_(self.fc2.bias)
        nn.init.xavier_uniform_(self.fc_out.weight)
        nn.init.zeros_(self.fc_out.bias)
        nn.init.xavier_uniform_(self.fc_action.weight)
        nn.init.zeros_(self.fc_action.bias)
        # Log standard deviation (learned parameter)
        self.log_std = nn.Parameter(torch.zeros(action_dim))

        for name, param in self.gru.named_parameters():
            if "weight_ih" in name:  # Input-to-hidden weights
                init.xavier_uniform_(param)
            elif "weight_hh" in name:  # Hidden-to-hidden weights
                init.xavier_uniform_(param)
            elif "bias" in name:  # Biases
                init.zeros_(param)
    def forward(self, state, action):

        x = state.reshape(state.shape[0],-1, self.state_dim)
        '''
        batch_size, seq_len, feature_dim = x.size()
        x = x.view(-1, feature_dim)
        x = self.batch_norm(x)
        x = x.view(batch_size, seq_len, feature_dim)
        '''
        gru_output, hgru = self.gru(x)
        action = self.relu(self.fc_action(action))
        x = self.relu(hgru.permute(1,0,2).reshape(hgru.shape[1],-1))
        x = self.relu(self.fc1(x))
        x = torch.cat([x, action], dim=-1)
        x = self.relu(self.fc2(x))
        next_state_pred = self.fc_out(x)
        return next_state_pred



class Actor(nn.Module):
    def __init__(self, state_dim, action_dim, hidden_dim=128):
        super(Actor, self).__init__()
        self.gru = nn.GRU(input_size=state_dim, hidden_size=128, num_layers=2, batch_first=True, bidirectional=True)
        self.fc1 = nn.Linear(4*128, hidden_dim)
        self.batch_norm = nn.BatchNorm1d(state_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.fc_mean = nn.Linear(hidden_dim, action_dim)
        self.fc_log_std = nn.Linear(hidden_dim, action_dim)
        self.state_dim = state_dim
        self.relu = nn.LeakyReLU(negative_slope=0.01)


        nn.init.orthogonal_(self.fc1.weight, np.sqrt(2))
        nn.init.zeros_(self.fc1.bias)
        nn.init.orthogonal_(self.fc2.weight, np.sqrt(2))
        nn.init.zeros_(self.fc2.bias)
        nn.init.orthogonal_(self.fc_mean.weight, 0.01)
        nn.init.zeros_(self.fc_mean.bias)
        nn.init.zeros_(self.fc_log_std.weight)
        nn.init.constant_(self.fc_log_std.bias, -1)
        
        

        for name, param in self.gru.named_parameters():
            if "weight_ih" in name:  # Input-to-hidden weights
                nn.init.xavier_uniform_(param)
            elif "weight_hh" in name:  # Hidden-to-hidden weights
                nn.init.orthogonal_(param, np.sqrt(2))  # Orthogonal initialization is better for recurrent weights
            elif "bias" in name:  # Bias terms
                nn.init.zeros_(param)


    def forward(self, state):
        x = state.reshape(state.shape[0],-1, self.state_dim)
        '''
        batch_size, seq_len, feature_dim = x.size()
        x = x.view(-1, feature_dim)
        x = self.batch_norm(x)
        x = x.view(batch_size, seq_len, feature_dim)
        '''
        gru_output, hgru = self.gru(x)
        x = self.relu(hgru.permute(1,0,2).reshape(hgru.shape[1],-1))
        x = self.relu(self.fc1(x))
        x = self.relu(self.fc2(x))
        mean = self.fc_mean(x)
        log_std = self.fc_log_std(x)
        log_std = torch.clamp(log_std, -20, 2)  # Prevent extreme std
        if mean.shape[0]<2:
            print('abababababababababababababab', mean.detach().cpu())
            print('abababababababababababababab', torch.exp(log_std).detach().cpu())
        return mean, log_std

    def get_action(self, state, log_prob=False):
        mean, log_std = self.forward(state)
        std = torch.exp(log_std)
        dist = torch.distributions.Normal(mean, std)
        action = dist.rsample()  # Reparameterization trick
        log_prob_val = dist.log_prob(action).sum(dim=-1) if log_prob else None
        action = torch.tanh(action)  # Squash to (-1, 1)
        if log_prob:
            log_prob_val -= torch.log(1 - action.pow(2) + 1e-6).sum(dim=-1)  # Adjust log_prob for tanh
        return (action, log_prob_val) if log_prob else action

class Critic(nn.Module):
    def __init__(self, state_dim, action_dim, hidden_dim=128):
        super(Critic, self).__init__()
        self.gru = nn.GRU(input_size=state_dim, hidden_size=128, num_layers=2, batch_first=True, bidirectional=True)
        self.fc1 = nn.Linear(4*128, hidden_dim)
        self.batch_norm = nn.BatchNorm1d(state_dim)
        self.fc2 = nn.Linear(hidden_dim+16, hidden_dim)
        self.fc_action = nn.Linear(action_dim, 16)
        self.fc_out = nn.Linear(hidden_dim, 1)
        self.state_dim = state_dim
        self.relu = nn.LeakyReLU(negative_slope=0.01)


        # Initialize weights and biases to zero



        nn.init.orthogonal_(self.fc1.weight, np.sqrt(2))
        nn.init.zeros_(self.fc1.bias)
        nn.init.orthogonal_(self.fc2.weight, np.sqrt(2))
        nn.init.zeros_(self.fc2.bias)
        nn.init.orthogonal_(self.fc_action.weight, np.sqrt(2))
        nn.init.zeros_(self.fc_action.bias)
        nn.init.orthogonal_(self.fc_out.weight, 1.0)
        nn.init.zeros_(self.fc_out.bias)

        
        

        for name, param in self.gru.named_parameters():
            if "weight_ih" in name:  # Input-to-hidden weights
                nn.init.xavier_uniform_(param)
            elif "weight_hh" in name:  # Hidden-to-hidden weights
                nn.init.orthogonal_(param, np.sqrt(2))  # Orthogonal initialization is better for recurrent weights
            elif "bias" in name:  # Bias terms
                nn.init.zeros_(param)

    def forward(self, state, action):
        x = state.reshape(state.shape[0],-1, self.state_dim)
        '''
        batch_size, seq_len, feature_dim = x.size()
        x = x.view(-1, feature_dim)
        x = self.batch_norm(x)
        x = x.view(batch_size, seq_len, feature_dim)
        '''
        gru_output, hgru = self.gru(x)
        action = self.relu(self.fc_action(action))
        x = self.relu(hgru.permute(1,0,2).reshape(hgru.shape[1],-1))
        x = self.relu(self.fc1(x))
        x = torch.cat([x, action], dim=-1)
        x = self.relu(self.fc2(x))
        q_value = self.fc_out(x)
        return q_value



class ActorCritic(nn.Module):
    def __init__(self, state_dim, action_dim, hidden_dim=128, std=1):
        super(ActorCritic, self).__init__()
        # Shared layers
        self.fc1 = nn.Linear(4*128, hidden_dim)
        self.batch_norm = nn.BatchNorm1d(state_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.state_dim = state_dim
        # Policy head
        self.policy_mean0 = nn.Linear(hidden_dim, hidden_dim)
        self.policy_mean = nn.Linear(hidden_dim, action_dim)
        self.fc_log_std = nn.Linear(hidden_dim, action_dim)

        # Value head
        self.value0 = nn.Linear(hidden_dim, hidden_dim)
        self.value = nn.Linear(hidden_dim, 1)
        self.relu = nn.LeakyReLU(negative_slope=0.01)


        self.betaHead = BetaMDNPolicy(hidden_dim, action_dim, num_mixtures=3)

        self.pre_train_head = nn.Linear(hidden_dim, action_dim)

        self.trans_enc =  TimeSeriesTransformer(
            seq_len=45,
            feature_dim=state_dim,
            d_model=256,
            nhead=8,
            num_layers=3,
            dim_feedforward=256,
            out_dim=128
        )
        
        nn.init.constant_(self.batch_norm.weight, 0.0)
        nn.init.constant_(self.batch_norm.bias, 1.0)
        nn.init.orthogonal_(self.fc1.weight, np.sqrt(2))
        nn.init.zeros_(self.fc1.bias)
        nn.init.orthogonal_(self.fc2.weight, np.sqrt(2))
        nn.init.zeros_(self.fc2.bias)
        nn.init.orthogonal_(self.policy_mean0.weight, np.sqrt(2))
        nn.init.zeros_(self.policy_mean0.bias)
        nn.init.orthogonal_(self.value0.weight, np.sqrt(2))
        nn.init.zeros_(self.value0.bias)
        nn.init.orthogonal_(self.policy_mean.weight, std)
        nn.init.zeros_(self.policy_mean.bias)
        nn.init.orthogonal_(self.value.weight, std)
        nn.init.zeros_(self.value.bias)
        


        '''
        nn.init.xavier_uniform_(self.fc1.weight)
        nn.init.zeros_(self.fc1.bias)
        nn.init.xavier_uniform_(self.fc2.weight)
        nn.init.zeros_(self.fc2.bias)
        nn.init.xavier_uniform_(self.policy_mean0.weight)
        nn.init.zeros_(self.policy_mean0.bias)
        nn.init.xavier_uniform_(self.value0.weight)
        nn.init.zeros_(self.value0.bias)
        nn.init.xavier_uniform_(self.policy_mean.weight)
        nn.init.zeros_(self.policy_mean.bias)
        nn.init.xavier_uniform_(self.value.weight)
        nn.init.zeros_(self.value.bias)
        nn.init.xavier_uniform_(self.fc_log_std.weight)
        nn.init.zeros_(self.fc_log_std.bias)
        nn.init.xavier_uniform_(self.alpha_head.weight)
        nn.init.xavier_uniform_(self.beta_head.weight)
        '''

    def forward(self, state):
        
        x = state.reshape(state.shape[0],-1, self.state_dim)
        
        '''
        batch_size, seq_len, feature_dim = x.size()
        x = x.view(-1, feature_dim)
        x = self.batch_norm(x)
        x = x.view(batch_size, seq_len, feature_dim)
        x = torch.clamp(x, -10, 10)
        '''
        '''
        gru_output, hgru = self.gru(x)
        x = self.relu(hgru.permute(1,0,2).reshape(hgru.shape[1],-1))
        x = self.relu(self.fc1(x))
        x = self.fc2(x)
        '''
        x = self.trans_enc(x)
        return x

    def get_pretrain_action(self, state):
        x = self.relu(self.forward(state))
        x = self.pre_train_head(x)
        return x


    def get_action(self, state, retrun_entropy=False, deterministic=False):
        
        '''
        alpha = torch.exp(self.alpha_head(x)) + 1.0
        beta = torch.exp(self.beta_head(x)) + 1.0
        if alpha.shape[0]<2:
            print('abababababababababababababab', alpha.detach().cpu())
            print('abababababababababababababab', beta.detach().cpu())
        
    # Adding 1 ensures beta > 1
        dist = D.Beta(alpha, beta)

        if deterministic:
            action = dist.mean  # Use mean for deterministic actions
        else:
            action = dist.sample()  # Reparameterized sampling
        #sprint(action)
        log_prob = dist.log_prob(action).sum(dim=-1)  # Log probability
        entropy = dist.entropy().sum(dim=-1)
        
        action = action *2 -1
        '''
        '''
        entropy = dist.entropy().sum(dim=-1)
        action = dist.rsample()
        log_prob = dist.log_prob(action).sum(dim=-1)
        action = torch.tanh(action)
        if not deterministic:
            log_prob -= torch.log(1 - action.pow(2) + 1e-6).sum(dim=-1)
        '''
        '''
        action = dist.sample()
        action = torch.clamp(action, -1, 1)
        log_prob = dist.log_prob(action).sum()
        entropy = dist.entropy().sum(dim=-1)
        '''
        '''
        dist = self.get_dist(state)
        action = dist.sample()
        log_prob = dist.log_prob(action).sum(dim=-1)
        entropy = dist.entropy().sum(dim=-1)
        '''
        '''
        action = dist.sample()  # rsample() for reparameterization
        
        # Log-prob of the raw action. No tanh-correction applied here!
        log_prob = dist.log_prob(action).sum(dim=-1)
        entropy = dist.entropy().sum(dim=-1)
        action = torch.tanh(action)
        '''
        x = self.relu(self.forward(state))
        action, log_prob, entropy = self.betaHead.get_action(x)
        if retrun_entropy:
            return action, log_prob, entropy
        else:
            return action, log_prob

    def log_prob(self, states, actions):
        x = self.relu(self.forward(states))
        log_prob = self.betaHead.log_prob(x, actions)
        return log_prob
        
    def entropy(self, states):
        x = self.relu(self.forward(states))
        entropyy = self.betaHead.mixture_entropy(x, n_samples=5)
        return entropyy

    def get_dist(self, state):
        
        x = self.relu(self.forward(state))
        alpha = torch.exp(self.alpha_head(x)) + 1.0
        beta = torch.exp(self.beta_head(x)) + 1.0
        
        if alpha.shape[0]<2:
            print('abababababababababababababab', alpha.detach().cpu())
            print('abababababababababababababab', beta.detach().cpu())
    
        
    # Adding 1 ensures beta > 1
        dist = D.Beta(alpha, beta)
        return dist

    def get_value(self, state):
        x = self.relu(self.forward(state))
        value = self.value(x)
        return value





class PolicyNetwork(nn.Module):
    def __init__(self, state_dim, action_dim):
        super(PolicyNetwork, self).__init__()
        # Mean network

        self.gru = nn.GRU(input_size=state_dim, hidden_size=128, num_layers=2, batch_first=True, bidirectional=True)
        self.state_dim = state_dim
        self.batch_norm = nn.BatchNorm1d(state_dim)
        self.fc1 = nn.Linear(4*128, 128)
        self.fc2 = nn.Linear(128, 128)
        self.fc3 = nn.Linear(128, 128)
        self.fc4 = nn.Linear(128, 3)
        self.relu = nn.ReLU()

        # Initialize weights and biases to zero
        nn.init.zeros_(self.fc1.weight)
        nn.init.zeros_(self.fc1.bias)
        nn.init.zeros_(self.fc2.weight)
        nn.init.zeros_(self.fc2.bias)
        nn.init.zeros_(self.fc3.weight)
        nn.init.zeros_(self.fc3.bias)
        nn.init.zeros_(self.fc4.weight)
        nn.init.zeros_(self.fc4.bias)
        # Log standard deviation (learned parameter)
        self.log_std = nn.Parameter(torch.zeros(action_dim))

        for name, param in self.gru.named_parameters():
            if "weight" in name or "bias" in name:  # Check if it's a weight or bias
                param.data.fill_(0)

    def forward(self, state):
        x = state.reshape(state.shape[0],-1, self.state_dim)

        batch_size, seq_len, feature_dim = x.size()
        x = x.view(-1, feature_dim)
        x = self.batch_norm(x)
        x = x.view(batch_size, seq_len, feature_dim)
        gru_output, hgru = self.gru(x)
        x = hgru.permute(1,0,2).reshape(hgru.shape[1],-1)
        x = self.relu(x)
        x = self.fc1(x)
        x = self.relu(x)
        x = self.fc3(x)
        x = self.relu(x)
        mean = self.fc4(x)


        y1 = torch.tanh(mean[:, 0])  # Output between -1 and 1
        y2 = torch.sigmoid(mean[:, 1])     # Output between 0 and 1
        y3 = torch.tanh(mean[:, 2])  # Output between 0 and 1

        # Combine outputs into a single tensor
        mean = torch.stack((y1, y2, y3), dim=1)

        std = torch.exp(self.log_std)  # Ensure std is positive
        return mean, std

class ValueNetwork(nn.Module):
    def __init__(self, state_dim):
        super(ValueNetwork, self).__init__()

        self.gru = nn.GRU(input_size=state_dim, hidden_size=128, num_layers=2, batch_first=True, bidirectional=True)
        self.state_dim = state_dim
        self.batch_norm = nn.BatchNorm1d(state_dim)
        self.fc1 = nn.Linear(4*128, 128)
        self.fc2 = nn.Linear(128, 128)
        self.fc3 = nn.Linear(128, 128)
        self.fc4 = nn.Linear(128, 1)
        self.relu = nn.ReLU()

        # Initialize weights and biases to zero
        nn.init.zeros_(self.fc1.weight)
        nn.init.zeros_(self.fc1.bias)
        nn.init.zeros_(self.fc2.weight)
        nn.init.zeros_(self.fc2.bias)
        nn.init.zeros_(self.fc3.weight)
        nn.init.zeros_(self.fc3.bias)
        nn.init.zeros_(self.fc4.weight)
        nn.init.zeros_(self.fc4.bias)

        for name, param in self.gru.named_parameters():
            if "weight" in name or "bias" in name:  # Check if it's a weight or bias
                param.data.fill_(0)


    def forward(self, state):
        x = state.reshape(state.shape[0],-1, self.state_dim)

        batch_size, seq_len, feature_dim = x.size()
        x = x.view(-1, feature_dim)
        x = self.batch_norm(x)
        x = x.view(batch_size, seq_len, feature_dim)
        gru_output, hgru = self.gru(x)
        x = hgru.permute(1,0,2).reshape(hgru.shape[1],-1)
        x = self.relu(x)
        x = self.fc1(x)
        x = self.relu(x)
        x = self.fc3(x)
        x = self.relu(x)
        x = self.fc4(x)
        return x


class DiscretePolicyNetwork(nn.Module):
    def __init__(self, state_dim, action_dim=1, hidden_dim=64):
        super(DiscretePolicyNetwork, self).__init__()
        
        self.state_dim = state_dim
        self.gru = nn.GRU(input_size=state_dim, hidden_size=128, num_layers=2, batch_first=True, bidirectional=True)
        self.batch_norm = nn.BatchNorm1d(state_dim)
        self.fc1 = nn.Linear(4*128, 128)
        self.fc2 = nn.Linear(128, 128)
        self.fc3 = nn.Linear(128, 128)
        self.logits_layer = nn.Linear(128, action_dim)
        self.relu = nn.ReLU()

        # Initialize weights and biases to zero
        nn.init.xavier_uniform_(self.fc1.weight)
        nn.init.zeros_(self.fc1.bias)
        nn.init.xavier_uniform_(self.fc2.weight)
        nn.init.zeros_(self.fc2.bias)
        nn.init.xavier_uniform_(self.fc3.weight)
        nn.init.zeros_(self.fc3.bias)
        nn.init.xavier_uniform_(self.logits_layer.weight)
        nn.init.zeros_(self.logits_layer.bias)

        for name, param in self.gru.named_parameters():
            if "weight" in name or "bias" in name:  # Check if it's a weight or bias
                param.data.fill_(0)

    def forward(self, state):

        x = state.reshape(state.shape[0],-1, self.state_dim)

        batch_size, seq_len, feature_dim = x.size()
        x = x.view(-1, feature_dim)
        x = self.batch_norm(x)
        x = x.view(batch_size, seq_len, feature_dim)
        gru_output, hgru = self.gru(x)
        x = F.relu(hgru.permute(1,0,2).reshape(hgru.shape[1],-1))


        x = F.relu(self.fc1(x))
        x = F.relu(self.fc3(x))
        logits = self.logits_layer(x)  # Output logits for each discrete action
        return logits






class PositionalEncoding(nn.Module):
    """
    Implements the standard sine/cosine positional encoding.
    """
    def __init__(self, d_model, max_len=5000):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))

        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0)  # shape: (1, max_len, d_model)

        self.register_buffer('pe', pe)

    def forward(self, x):
        """
        x shape: (batch_size, seq_len, d_model)
        """
        seq_len = x.size(1)
        # Add positional encoding
        x = x + self.pe[:, :seq_len, :]
        return x

# ---------------------------
# 3) Transformer Model
# ---------------------------
class TimeSeriesTransformer(nn.Module):
    def __init__(self,
                 seq_len=50,
                 feature_dim=250,
                 d_model=256,
                 nhead=8,
                 num_layers=4,
                 dim_feedforward=512,
                 dropout=0.1,
                 out_dim=128):
        """
        Args:
            seq_len: input sequence length
            feature_dim: dimension of input features per time step
            d_model: model dimension for the Transformer
            nhead: number of attention heads
            num_layers: number of transformer encoder layers
            dim_feedforward: dimension of the feedforward network model
            dropout: dropout rate
            out_dim: dimension of final output vector (pooled over time)
        """
        super().__init__()

        # 1) Optional: Project input features (feature_dim) -> d_model
        self.input_projection = nn.Linear(feature_dim, d_model)

        # 2) Positional encoding
        self.pos_encoder = PositionalEncoding(d_model)

        # 3) Transformer Encoder
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=nhead,
            dim_feedforward=dim_feedforward,
            dropout=dropout,
            batch_first=True  # important so that input is (B, S, D) not (S, B, D)
        )
        self.transformer_encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)

        # 4) Final pooling: reduces the sequence dimension to a single vector via mean pooling.
        self.pool = nn.AdaptiveAvgPool1d(1)  # Will pool over the sequence dimension

        # 5) Final dimension reduction from d_model -> out_dim
        self.fc_out = nn.Linear(d_model, out_dim)

    def get_seq_env(self, x):
        x = self.input_projection(x)  # (B, S, d_model)

        # Add positional encoding
        x = self.pos_encoder(x)       # (B, S, d_model)

        # Pass through Transformer Encoder
        x = self.transformer_encoder(x)  # (B, S, d_model)

        return x

    def forward(self, x):
        """
        x shape: (B, S, feature_dim)
        Returns: (B, out_dim)
        """
        # Project to d_model
        x = self.input_projection(x)  # (B, S, d_model)

        # Add positional encoding
        x = self.pos_encoder(x)       # (B, S, d_model)

        # Pass through Transformer Encoder
        x = self.transformer_encoder(x)  # (B, S, d_model)

        # Pool over the sequence dimension (S)
        # x shape is (B, d_model, S) for using 1D pooling properly,
        # transpose to match (B, D, S)
        x = x.transpose(1, 2)  # (B, d_model, S)
        x = self.pool(x)       # (B, d_model, 1)
        x = x.squeeze(-1)      # (B, d_model)

        # Final linear to get out_dim
        x = self.fc_out(x)     # (B, out_dim)
        return x


import torch
import torch.nn as nn
import torch.nn.functional as F
import math

class BetaMDNPolicy(nn.Module):

    def __init__(self, hidden_dim, action_dim, num_mixtures):
        super().__init__()
        self.num_mixtures = num_mixtures
        self.action_dim = action_dim
        
        out_dim = num_mixtures * (1 + 2 * action_dim)
        self.fc_out = nn.Linear(hidden_dim, out_dim)
        nn.init.orthogonal_(self.fc_out.weight, 0.01)
        nn.init.zeros_(self.fc_out.bias)
        

    def forward(self, state):

        out = self.fc_out(state)  # shape: [batch_size, K * (1 + 2*d)]
        batch_size = out.size(0)
        
        # Reshape to separate mixture dimension
        out = out.view(batch_size, self.num_mixtures, 1 + 2 * self.action_dim)
        
        # 1) Mixture logits -> pi
        logit_pi = out[:, :, 0]  # [batch_size, K]
        pi = F.softmax(logit_pi, dim=-1)  # mixture weights sum to 1
        
        # 2) alpha params
        alpha_params = out[:, :, 1 : 1 + self.action_dim]  # [batch_size, K, d]
        # 3) beta params
        beta_params  = out[:, :, 1 + self.action_dim : 1 + 2*self.action_dim]  # [batch_size, K, d]
        
        # Force positivity of alpha, beta (e.g., softplus)
        alpha = F.softplus(alpha_params) + 1
        beta  = F.softplus(beta_params)  + 1
        
        return pi, alpha, beta

    def sample_action(self, state):
        pi, alpha, beta = self.forward(state)
        return self._sample_from_beta_mixture(pi, alpha, beta)

    def log_prob(self, state, action):
        pi, alpha, beta = self.forward(state)
        return self._log_prob_beta_mixture(action, pi, alpha, beta)

    def mixture_entropy(self, state, n_samples=10):
        pi, alpha, beta = self.forward(state)
        return self._mixture_beta_entropy(pi, alpha, beta, n_samples=n_samples)+ 2*self._mixture_usage_entropy(pi)

    def get_action(self, state):

        action = self.sample_action(state)
        log_prob = self.log_prob(state, action)
        entropy = self.mixture_entropy(state, n_samples=5)

        return action, log_prob, entropy

    @staticmethod
    def _sample_from_beta_mixture(pi, alpha, beta):
        batch_size, K = pi.shape
        d = alpha.shape[-1]
        
        # 1) Choose which mixture component k for each batch element
        cat = torch.distributions.Categorical(pi)  # [batch_size]
        mixture_indices = cat.sample()             # [batch_size]
        
        # 2) Gather alpha_k, beta_k for chosen component
        chosen_alpha = alpha[torch.arange(batch_size), mixture_indices, :]  # [batch_size, d]
        chosen_beta  = beta[torch.arange(batch_size), mixture_indices, :]   # [batch_size, d]
        
        
        if batch_size <2:
            print('aaaaaa', alpha.detach().cpu().tolist())
            print('bbbbbb', beta.detach().cpu().tolist())
            print('iiiiii', mixture_indices.detach().cpu())
        
        # 3) Sample from Beta(chosen_alpha, chosen_beta) dimension by dimension
        sampled = []
        for dim in range(d):
            dist_beta = torch.distributions.Beta(chosen_alpha[:, dim], chosen_beta[:, dim])
            sampled_dim = dist_beta.sample()  # [batch_size]
            sampled.append(sampled_dim)
        
        action = torch.stack(sampled, dim=-1)  # [batch_size, d]
        return action

    @staticmethod
    def _log_prob_beta_mixture(action, pi, alpha, beta, eps=1e-8):
        batch_size, K = pi.shape
        d = action.shape[-1]
        
        # log(pi)
        log_pi = torch.log(pi + eps)  # [batch_size, K]

        # Expand action to [batch_size, K, d] for vectorized computation
        action_expanded = action.unsqueeze(1).expand(-1, K, -1)
        
        # Beta log PDF per dimension: log Beta(x|alpha,beta) = log Gamma(a+b) - log Gamma(a) - log Gamma(b)
        #                           + (alpha-1)*log(x) + (beta-1)*log(1-x)
        # sum across d, then combine with log(pi) via logsumexp
        log_beta_fn = (
            torch.lgamma(alpha + beta)
            - torch.lgamma(alpha)
            - torch.lgamma(beta)
        )
        term = (
            (alpha - 1.0) * torch.log(action_expanded + eps)
            + (beta  - 1.0) * torch.log(1.0 - action_expanded + eps)
        )
        
        # sum across action_dim
        log_component_pdf = torch.sum(log_beta_fn + term, dim=-1)  # [batch_size, K]
        
        # log p(a) = logsumexp( log(pi) + sum_{d} log Beta(x_d), dim=K )
        log_mix = log_pi + log_component_pdf  # [batch_size, K]
        log_p = torch.logsumexp(log_mix, dim=-1)  # [batch_size]
        
        return log_p

    @staticmethod
    def _mixture_beta_entropy(pi, alpha, beta, n_samples=10):
        batch_size = pi.size(0)
        ent = torch.zeros(batch_size, device=pi.device)
        
        for _ in range(n_samples):
            a = BetaMDNPolicy._sample_from_beta_mixture(pi, alpha, beta)  # [batch_size, d]
            lp = BetaMDNPolicy._log_prob_beta_mixture(a, pi, alpha, beta)
            ent += -lp
        
        ent /= float(n_samples)
        return ent
    
    @staticmethod
    def _mixture_usage_entropy(pi):
        entropy_per_sample = -(pi * (pi + 1e-8).log()).sum(dim=-1)
        return entropy_per_sample.mean()


# ----------------------- Example of Usage -----------------------
if __name__ == "__main__":
    # Example: a 4D state, 2D action, and 3 mixture components
    policy = BetaMDNPolicy(state_dim=4, hidden_dim=64, action_dim=2, num_mixtures=3)
    
    # Create a batch of states
    states = torch.randn(5, 4)  # batch_size=5, state_dim=4
    
    # 1) Sample actions
    actions = policy.sample_action(states)
    print("Sampled actions:\n", actions)
    
    # 2) Compute log-prob of those actions
    log_probs = policy.log_prob(states, actions)
    print("Log-probs:\n", log_probs)
    
    # 3) Approximate the mixture's entropy
    ent = policy.mixture_entropy(states, n_samples=5)
    print("Approximate Entropy:\n", ent)

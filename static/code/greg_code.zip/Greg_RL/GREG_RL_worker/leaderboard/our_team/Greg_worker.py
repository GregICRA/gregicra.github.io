"""
Rollout agent for the distributed RL worker.

The control loop is decimated to 5 Hz: the policy is queried only every DECISION_EVERY simulator
frames, both steer and acceleration are held constant across the block, and exactly one macro
transition is pushed per block. Its (state, next_state) are DECISION_EVERY frames apart and its
reward vector is the frame-by-frame sum of the block's per-frame reward terms (get_reward still runs
every frame, so route progress and speed are captured exactly). The learner's geometric-mean reward
is degree-1 homogeneous, so summing the terms equals DECISION_EVERY times the per-frame reward while
applying the terminal collision penalty exactly once.

The learner constants must match this cadence: gamma -> gamma**DECISION_EVERY, GAMMA_COST likewise,
and N_STEP_COST_LOOKAHEAD expressed in macro-steps.

The agent collects experience over HTTP from the trainer's data server (MASTER_IP / DATA_SERVER_PORT)
and periodically pulls the latest actor weights from the same server.
"""
import os
import json
import datetime
import pathlib
import time
from dotenv import load_dotenv

load_dotenv()
import cv2
import carla
from collections import deque
import math
from collections import OrderedDict

import torch
import numpy as np
from PIL import Image
from torchvision import transforms as T

from leaderboard.autoagents import autonomous_agent

from Greg.model import Greg, RSSMBelief
from Greg.config import GlobalConfig
from team_code.planner import RoutePlanner
from scipy.optimize import fsolve
from transformers import AutoModel, AutoConfig

# BEV rendering / stop-sign tracking
from srunner.scenariomanager.carla_data_provider import CarlaDataProvider
from birds_eye_view.chauffeurnet import ObsManager
from birds_eye_view.run_stop_sign import RunStopSign


########################

import requests
import time
import io
import sys


import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.distributions import Categorical, Normal
import numpy as np
import math

from our_team.actorcritic import (
    ValueNetwork,
    PolicyNetwork,
    ActorCritic,
    ForwardModel,
    EnvironmentModelVAE,
    Value,
)
from our_team.util import (
    RewardNormalizer,
    PrioritizedReplayBuffer,
    ReplayBuffer,
    barrier,
    copy_pth_files,
    TreeNode,
    best_trajectory
)

from collections import deque
import math
from collections import OrderedDict
import random
import traceback
import time

import pathlib
import pickle
import ujson  # Like json but faster
import gzip
import re

Discrete_Actions_DICT = {
    0:  (0, 1, False),
    1:  (0.0, 0, False),
    2: (0.3, 0, False),
    3: (0.7, 0.0, False),
    4: (1.0, 0, False),
    5: (0.5, 0, True),
    }
########################

SAVE_PATH = None
IS_BENCH2DRIVE = True
PLANNER_TYPE = 'only_ctrl'
ORIGINAL = True
print('*'*10)
print(PLANNER_TYPE)
print('*'*10)

EARTH_RADIUS_EQUA = 6378137.0


def get_entry_point():
    return 'GregAgent'


MASTER_IP = os.environ["MASTER_IP"]  # trainer's data-server host; set in .env
MASTER_PORT = int(os.environ.get('DATA_SERVER_PORT', 34543)) # must match GREG_RL_Trainer's data_server.py
MASTER_BATCH_URL = f"http://{MASTER_IP}:{MASTER_PORT}/add_batch/"
MASTER_WEIGHT_URL = f"http://{MASTER_IP}:{MASTER_PORT}/get_latest_weights/"
WORKER_ID = os.environ.get('WORKER_ID', None)
# Machine-unique worker key. The learner chains n-step windows per worker_id, so every worker
# process must have a distinct id: a hostname hash combined with the PID is unique across machines
# and stable for the lifetime of this process.
import socket, zlib
UNIQUE_WORKER_ID = (zlib.crc32(socket.gethostname().encode()) % 20000) * 100000 + os.getpid() % 100000

BATCH_UPLOAD_SIZE = 100
RETRY_DELAY = 5
POLICY_UPDATE_INTERVAL = 15

# Decimation: the policy is called (and one macro-transition pushed) only every DECISION_EVERY
# frames; both steer and accel are held constant in between. DECISION_EVERY=4 -> 5 Hz decisions,
# and must match the learner's gamma / GAMMA_COST / N_STEP_COST_LOOKAHEAD (see module docstring).
DECISION_EVERY = int(os.environ.get('DECISION_EVERY', 4))
ACCEL_HOLD_K = DECISION_EVERY

# Run the DINOv3 ViT-L forward on decision frames only; VIT_GATE=0 forces a per-frame forward.
VIT_GATE = int(os.environ.get('VIT_GATE', 1)) != 0

# --- RSSM belief (recurrent burn-in) ---
# The worker executes the same belief the learner trains on. The deterministic state h is neither
# carried across the episode nor shipped: it is re-derived at every decision by unrolling the GRU
# from zeros over the previous RSSM_BURNIN_K-1 decision frames, with the actions actually executed.
# That fixed window makes the belief a pure function of the last K frames, so the learner's
# recomputation from stored windows matches what the worker acted on.
# Dims must match the learner's RSSM_* constants (RSSM_BURNIN_K == learner.RSSM_BURNIN_K).
# RSSM_BURNIN_K=1 degenerates to a zero-h belief; RSSM_ENABLED=False drops the belief input.
RSSM_ENABLED = True
RSSM_BURNIN_K = 16   # decision frames of history = 3.0 s at 5 Hz
RSSM_BURNIN_L = RSSM_BURNIN_K - 1
RSSM_OBS_DIM = 512 + 10        # [frozen IL embedding, 10-d route scalars]
RSSM_DETER_DIM = 256
RSSM_STOCH_GROUPS = 16
RSSM_STOCH_CLASSES = 16
RSSM_HIDDEN = 512
RSSM_UNIMIX = 0.01

# --- Camera-only stop-sign memory (route scalar #10) ---
# Self-computed from the ego's OWN speedometer (no privileged sim state): normalized time since the
# ego last came to a full stop. Recovers the hidden "stop already completed" bit that a
# single-frame embedding can't hold, so a reactive policy can learn stop-sign compliance.
STOP_SPEED_THRESH = 0.1   # m/s; below this the ego counts as fully stopped -> memory resets to 0
STOP_MEMORY_CAP = 10.0    # s; time_since_full_stop saturates here (feature normalized to [0,1])
STOP_TICK_DT = 0.05       # s per tick (CARLA @ 20 Hz); the per-step increment while moving

class GregAgent(autonomous_agent.AutonomousAgent):
    def setup(self, path_to_conf_file,gamma=0.99,
        clip_param=0.2,
        update_freq=60,   # decisions between weight pulls / batch ships (~12.5 s of wall clock)
        batch_size=1024,
        ppo_epochs=10,
        buffer_capacity=2048):
        self.track = autonomous_agent.Track.SENSORS
        self.steer_step = 0
        self.last_moving_status = 0
        self.last_moving_step = -1
        self.last_steers = deque()
        if IS_BENCH2DRIVE:
            self.save_name = path_to_conf_file.split('+')[-1]
            self.config_path = path_to_conf_file.split('+')[0]
        else:
            self.config_path = path_to_conf_file
            self.save_name = '_'.join(
                map(lambda x: '%02d' % x, (now.month, now.day, now.hour, now.minute, now.second)))
        self.step = -1
        self.wall_start = time.time()
        self.initialized = False

        self.env_metadata = re.sub(r'(_\d+){5,6}$', '', self.save_name)

        self.config = GlobalConfig()
        my_hf_token = os.environ.get("HF_TOKEN")

        # Load the ViT-Large model directly from Hugging Face
        pretrained_model_name = "facebook/dinov3-vitl16-pretrain-lvd1689m"
        custom_cache_path = "./dinov3_large_cache"
        config = AutoConfig.from_pretrained(
            pretrained_model_name,
            token=my_hf_token,
            cache_dir=custom_cache_path
        )

        # 2. Initialize the model with that config (no weights loaded)
        vit_base = AutoModel.from_config(config)
        self.net = Greg(self.config, vit_base_model=vit_base)

        
        if ORIGINAL:
            ckpt = torch.load(self.config_path, map_location="cuda")
            ckpt = ckpt["state_dict"]
            new_state_dict = OrderedDict()
            
            for key, value in ckpt.items():
                # Chain the replacements to scrub BOTH prefixes
                new_key = key.replace("model.", "").replace("_orig_mod.", "")
                new_state_dict[new_key] = value
                
            # strict=False: the zero-init route_adapter is absent from the IL checkpoint and keeps
            # its no-op initialisation until a trained actor is fetched.
            self.net.load_state_dict(new_state_dict, strict=False)
        else:
            ckpt = torch.load(self.config_path, map_location="cuda")
            self.net.load_state_dict(ckpt['policy_net_state_dict'], strict=False)
        
        self.net.cuda()
        self.net.eval()

        self.takeover = False
        self.stop_time = 0
        self.takeover_time = 0

        self.save_path = None
        self._im_transform = T.Compose([T.ToTensor(), T.Normalize(
            mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])])

        self.last_steers = deque()
        if SAVE_PATH is not None:
            now = datetime.datetime.now()
            string = self.save_name

            print(string)

            self.save_path = pathlib.Path(os.environ['SAVE_PATH']) / string
            self.save_path.mkdir(parents=True, exist_ok=False)

            (self.save_path / 'rgb').mkdir()
            (self.save_path / 'rgb_front').mkdir()
            (self.save_path / 'meta').mkdir()
            (self.save_path / 'bev').mkdir()

        #################################

        self.pretrain_loss_below_threshold_count = 0
        self.is_pretraining = True  # Flag to indicate pre-training phase
        self.eval_mode = False
        self.il_baseline_only = False
        self.fused_head = False
        self.eval_disc = True
        self.eval_act = False
        self.auto_train = False

        self.pre_pos = torch.tensor(0).cuda()
        self.pre_dis = None
        # --- Exact route progress -------------------------------------------------
        # Route progress is measured against the ground-truth ego transform rather than by
        # differencing ||target_point||: the latter is built from the GNSS position, which the
        # leaderboard perturbs with 5e-6 deg (~0.56 m per axis) of noise resampled every frame,
        # swamping the ~0.30 m per-frame signal at 6 m/s. The planner still SELECTS the waypoint
        # (distance travelled alone is direction-blind), but the progress toward it is measured in
        # the CARLA world frame. This is reward-only privileged information, like _get_desired_speed.
        # `_exact_prog_ok` records whether that path is available; the GPS difference is the fallback.
        self._cur_route_wp = None       # waypoint the planner selected THIS frame (world x,y)
        self._prev_route_wp = None      # ...and the one it selected on the previous frame
        self._prev_ego_xy = None        # ground-truth ego (x,y) on the previous frame
        self._exact_prog_ok = None      # None = not yet checked, False = frames misaligned
        self.pre_target_wp = torch.tensor(0).cuda()
        self.pre_target = torch.tensor([0, 0]).cuda()
        if self.il_baseline_only:
            self.start_cnt = random.randint(5000, 5001)
        else:
            self.start_cnt = random.randint(51, 51)

        self.not_seen_target = True

        self.forward_epoch = ppo_epochs
        self.first_episode_epco = 20
        self.gamma = gamma  # Discount factor
        self.clip_param = clip_param  # PPO clipping parameter
        self.update_freq = update_freq  # Frequency of updates
        self.batch_size = batch_size  # Mini-batch size
        self.ppo_epochs = ppo_epochs  # Number of PPO epochs per update
        self.pretrain_loss_threshold = 0.08
        self.pretrain_loss_threshold_episode = 1000
        self.required_steps_below_threshold = 100
        self.mini_batch_size = batch_size
        self.state_queue_size = 1
        self.pretrain_barrier_num = 30
        # Networks

        self.prev_command = None
        self.tree_depth = 20
        self.tree_degree = 2
        self.cnt_env = 0
        self.actions_env = None
        self.last_alpha= None
        self.last_beta = None

        self.state_dim = 640
        self.ttc = 100000.0
        # Desired speed (normalized by /12, same as the speed fed to get_reward).
        # Set every step from surrounding traffic / speed limit in run_step.
        self.desired_speed_norm = torch.tensor(0.5).float().cuda()

        # PolicyNetwork(state_dim=8+2+1+256, action_dim=3)
        self.policy_net = self.net

        self.reward_norm = RewardNormalizer()

        self.buffer = []

        # For one-step delay
        self.prev_state = None
        self.prev_prev_state = None
        self.prev_action_queue = None
        self.prev_prev_action_queue = None
        self.prev_action = None
        self.prev_log_prob = None
        self.prev_value = None
        self.prev_reward = None
        self.prev_bev = None # Added for BEV serialization
        self.prev_boxes = None # privileged GT box/route tokens for the state (one-step delay, mirrors prev_bev)
        self.prev_route = None # route scalars [speed, target_point, command] for the state (one-step delay, mirrors prev_bev)

        self.step_count = 0

        self.temp_buffer = []

        self.reward_list = []

        self.replay_buffer = []
        # Teardown may be called more than once by leaderboard cleanup paths.  These counters make
        # the route-end data contract visible in worker logs without changing the transition wire
        # format or the policy/learner objective.
        self._destroyed = False
        self._route_end_flush_count = 0
        self._route_end_flush_rows = 0
        self.state_queue = deque(maxlen=self.state_queue_size)
        self.action_queue_size = 10
        self.action_queue = deque(maxlen=self.action_queue_size)
        for i in range(self.action_queue_size):
            self.action_queue.append(torch.tensor([0.5, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0]))

        self._reset()

        self.is_done = False
        self.collid = False
        # Termination-cause code shipped as reward index 10 (see end_episode):
        # 0 none/other, 1 collision/off-road (physical), 2 red-light/stop-sign (rule),
        # 3 blocked/route-deviation. Lets the learner give COST only to physical danger.
        self.term_cause = 0
        # Consecutive steps the in-lane lead vehicle has been ~stationary (see _get_desired_speed).
        self._stopped_lead_steps = 0
        self.terminate = False
        self.end = False
        self.best_loss_policy = 1e7
        self.best_loss_value = 1e7
        self.best_reward = torch.tensor(-10000)
        self.acc_reward = torch.tensor([0.]).float().cuda()
        self.cnt = 0
        # Camera-only stop-sign memory: seconds since the ego last fully stopped (see STOP_* consts).
        # Starts at 0 (the ego spawns stationary == "just stopped").
        self.time_since_full_stop = 0.0
        self.last_thbk = 0
        self.last_st = 0
        self.last_th = 0
        self.last_bk = 0
        self.last_reverse = False
        self.is_parked_stat = False
        self.last_sts = deque(maxlen=10)
        self.last_speeds = deque(maxlen=500)
        for i in range(500):
            self.last_speeds.append(torch.tensor(1).float().cuda())

        self.barrier_num = -2
        self.states = []
        self.labels = []

        # --- RSSM belief filter (weights refreshed from the learner alongside the policy).
        # Until the first sync it is random-init — harmless: the policy's zero-init belief_proj
        # ignores the belief until trained weights arrive. h starts at 0 each episode (one agent
        # instance per route); in ZERO_H mode it simply stays 0 forever.
        self.rssm = None
        if RSSM_ENABLED:
            self.rssm = RSSMBelief(embed_dim=RSSM_OBS_DIM, action_dim=7,
                                   deter_dim=RSSM_DETER_DIM, stoch_groups=RSSM_STOCH_GROUPS,
                                   stoch_classes=RSSM_STOCH_CLASSES, hidden=RSSM_HIDDEN,
                                   unimix=RSSM_UNIMIX).cuda()
            self.rssm.eval()
        # Fixed-window burn-in filter state: the last RSSM_BURNIN_K-1 DECISION frames as
        # (obs_522, executed action_7), oldest first. Cleared per episode so h restarts from zeros.
        self._belief_hist = deque(maxlen=RSSM_BURNIN_L)
        self._cur_obs = None         # this decision's obs, held until its executed action is known

        self.update_policy_from_master()
        self.policy_net.cuda()
        self.policy_net.eval()
            
        self.end_of_ep = False

        # --- 5 Hz decimation state ---
        # Frame counter over post-warmup steps; a decision fires when it % DECISION_EVERY == 0.
        self.decimation_frame = 0
        # Running element-wise SUM of the 6-term per-frame reward_list over the current macro-block.
        # Reset to None (empty) after each push; get_reward feeds it every frame.
        self._macro_r6 = None
        # Cached EXECUTED control from the last decision, re-emitted on the held (non-decision) frames.
        self._held_control = None   # (steer_traj, throttle_traj, brake_traj, reverse_traj, temp_throttle)
        self._held_net = None       # cached ViT outputs for held frames (see VIT_GATE)
        # Accel-hold bookkeeping (referenced by end_episode); inert under full decimation.
        self.held_accel_idx = None
        self.accel_hold_count = 0

    def _apply_accel_hold(self, action):
        """Inert under full 5 Hz decimation: the decision gate in run_step already holds the ENTIRE
        action (steer + accel) across the block by only sampling every DECISION_EVERY frames and
        re-emitting the cached control in between. Kept as an identity passthrough so the two call
        sites in run_step need no change."""
        return action

    def _accumulate_macro_reward(self, reward_list):
        """Add this frame's 6-term reward_list ([r, Rdis, Rspeed, Rsteer, Rds, Rreverse]) into the
        macro-block running sum. Summing (not averaging) is exact: the learner's geo-mean reward is
        degree-1 homogeneous, so calculate_reward(sum) == DECISION_EVERY x the per-frame reward, and
        the terminal collision penalty (carried by term_cause, 0 except on the terminal frame) is
        applied once. Only the 6 get_reward terms accumulate; the appended 5 (speed/collision/ttc/
        desired/cause) are taken from the decision frame at push time (see run_step)."""
        vec = torch.stack([t.squeeze().float().cpu() for t in reward_list])
        if self._macro_r6 is None:
            self._macro_r6 = vec
        else:
            self._macro_r6 = self._macro_r6 + vec

    def _belief_for(self, emb, route):
        """RSSM belief for acting on this DECISION step, via the fixed-window burn-in filter:
        h is unrolled from zeros over the RSSM_BURNIN_K-1 previous DECISION frames (each stored
        with the action actually executed in that block), then belief = q(z | h, [emb, route]).
        The learner recomputes h the exact same way from its stored windows, so acting and
        learning agree with no shipped/stored h. Returns None for a belief-less policy."""
        if self.rssm is None:
            return None
        with torch.no_grad():
            obs = torch.cat([emb, route.to(emb.device)], dim=1)
            if RSSM_BURNIN_L > 0 and len(self._belief_hist) > 0:
                e_hist = torch.stack([f[0] for f in self._belief_hist], dim=1)   # (1, L', 522)
                a_hist = torch.stack([f[1] for f in self._belief_hist], dim=1)   # (1, L', 7)
                h = self.rssm.burn_in(e_hist, a_hist)      # no mask: only real frames are queued
            else:
                h = self.rssm.initial(obs.shape[0], obs.device)
            belief, _ = self.rssm.posterior_belief(h, obs, sample=True)
        self._cur_obs = obs
        return belief

    def _advance_filter(self, action_buffer):
        """Push (obs_t, executed action_t) onto the burn-in history once the block's action is
        known. `action_buffer` is the EXECUTED [steer, onehot6] form the learner trains on. The
        deque length caps the window, so h always restarts from zeros K-1 frames back."""
        if self.rssm is None or RSSM_BURNIN_L == 0 or self._cur_obs is None:
            return
        a_exec = action_buffer.detach().to(self._cur_obs.device).float().view(1, -1)
        self._belief_hist.append((self._cur_obs, a_exec))
        self._cur_obs = None

    def _reset(self):
        self.last_state = None
        self.last_action = None
        self.last_log_prob = None
        self.last_value = None
        self.last_reward = torch.tensor(0).cuda()
        self.last_done = False

    def reset_queue(self, state):
        # New episode: the burn-in window must restart from zeros, exactly like the learner's
        # per-worker rolling history (cleared on `done` / stream discontinuity in _nstep_process).
        self._belief_hist.clear()
        self._cur_obs = None
        self.state_queue.clear()
        initial_state = torch.zeros_like(state)
        for _ in range(self.state_queue_size):
            self.state_queue.append(initial_state)

    def is_honk(self):
        return False

    def update_policy_from_master(self):
        """Downloads the latest model weights from the master data server."""
        while True:
            try:
                response = requests.get(MASTER_WEIGHT_URL, timeout=5)
                response.raise_for_status() 
                weights = torch.load(io.BytesIO(response.content), map_location=torch.device('cpu'))
                # RSSM weights ride along as one extra top-level key; pop it so load_state_dict
                # sees only policy keys.
                rssm_sd = weights.pop('rssm_state_dict', None) if isinstance(weights, dict) else None
                self.policy_net.load_state_dict(weights, strict=False)
                if self.rssm is not None and rssm_sd is not None:
                    # The multi-horizon safety head is learner-only and omitted from the actor
                    # payload. Allow exactly those missing keys; every dynamics key is still checked.
                    missing, unexpected = self.rssm.load_state_dict(rssm_sd, strict=False)
                    bad_missing = {
                        k for k in missing if not k.startswith('safety_horizon_head.')
                    }
                    if bad_missing or unexpected:
                        raise RuntimeError(
                            f"Unexpected RSSM weight mismatch: missing={sorted(bad_missing)}, "
                            f"unexpected={sorted(unexpected)}")
                    self.rssm.eval()
                print(f"✅ [Worker {WORKER_ID}] Policy updated successfully.")
                break
            except requests.exceptions.RequestException:
                pass
            except Exception as e:
                print(f"❌ [Worker {WORKER_ID}] Error loading downloaded model: {e}")

    def get_boxes_and_route(self, max_obj=30, max_route=20, obj_radius=40.0):
        """Privileged GROUND-TRUTH object + route tokens in the ego frame for the asymmetric box critic.
        Each token row = [x_fwd, y_left, yaw_rel, speed, extent_x, extent_y, class_id]; class ids:
        1=vehicle, 2=walker, 5=route (0=pad on the learner side).

        FAILS LOUD by design: the route tokens are REQUIRED (they carry the route-progress signal the
        frozen IL embedding is blind to). The ego transform, CARLA world and the privileged route plan
        (`_global_plan_world_coord`, set once by the leaderboard's set_global_plan) are accessed directly
        -- a missing/empty one raises rather than silently shipping a route-less scene that would quietly
        defeat the box critic. Only individual malformed actors are tolerated (skipped)."""
        ego_tf = self._vehicle.get_transform()
        ego_loc = ego_tf.location
        fwd = ego_tf.get_forward_vector()
        ego_yaw = math.radians(ego_tf.rotation.yaw)
        world = CarlaDataProvider.get_world()

        def to_ego(loc):
            dx, dy = loc.x - ego_loc.x, loc.y - ego_loc.y
            return (dx * fwd.x + dy * fwd.y, -dx * fwd.y + dy * fwd.x)  # (x_forward, y_left)

        # --- objects: vehicles + walkers, nearest first (one malformed actor != a system failure) ---
        objs = []
        for cls_id, flt in ((1.0, '*vehicle*'), (2.0, '*walker*')):
            for a in world.get_actors().filter(flt):
                try:
                    if a.id == self._vehicle.id:
                        continue
                    x, y = to_ego(a.get_location())
                    if abs(x) > obj_radius or abs(y) > obj_radius:
                        continue
                    vel = a.get_velocity()
                    spd = (vel.x ** 2 + vel.y ** 2 + vel.z ** 2) ** 0.5
                    yaw_rel = math.radians(a.get_transform().rotation.yaw) - ego_yaw
                    yaw_rel = math.atan2(math.sin(yaw_rel), math.cos(yaw_rel))
                    ext = a.bounding_box.extent
                    objs.append((x * x + y * y, [x, y, yaw_rel, spd, ext.x, ext.y, cls_id]))
                except Exception:
                    continue
        objs.sort(key=lambda t: t[0])
        tokens = [r for _, r in objs[:max_obj]]

        # --- route: REQUIRED. Direct attribute access -> AttributeError if the leaderboard base class
        #     never populated it; empty -> RuntimeError. Either is a hard bug that must surface immediately. ---
        plan = self._global_plan_world_coord
        if not plan:
            raise RuntimeError(f"[Worker {WORKER_ID}] _global_plan_world_coord is empty -- privileged "
                               f"route plan unavailable; the box critic requires route tokens.")
        route = []
        for item in plan:
            x, y = to_ego(item[0].location)
            if x < -2.0:                       # skip points well behind the ego
                continue
            route.append((x * x + y * y, [x, y, 0.0, 0.0, 0.0, 0.0, 5.0]))
        route.sort(key=lambda t: t[0])
        tokens.extend([r for _, r in route[:max_route]])
        return tokens

    def send_batch_to_master(self, batch):
        """Sends a batch of experiences to the master, with a retry loop."""
        payload = [
            {
                "state_bev": s_bev.tolist(),
                "next_state_bev": ns_bev.tolist(),
                "pre_state": ps.squeeze().detach().cpu().numpy().tolist(),
                "state": s.squeeze().detach().cpu().numpy().tolist(),
                "action": a.detach().squeeze().cpu().numpy().tolist(),
                "reward": r.detach().squeeze().cpu().numpy().tolist(),
                "next_state": ns.detach().squeeze().cpu().numpy().tolist(),
                "done": bool(d),
                "action_queue": al.detach().squeeze().cpu().numpy().tolist(),
                "action_queue_next": aln.detach().squeeze().cpu().numpy().tolist(),
                "env_metadata": str(self.env_metadata),
                "worker_id": UNIQUE_WORKER_ID,
                "boxes": bx if bx else [],
                "next_boxes": nbx if nbx else [],
                "route_scalars": rsc.squeeze().detach().cpu().numpy().tolist() if rsc is not None else [],
                "next_route_scalars": nrsc.squeeze().detach().cpu().numpy().tolist() if nrsc is not None else [],
                # Optional RSSM filter states (FULL_FILTER mode only; [] in zero-h mode -> the
                # learner substitutes zeros, which IS the zero-h belief). h pairs with `state`,
                # h_next with `next_state`; the learner's n-step aggregator re-pairs h_next to
                # the landing state itself.
                "h": (ph.tolist() if ph is not None else []),
                "h_next": (ch.tolist() if ch is not None else []),
            }
            for ps, s, a, r, ns, _, _, _, d, al, aln, s_bev, ns_bev, bx, nbx, rsc, nrsc, ph, ch in batch
        ]
        
        while True:
            try:
                requests.post(MASTER_BATCH_URL, data=ujson.dumps(payload), headers={'Content-Type': 'application/json'}, timeout=10).raise_for_status()
                return 
            except requests.exceptions.RequestException as e:
                print(f"⚠️ [Worker {WORKER_ID}] Could not send batch to master ({e}). Retrying in {RETRY_DELAY}s...")
                time.sleep(RETRY_DELAY)

    def update(self):
        print(f"{WORKER_ID}: updating...")
        self.send_batch_to_master(self.replay_buffer)
        self.update_policy_from_master()
        self.replay_buffer = []
        print(f"{WORKER_ID}: updated")

    def _flush_pending_replay(self, reason="route_teardown"):
        """Send a residual route batch without fetching policy weights.

        Normal periodic updates run from inside ``run_step``.  Successful route completion is
        detected by the scenario manager *after* the final agent tick, so there is no later tick
        on which ``self.end`` can enter that periodic path, and the per-route agent is destroyed
        with residual rows still queued.

        ``send_batch_to_master`` returns only after an acknowledged HTTP response.  Keep the list
        intact until then, then replace it atomically so repeated teardown is process-idempotent.
        Delivery is at-least-once: a lost response can resend a batch.
        """
        pending = getattr(self, "replay_buffer", None)
        if not pending:
            return 0
        if getattr(self, "eval_mode", False) or getattr(self, "eval_act", False):
            return 0

        rows = len(pending)
        print(f"[Worker {WORKER_ID}] flushing {rows} residual rows ({reason})", flush=True)
        self.send_batch_to_master(pending)
        # No producer runs concurrently with leaderboard teardown.  Replacing (rather than
        # clearing before POST) retains every row until the server acknowledges the request.
        if self.replay_buffer is pending:
            self.replay_buffer = []
        self._route_end_flush_count += 1
        self._route_end_flush_rows += rows
        print(f"[Worker {WORKER_ID}] residual flush acknowledged: rows={rows} "
              f"flushes={self._route_end_flush_count}", flush=True)
        return rows

    def set_reward(self, reward, ttc):
        r = 1
        for key in reward.keys():
            r *= (1-0.9*reward[key])
            
        self.reward = r
        self.ttc = ttc

    def is_stall(self):
        if self.end_of_ep and not self.is_pretraining:
            return True
        else:
            return False
            
    def is_parked(self, parked):
        self.is_parked_stat = parked

    def _must_stop_for_signal(self):
        """Privileged (reward-only): True if the ego is currently held by a red light or by a
        stop sign it has not yet yielded to (i.e. has not come to a full stop for). Called once
        per step from _get_desired_speed; it ticks the dedicated reward stop-sign tracker.
        """
        # --- Red traffic light affecting the ego ---
        try:
            if (self._vehicle.is_at_traffic_light()
                    and self._vehicle.get_traffic_light_state() == carla.TrafficLightState.Red):
                return True
        except Exception:
            pass
        # --- Stop sign affecting the ego that it has not yet stopped for ---
        try:
            self._reward_stop_criteria.tick(self._vehicle)
            if (self._reward_stop_criteria.target_stop_sign is not None
                    and not self._reward_stop_criteria.stop_completed):
                return True
        except Exception:
            pass
        return False

    def _lead_is_signal_queue(self, lead):
        """Privileged (reward-only): True if a STOPPED lead vehicle is plausibly waiting at a
        signal/junction (queue) rather than being a static obstacle to drive around. Used to
        gate the stopped-lead timeout so it never rewards creeping into a red-light queue."""
        # Lead itself held by a red light.
        try:
            if lead.is_at_traffic_light() and lead.get_traffic_light_state() == carla.TrafficLightState.Red:
                return True
        except Exception:
            pass
        # Junction shortly ahead of the lead along its lane -> likely a queue (light/stop/yield).
        try:
            wp = CarlaDataProvider.get_map().get_waypoint(lead.get_location())
            for d in (5.0, 15.0, 30.0):
                nxt = wp.next(d)
                if nxt and nxt[0].is_junction:
                    return True
        except Exception:
            return True   # can't tell -> be conservative, treat as a queue (no override)
        return False

    def _get_desired_speed(self, max_distance=30.0, max_lateral=2.0):
        """Privileged (reward-only) target speed in m/s.

        ACC-style: the speed of the nearest lead vehicle in the ego lane, capped by the
        posted speed limit. Falls back to the speed limit on open road. A stopped lead
        (jam / red light) legitimately yields a low target, so it is not filtered out —
        UNLESS it has been stationary for a long time with no signal/junction explanation,
        in which case it is a static obstacle and the target switches to a moderate creep
        speed so Rspeed rewards going AROUND it instead of parking behind it forever.
        max_lateral is 2.0 m so that only the ego lane (plus genuine cut-ins) counts as a lead;
        4 m would span adjacent lane centres and pick up parked cars. Privileged sim info —
        reward shaping only, never policy input.
        """
        # Posted speed limit (km/h -> m/s); CARLA default ~30 km/h when no sign seen.
        try:
            speed_limit_mps = self._vehicle.get_speed_limit() / 3.6
        except Exception:
            speed_limit_mps = 8.33
        if speed_limit_mps <= 0.1:
            speed_limit_mps = 8.33

        # Hard override: at a red light or a not-yet-yielded stop sign the correct target speed is
        # 0, so the speed term rewards stopping (speed=0 -> Rspeed=1) instead of crawling.
        if self._must_stop_for_signal():
            self._stopped_lead_steps = 0   # signal stop: don't accumulate obstacle-timeout ticks
            return 0.0

        # Stopped-lead-as-obstacle timeout: a static obstacle (parked or broken-down car,
        # construction) would otherwise hold v*=0 forever and reward waiting behind it.
        STOPPED_LEAD_SPEED = 0.5          # m/s: lead considered stationary below this
        STOPPED_LEAD_TIMEOUT_STEPS = 200  # ~10 s at 20 Hz before declaring it a static obstacle
        OBSTACLE_CREEP_SPEED = 6.0        # m/s target while pulling out and passing the obstacle

        v_star = speed_limit_mps
        try:
            ego_tf = self._vehicle.get_transform()
            ego_loc = ego_tf.location
            fwd = ego_tf.get_forward_vector()
            lead_speed = None
            lead_actor = None
            nearest_lon = max_distance
            for v in CarlaDataProvider.get_world().get_actors().filter('*vehicle*'):
                if v.id == self._vehicle.id:
                    continue
                loc = v.get_location()
                dx, dy = loc.x - ego_loc.x, loc.y - ego_loc.y
                lon = dx * fwd.x + dy * fwd.y                 # ahead (+) / behind (-)
                lat = abs(-dx * fwd.y + dy * fwd.x)           # perpendicular offset
                if lon <= 0 or lon > nearest_lon or lat > max_lateral:
                    continue
                vel = v.get_velocity()
                if (vel.x * fwd.x + vel.y * fwd.y) < 0:       # oncoming traffic
                    continue
                nearest_lon = lon                            # keep the closest one ahead
                lead_speed = (vel.x ** 2 + vel.y ** 2 + vel.z ** 2) ** 0.5
                lead_actor = v
            if lead_speed is not None and lead_speed < STOPPED_LEAD_SPEED:
                self._stopped_lead_steps += 1
            else:
                self._stopped_lead_steps = 0
            if lead_speed is not None:
                if (self._stopped_lead_steps > STOPPED_LEAD_TIMEOUT_STEPS
                        and lead_actor is not None
                        and not self._lead_is_signal_queue(lead_actor)):
                    # Long-stationary lead with no signal/junction explanation: static obstacle.
                    # Reward going around it at a moderate speed instead of parking behind it.
                    v_star = min(speed_limit_mps, OBSTACLE_CREEP_SPEED)
                else:
                    v_star = min(speed_limit_mps, lead_speed)
        except Exception:
            pass
        # Comfort cap: on empty high-limit roads the posted limit alone would drive v_star to
        # ~25 m/s, pulling Rspeed toward flat-out cruising. Sensible range is ~[10, 20] m/s.
        DESIRED_SPEED_CAP = 15.0
        v_star = min(v_star, DESIRED_SPEED_CAP)
        return float(v_star)

    def _exact_route_progress(self):
        """Metres closed on the route waypoint over the last frame, measured without GNSS noise.

        Progress is scored against the waypoint that was current at the START of the interval
        (`_prev_route_wp`), not the one selected after this frame's pop. Scoring against a fixed
        target over the interval keeps the measurement continuous across a waypoint switch, where
        ||next_wp - ego|| jumps by the node spacing.

        Sign is meaningful: driving away from the target gives a negative value, driving
        perpendicular ~0, driving at it the full closing distance -- so this keeps the navigational
        content that a speedometer-only progress term would throw away.

        Returns None (the caller then falls back to the GPS path) on the first frame of an episode,
        if the world/route frames failed their alignment check, or if the ego transform is
        unavailable. Privileged sim info -> reward shaping only, never a policy input.
        """
        if not self._exact_prog_ok:
            return None
        try:
            loc = self._vehicle.get_transform().location
            p = np.array([loc.x, loc.y], dtype=np.float64)
        except Exception:
            return None
        wp, prev = self._prev_route_wp, self._prev_ego_xy
        # Roll the window forward regardless of whether this frame can be scored, so one missing
        # sample costs one frame of reward rather than desynchronising the pair forever.
        self._prev_route_wp, self._prev_ego_xy = self._cur_route_wp, p
        if wp is None or prev is None:
            return None
        out = float(np.linalg.norm(wp - prev) - np.linalg.norm(wp - p))
        # A non-finite value here would propagate through clamp() into the geometric mean and
        # poison the whole reward, so refuse it and let the caller fall back.
        return out if np.isfinite(out) else None

    def get_reward(self, pos, speed, target_achieved, dis, alpha, beta):
        rd = torch.sqrt(torch.sum(self.pre_target_wp**2))
        rdd = 1 / (rd + 1)
        rd2 = torch.sqrt(torch.sum((self.pre_pos - pos) ** 2))
        rdd2 = torch.min(torch.tensor([1]).float().cuda(), rd2 / 0.5)
        
        # Desired-speed term, one-sided: exp(-(max(0, v - v*)/sigma)^2) is exactly 1.0 for every
        # v <= v*, so only over-speeding is penalised. The v* oracle (`_get_desired_speed`) does not
        # model yielding to cross traffic and ignores pedestrians, so it errs in one direction only
        # (too high, never too low); a one-sided term is immune to that error while still opposing
        # speeding, which nothing else in the reward does (Rdis is flat above Rdis_ref m/frame).
        # `speed` and self.desired_speed_norm are both normalized by /12, so the comparison is
        # unit-consistent. The constant Rtime in learner.py is calibrated against this term so that
        # a stopped car scores ~0 per step.
        speed_sigma = torch.tensor(0.20).float().cuda()   # ~2.4 m/s band; tune here
        rs = torch.exp(-(torch.clamp(speed - self.desired_speed_norm, min=0.0) / speed_sigma) ** 2)
        rst = torch.max(torch.tensor([0]).float().cuda(), (1 - torch.abs(self.last_st)))
        harsh1 = torch.max(
            torch.abs(self.last_st) - 0.75, torch.tensor([0]).float().cuda()
        )
        harsh2 = torch.max(
            torch.abs(self.last_th) - 0.75, torch.tensor([0]).float().cuda()
        )
        rharsh = 0  
        rth = 10 * (
            torch.max(self.last_bk - 0.8, torch.tensor([0]).float().cuda())
        )  
        rbk = 1 - self.last_bk
        rtb = 1 / (1 + rth + (self.last_th + self.last_bk - 1) ** 2)
        rcol = -10 * self.collid  
        rt = 2 * target_achieved
        rdev = -0.1 * self.reward

        if len(list(self.last_sts)) > 0:
            rsts = 1 - torch.std(torch.tensor(list(self.last_sts)).cuda())
            torch.max(torch.tensor([0]).float().cuda(), rsts)
        else:
            rsts = torch.tensor([1]).float().cuda()
        rsteer = (
            (rst * rsts) ** (1 / 2)
            if not torch.isnan((rst * rsts) ** (1 / 2))
            else torch.tensor([0]).float().cuda()
        )
        rstop = (
            torch.tensor([0]).float().cuda()
            if torch.mean(torch.tensor(list(self.last_speeds))) > 0.01
            else torch.tensor([-0.1]).float().cuda()
        )
        rdiscountsteer = 0.1 * (
            torch.mean(torch.tensor(list(self.last_sts))) > 0.2
            and not self.collid
            and rs > 0.01
        ) - 2 * (torch.mean(torch.tensor(list(self.last_sts))) > 0.2 and self.collid)
        rss = 0.02 * rs
        
        if target_achieved:
            print("TARGET ACGIIIIIIIIIIIIIIIEEEEEEEVVVVVVVED")

        ralive = -0.02
        r = 0.02 * speed + ralive  
        r = (
            (torch.clip(self.last_th, 0, 1) - 0.6 * torch.clip(self.last_bk, 0, 1))
            + rt
            + ralive
            + 0.4 * speed
            + 6 * ((self.pre_dis - dis) if self.cnt > 52 else 0)
        )
        if self.pre_dis != None and dis != None:
            if abs(dis - self.pre_dis) > 3:
                self.pre_dis = None
        r_col_br_st = (
            -5
            * self.collid
            * (
                self.last_bk < 0.5
                or torch.mean(torch.tensor(list(self.last_sts))) < 0.2
            )
        )
        r = (
            4
            * torch.pow(
                ((self.pre_dis - dis) if self.pre_dis != None else 0) * rs * rst, 1 / 3
            )
            + r_col_br_st
            + rdiscountsteer
            + rt
            + ralive
            + 0.02
            * (
                torch.clip(self.last_th, 0, 1)
                if self.last_th < 0.8
                else 0.8 - torch.clip(self.last_th, 0, 1)
            )
            + self.reward
        )

        r = 4 * torch.pow(
            ((self.pre_dis - dis) if self.pre_dis != None else 0) * rs * rst, 1 / 3
        ) + self.reward * ((1 + speed) ** 4)
        rth = abs(self.last_thbk)

        # Route-progress reward = fraction of the per-step progress target achieved, as a linear
        # ramp in [Rdis_floor, 1]: standstill and backward motion collapse to the floor and only
        # forward progress climbs toward 1. Stays >= 0 for the geometric-mean reward.
        # Δ = how much closer to the target waypoint this step (metres).
        Rdis_floor = 0.1          # reward floor at standstill
        Rdis_ref = 0.6            # per-step progress (m) earning full reward; tune
        # Noise-free route progress (see _exact_route_progress); the GPS-differenced form is the
        # fallback. With Rdis_ref as set, the ramp spans 0.10 at a standstill, ~0.55 at 6 m/s and
        # ~0.72 at the 8.33 m/s limit.
        _exact_prog = self._exact_route_progress()
        if _exact_prog is not None:
            prog = torch.tensor(_exact_prog, dtype=torch.float32).cuda()
        else:
            prog = (self.pre_dis - dis) if self.pre_dis != None else torch.tensor(0.0).cuda()
        Rdis = Rdis_floor + (1.0 - Rdis_floor) * torch.clamp(prog / Rdis_ref, min=0.0, max=1.0)
        Ralphabeta = -0.5*(torch.exp(-20*(alpha-1))+torch.exp(-20*(beta-1)))
        Rspeed = rs
        Rsteer = rst
        Rthrottle = rth
        Rds = self.reward
        Rreverse = 0.01*self.last_reverse
        r = ((Rdis**4) * Rspeed * Rsteer * Rds) ** (1/7) + Rreverse
        
        r = r.float() if not torch.isnan(r) else torch.tensor([0]).float().cuda()

        def maybe_convert_to_tensor(x):
            if not isinstance(x, torch.Tensor):
                x = torch.tensor(x)
            x = x.squeeze().cpu()
            return x

        Rdis = maybe_convert_to_tensor(Rdis)
        Rspeed = maybe_convert_to_tensor(Rspeed)
        Rsteer = maybe_convert_to_tensor(Rsteer)
        Rds = maybe_convert_to_tensor(Rds)
        Rreverse = maybe_convert_to_tensor(Rreverse)
        r = maybe_convert_to_tensor(r)

        reward_list = [r, Rdis, Rspeed, Rsteer, Rds, Rreverse]

        self.pre_dis = dis
        return r, reward_list 

    def end_episode(self, end, collid, cause=None):
        self.end = end
        self.collid = collid
        # Drop all decimation state across the episode boundary — the next episode starts with a fresh
        # decision on its first post-warmup frame, an empty macro-reward accumulator, and no held control.
        self.held_accel_idx = None
        self.accel_hold_count = 0
        self.decimation_frame = 0
        self._macro_r6 = None
        self._held_control = None
        self._held_net = None   # cached ViT outputs for held frames (see VIT_GATE)
        # cause: 0 none/other, 1 collision/off-road, 2 red-light/stop-sign, 3 blocked/deviation.
        # When a caller omits it, infer a physical cause from the collision flag.
        if cause is not None:
            self.term_cause = int(cause)
        else:
            self.term_cause = 1 if collid else 0

    def _init(self):
        try:
            locx, locy = self._global_plan_world_coord[0][
                0].location.x, self._global_plan_world_coord[0][0].location.y
            lon, lat = self._global_plan[0][0]['lon'], self._global_plan[0][0]['lat']
            E = EARTH_RADIUS_EQUA

            def equations(vars):
                x, y = vars
                eq1 = lon * math.cos(x * math.pi / 180) - (locx * x * 180) / \
                    (math.pi * E) - math.cos(x * math.pi / 180) * y
                eq2 = math.log(math.tan((lat + 90) * math.pi / 360)) * E * math.cos(x * math.pi / 180) + \
                    locy - math.cos(x * math.pi / 180) * E * \
                    math.log(math.tan((90 + x) * math.pi / 360))
                return [eq1, eq2]
            initial_guess = [0, 0]
            solution = fsolve(equations, initial_guess)
            self.lat_ref, self.lon_ref = solution[0], solution[1]
        except Exception as e:
            print(e, flush=True)
            self.lat_ref, self.lon_ref = 0, 0
        print(self.lat_ref, self.lon_ref, self.save_name)
        
        self._route_planner = RoutePlanner(
            4.0, 50.0, lat_ref=self.lat_ref, lon_ref=self.lon_ref)
        # --- fsolve-INDEPENDENT exact progress -------------------------------------
        # Passing `_global_plan_world_coord` makes RoutePlanner carry a third element per node: the
        # same waypoint in the CARLA world frame. Waypoint SELECTION still runs on the GPS-frame
        # `pos`, and `target_point` stays in the GPS frame because it is a policy input the IL trunk
        # was trained on; only the exact-progress MEASUREMENT uses the world-frame copy, which needs
        # no lat_ref/lon_ref solve and so cannot silently disable itself.
        # A planner with the two-argument set_route signature raises TypeError here; fall back to
        # that call and let the exact-progress path disable itself (loudly, in tick).
        try:
            self._route_planner.set_route(self._global_plan, True, self._global_plan_world_coord)
        except TypeError:
            print(f"[Worker {WORKER_ID}] planner.py has no global_plan_world support -- exact route "
                  f"progress will be DISABLED. Update team_code/planner.py on this machine.",
                  flush=True)
            self._route_planner.set_route(self._global_plan, True)
        # The exact-progress window refers to this planner's nodes and to a ground-truth ego
        # position on the previous frame, so both are dropped whenever the route is rebuilt.
        # `_exact_prog_ok` re-arms for the new route.
        self._cur_route_wp = None
        self._prev_route_wp = None
        self._prev_ego_xy = None
        self._exact_prog_ok = None
        
        # ObsManager renders the BEV observation.
        world = CarlaDataProvider.get_world()
        self._vehicle = CarlaDataProvider.get_hero_actor()
        self.stop_sign_criteria = RunStopSign(world)
        # Dedicated, reward-only stop-sign tracker. The BEV's stop_sign_criteria above is never
        # ticked, so a separate instance is stepped independently each step (in _get_desired_speed)
        # to know whether the ego has yet yielded (fully stopped) at the stop sign affecting it.
        # Separate => zero side effects on the BEV rendering / policy input.
        self._reward_stop_criteria = RunStopSign(world)

        obs_config = {
            'width_in_pixels': self.config.lidar_resolution_width,
            'pixels_ev_to_bottom': self.config.lidar_resolution_height / 2.0,
            'pixels_per_meter': self.config.pixels_per_meter_collection,
            'history_idx': [-1],
            'scale_bbox': True,
            'scale_mask_col': 1.0,
            'map_folder': 'maps_2ppm_cv'
        }
        self.ss_bev_manager = ObsManager(obs_config, self.config)
        self.ss_bev_manager.attach_ego_vehicle(self._vehicle, criteria_stop=self.stop_sign_criteria)
        
        self.initialized = True
        self.metric_info = {}

    def sensors(self):
        sensors =[
                # camera rgb
                {
                    'type': 'sensor.camera.rgb',
                    'x': 0.80, 'y': 0.0, 'z': 1.60,
                    'roll': 0.0, 'pitch': 0.0, 'yaw': 0.0,
                    'width': 1600, 'height': 900, 'fov': 70,
                    'id': 'CAM_FRONT'
                },
                {
                    'type': 'sensor.camera.rgb',
                    'x': 0.27, 'y': -0.55, 'z': 1.60,
                    'roll': 0.0, 'pitch': 0.0, 'yaw': -55.0,
                    'width': 1600, 'height': 900, 'fov': 70,
                    'id': 'CAM_FRONT_LEFT'
                },
                {
                    'type': 'sensor.camera.rgb',
                    'x': 0.27, 'y': 0.55, 'z': 1.60,
                    'roll': 0.0, 'pitch': 0.0, 'yaw': 55.0,
                    'width': 1600, 'height': 900, 'fov': 70,
                    'id': 'CAM_FRONT_RIGHT'
                },
                {
                    'type': 'sensor.camera.rgb',
                    'x': -2.0, 'y': 0.0, 'z': 1.60,
                    'roll': 0.0, 'pitch': 0.0, 'yaw': 180.0,
                    'width': 1600, 'height': 900, 'fov': 110,
                    'id': 'CAM_BACK'
                },
                {
                    'type': 'sensor.camera.rgb',
                    'x': -0.32, 'y': -0.55, 'z': 1.60,
                    'roll': 0.0, 'pitch': 0.0, 'yaw': -110.0,
                    'width': 1600, 'height': 900, 'fov': 70,
                    'id': 'CAM_BACK_LEFT'
                },
                {
                    'type': 'sensor.camera.rgb',
                    'x': -0.32, 'y': 0.55, 'z': 1.60,
                    'roll': 0.0, 'pitch': 0.0, 'yaw': 110.0,
                    'width': 1600, 'height': 900, 'fov': 70,
                    'id': 'CAM_BACK_RIGHT'
                },
                # imu
                {
                    'type': 'sensor.other.imu',
                    'x': -1.4, 'y': 0.0, 'z': 0.0,
                    'roll': 0.0, 'pitch': 0.0, 'yaw': 0.0,
                    'sensor_tick': 0.05,
                    'id': 'IMU'
                },
                # gps
                {
                    'type': 'sensor.other.gnss',
                    'x': -1.4, 'y': 0.0, 'z': 0.0,
                    'roll': 0.0, 'pitch': 0.0, 'yaw': 0.0,
                    'sensor_tick': 0.01,
                    'id': 'GPS'
                },
                # speed
                {
                    'type': 'sensor.speedometer',
                    'reading_frequency': 20,
                    'id': 'SPEED'
                },
            ]
        if IS_BENCH2DRIVE:
            sensors += [
                    {	
                        'type': 'sensor.camera.rgb',
                        'x': 0.0, 'y': 0.0, 'z': 50.0,
                        'roll': 0.0, 'pitch': -90.0, 'yaw': 0.0,
                        'width': 512, 'height': 512, 'fov': 5 * 10.0,
                        'id': 'bev'
                    }]
        return sensors
        
    def tick(self, input_data):
        self.step += 1

        def process_cell(cam_id):
            img = cv2.cvtColor(input_data[cam_id][1][:, :, :3], cv2.COLOR_BGR2RGB)
            return cv2.resize(img, (298, 256))

        # Extract and resize all 6 cameras
        fl = process_cell('CAM_FRONT_LEFT')
        f  = process_cell('CAM_FRONT')
        fr = process_cell('CAM_FRONT_RIGHT')
        bl = process_cell('CAM_BACK_LEFT')
        b  = process_cell('CAM_BACK')
        br = process_cell('CAM_BACK_RIGHT')

        # Build the 2x3 Mosaic
        top_row = np.concatenate((fl, f, fr), axis=1)
        bottom_row = np.concatenate((bl, b, br), axis=1)
        full_grid = np.concatenate((top_row, bottom_row), axis=0)

        # Final resize to exactly 512x896 (H x W)
        rgb = cv2.resize(full_grid, (896, 512))
        
        # Keep original front camera for saving metadata/visuals
        rgb_front = cv2.cvtColor(input_data['CAM_FRONT'][1][:, :, :3], cv2.COLOR_BGR2RGB)

        # BEV comes from ObsManager rather than from parsing a camera sensor.
        bev_raw = self.ss_bev_manager.get_observation(None)['bev_semantic_classes']
        bev_raw = np.rot90(bev_raw)
        bev_semantic_mask = bev_raw.astype(np.uint8)

        gps = input_data['GPS'][1][:2]
        speed = input_data['SPEED'][1]['speed']
        compass = input_data['IMU'][1][-1]

        if (math.isnan(compass) == True): 
            compass = 0.0

        result = {
                'rgb': rgb,
                'rgb_front': rgb_front,
                'gps': gps,
                'speed': speed,
                'compass': compass,
                'bev': bev_semantic_mask
                }
        pos = self.gps_to_location(result['gps'])
        result['gps'] = pos
        _step = self._route_planner.run_step(pos)
        # RoutePlanner nodes are 3-tuples (gps_xy, cmd, world_transform) when set_route was given
        # `_global_plan_world_coord`, and 2-tuples otherwise; both forms are accepted.
        if len(_step) >= 3:
            next_wp, next_cmd, next_wp_world = _step[0], _step[1], _step[2]
        else:
            next_wp, next_cmd, next_wp_world = _step[0], _step[1], None
        # Exact-progress bookkeeping. The planner still chooses the waypoint from the noisy GPS
        # `pos` (selection is robust to 0.5 m); the chosen node is recorded in the world frame so
        # it can be differenced against the ground-truth ego transform without a GNSS round-trip.
        if next_wp_world is not None:
            try:
                _wloc = next_wp_world.location          # carla.Transform from the leaderboard plan
                self._cur_route_wp = np.array([_wloc.x, _wloc.y], dtype=np.float64)
            except AttributeError:
                self._cur_route_wp = np.asarray(next_wp_world, dtype=np.float64)[:2]
        else:
            self._cur_route_wp = None
        if self._exact_prog_ok is None:
            # The waypoint and the ego pose are both read from the CARLA world frame, so no
            # frame-alignment check is needed; the only failure mode is a plan with no world
            # coordinates at all.
            self._exact_prog_ok = self._cur_route_wp is not None
            if not self._exact_prog_ok:
                print(f"[Worker {WORKER_ID}] EXACT ROUTE PROGRESS DISABLED (route plan carries no "
                      f"world coordinates) -- Rdis falls back to the noisy GPS difference.", flush=True)
            else:
                print(f"[Worker {WORKER_ID}] exact route progress ACTIVE (world-frame plan).", flush=True)
        result['next_command'] = next_cmd.value
        theta = compass - np.pi/2
        R = np.array([
            [np.cos(theta), np.sin(theta)],
            [-np.sin(theta),  np.cos(theta)]
            ])

        local_command_point = np.array([next_wp[0]-pos[0], next_wp[1]-pos[1]])
        local_command_point = R.dot(local_command_point)
        result['target_point'] = tuple(local_command_point)

        return result

    @torch.no_grad()
    def run_step(self, input_data, timestamp):
        if not self.initialized:
            self._init()
        tick_data = self.tick(input_data)
        if self.step < self.config.seq_len:
            rgb = self._im_transform(tick_data['rgb']).unsqueeze(0)

            control = carla.VehicleControl()
            control.steer = 0.0
            control.throttle = 0.0
            control.brake = 0.0

            return control

        gt_velocity = torch.FloatTensor(
            [tick_data['speed']]).to('cuda', dtype=torch.float32)
        
        # Format the BEV frame
        current_bev_uint8 = tick_data['bev'].astype(np.uint8)
        # Privileged GT box/route tokens for THIS step (next_state side of the stored transition).
        current_boxes = self.get_boxes_and_route(max_obj=30, max_route=20)

        command = tick_data['next_command']
        if command < 0:
            command = 4
        command -= 1
        assert command in [0, 1, 2, 3, 4, 5]
        cmd_one_hot = [0] * 6
        cmd_one_hot[command] = 1
        cmd_one_hot = torch.tensor(cmd_one_hot).view(
            1, 6).to('cuda', dtype=torch.float32)
        speed = torch.FloatTensor([float(tick_data['speed'])]).view(
            1, 1).to('cuda', dtype=torch.float32)
        speed = speed / 12
        rgb = self._im_transform(tick_data['rgb']).unsqueeze(
            0).to('cuda', dtype=torch.float32)

        tick_data['target_point'] = [torch.FloatTensor([tick_data['target_point'][0]]),
                                     torch.FloatTensor([tick_data['target_point'][1]])]
        target_point = torch.stack(tick_data['target_point'], dim=1).to(
            'cuda', dtype=torch.float32)
        state = torch.cat([speed, target_point, cmd_one_hot], 1)
        # Camera-only stop-sign memory (route scalar #10): normalized time since the ego last fully
        # stopped. Resets to 0 when stopped, ticks up (capped) otherwise. Own speedometer only.
        ego_speed_ms = float(tick_data['speed'])
        if ego_speed_ms < STOP_SPEED_THRESH:
            self.time_since_full_stop = 0.0
        else:
            self.time_since_full_stop = min(self.time_since_full_stop + STOP_TICK_DT, STOP_MEMORY_CAP)
        stop_mem = torch.tensor([[self.time_since_full_stop / STOP_MEMORY_CAP]],
                                device='cuda', dtype=torch.float32)   # [1,1] in [0,1]
        # 10-d route measurement for the RL route adapter + critic route scalars (capture before `state`
        # is reassigned to the IL embedding below). Mirrors the prev_bev/prev_boxes one-step delay.
        current_route = torch.cat([state.detach().clone(), stop_mem], dim=1)

        # -------------------------------------------------------------------------------------
        # ROLLOUT THROUGHPUT GATE
        # The DINOv3 ViT-L forward below costs ~137 ms and only serves a decision taken every
        # DECISION_EVERY frames; on a held frame its output is discarded in favour of
        # self._held_control. The gate therefore skips it on held frames.
        #
        # It must reproduce, BEFORE the fact, the two branch conditions evaluated further down:
        #   * warmup   -- `if self.cnt < self.start_cnt` is tested AFTER the `self.cnt += 1` below,
        #                 so the look-ahead form is (self.cnt + 1) < self.start_cnt;
        #   * decision -- the same `self.decimation_frame % DECISION_EVERY` test used at the
        #                 decimation gate, read WITHOUT incrementing (the increment stays at its
        #                 original site, so the decision phase is completely unchanged).
        # Every value a held frame still consumes downstream -- the control fallbacks, the
        # pid_metadata fields, and the IL embedding -- is cached and re-emitted.
        # The backbone deliberately stays fp32: the IL embedding IS the RL state, so casting it
        # would shift the state distribution relative to the transitions already in the buffer.
        # VIT_GATE=0 restores the per-frame forward.
        # -------------------------------------------------------------------------------------
        _need_net = ((not VIT_GATE)
                     or ((self.cnt + 1) < self.start_cnt)
                     or (self.decimation_frame % DECISION_EVERY == 0)
                     or bool(self.end))
        if _need_net or self._held_net is None:
            pred = self.net(rgb, state, target_point)

            steer_ctrl, throttle_ctrl, brake_ctrl, reverse_ctrl, metadata = self.net.process_action(
                pred, tick_data['next_command'], gt_velocity, target_point)

            steer_traj, throttle_traj, brake_traj, metadata_traj = self.net.control_pid(
                pred['pred_wp'], gt_velocity, target_point)

            _il_embedding = pred['join_ctrl_inp']
            self._held_net = (steer_ctrl, throttle_ctrl, brake_ctrl, reverse_ctrl, metadata,
                              steer_traj, throttle_traj, brake_traj, metadata_traj, _il_embedding)
        else:
            (steer_ctrl, throttle_ctrl, brake_ctrl, reverse_ctrl, metadata,
             steer_traj, throttle_traj, brake_traj, metadata_traj, _il_embedding) = self._held_net

        [steer, throttle, brake, reverse] = [steer_ctrl, throttle_ctrl, brake_ctrl, reverse_ctrl]
        target = target_point
        target_achieved = False
        
        if (torch.sqrt(torch.sum(target**2)) < 15) and self.not_seen_target:
            target_achieved = True
            self.not_seen_target = False
        elif (torch.sqrt(torch.sum(target**2)) >= 15):
            self.not_seen_target = True

        if self.prev_state is not None:
            # Target speed from surrounding traffic / speed limit, normalized by /12 to
            # match the `speed` units inside get_reward (raw m/s / 12).
            self.desired_speed_norm = torch.tensor(
                self._get_desired_speed() / 12.0).float().cuda()
            reward, reward_list = self.get_reward(
                torch.tensor(tick_data["gps"]).cuda(),
                speed[0],
                target_achieved,
                torch.sqrt(torch.sum(target**2)),
                self.last_alpha,
                self.last_beta
            )
            self.pre_pos = torch.tensor(tick_data["gps"]).cuda()
            self.pre_target_wp = target_point.clone()
            self.last_reward = reward
            self.acc_reward += reward
            # 5 Hz decimation: accumulate this frame's 6 reward terms into the macro-block sum.
            # get_reward runs EVERY frame (so Rdis progress / speed are captured exactly); the sum is
            # consumed and reset at the next decision push.
            if not self.eval_act:
                self._accumulate_macro_reward(reward_list)

        # From the cache: a held frame reuses the last decision frame's embedding rather than
        # touching `pred`, which does not exist on a held frame.
        state = _il_embedding

        self.cnt += 1
        alpha_dist = torch.tensor(10.0).cuda()
        beta_dist = torch.tensor(10.0).cuda()
        
        if self.barrier_num > self.pretrain_barrier_num:
            self.is_pretraining = False
        if self.cnt < self.start_cnt:

            print('skipping..', end='\r')
            steer_traj, throttle_traj, brake_traj, reverse_traj = [steer, throttle, brake, reverse]
            temp_throttle = throttle_traj - brake_traj
            self.state_queue.append(state)
        else:
            # --- 5 Hz decimation gate: sample the policy, push ONE macro-transition, and advance the
            # state/belief chain ONLY every DECISION_EVERY frames (or on a terminal). Between decisions
            # the executed control is held and nothing is stored. Each stored (state, next_state) is
            # thus DECISION_EVERY frames apart. ---
            is_decision = (self.decimation_frame % DECISION_EVERY == 0) or bool(self.end)
            self.decimation_frame += 1
            if is_decision:
                self.step_count += 1
                if (self.prev_prev_state is not None) and not self.eval_mode:

                    self.prev_state = torch.vstack(
                        list(self.state_queue)).flatten().unsqueeze(0)
                    self.prev_action_queue = torch.vstack(list(self.action_queue)).flatten().unsqueeze(0)
                    self.state_queue.append(state)

                    state_tensor = torch.vstack(
                        list(self.state_queue)).flatten().unsqueeze(0)
                    if self.prev_action_queue is not None:
                        action_queue_cur = self.prev_action_queue.cuda()
                    else:
                        action_queue_cur = self.prev_action_queue
                    belief_t = self._belief_for(state_tensor.cuda(), current_route)
                    action, log_prob, entropy, alpha_dist, beta_dist = self.policy_net.get_actionrl(
                        state_tensor.cuda(), route=current_route, return_alphabeta=True, belief=belief_t)
                    action = self._apply_accel_hold(action)

                    action_buffer = action[:,:-1]
                    self._advance_filter(action_buffer)   # FULL_FILTER only: h advances on the EXECUTED action
                    action = torch.cat([action[:,0].unsqueeze(-1),action[:,-1].unsqueeze(-1)], dim=1)
                    action = action.detach().cpu()


                    self.action_queue.append(action_buffer[0].detach().cpu())


                    if not self.eval_act:
                        # Macro-step reward = frame-by-frame SUM of the 6 get_reward terms over the block
                        # (accumulated in self._macro_r6 every frame). The learner geo-mean is degree-1
                        # homogeneous, so calculate_reward(sum) == DECISION_EVERY x the per-frame reward,
                        # with the terminal collision penalty (term_cause) applied exactly once. The 5
                        # appended terms are taken from THIS (decision) frame.
                        macro6 = self._macro_r6 if self._macro_r6 is not None else torch.stack(
                            [t.squeeze().float().cpu() for t in reward_list])
                        self.reward_list = [macro6[k] for k in range(macro6.shape[0])]
                        if self.collid:
                            self.reward_list.append(torch.tensor(self.last_speeds[-1]).squeeze().cpu())
                            self.reward_list.append(torch.tensor(1.0))
                            self.reward_list.append(torch.tensor(self.ttc))
                        else:
                            self.reward_list.append(torch.tensor(self.last_speeds[-1]).squeeze().cpu())
                            self.reward_list.append(torch.tensor(0.0))
                            self.reward_list.append(torch.tensor(self.ttc))
                        # 10th reward term: desired (target) speed, normalized by /12 — logging only.
                        self.reward_list.append(self.desired_speed_norm.squeeze().detach().cpu())
                        # 11th reward term: termination-cause code (0 none, 1 collision/off-road,
                        # 2 red-light/stop-sign, 3 blocked/deviation) — set via end_episode one tick
                        # after collision_check fires, i.e. exactly on the stored terminal transition.
                        self.reward_list.append(torch.tensor(float(self.term_cause)))

                        self.prev_reward = torch.vstack(self.reward_list).squeeze()
                        self.reward_list = []
                        self.replay_buffer.append((self.prev_prev_state, self.prev_state, self.prev_action, self.prev_reward,
                                                state_tensor, self.prev_value, self.prev_log_prob, self.cnt, self.end, self.prev_prev_action_queue, self.prev_action_queue,
                                                self.prev_bev, current_bev_uint8, self.prev_boxes, current_boxes, self.prev_route, current_route,
                                                None, None))   # h / h_next wire slots (unused: belief is re-derived by burn-in)

                # Reset the macro-reward accumulator on EVERY decision (whether or not a transition was
                # pushed) so each stored reward covers exactly the block (D-1, D] between decisions. The
                # pre-first-transition blocks are correctly discarded.
                self._macro_r6 = None

                state_tensor = torch.vstack(
                    list(self.state_queue)).flatten().unsqueeze(0)
                action_queue_tensor = torch.vstack(list(self.action_queue)).flatten().unsqueeze(0)

                if self.prev_prev_state is None:
                    if self.prev_action_queue is not None:
                        action_queue_cur = self.prev_action_queue.cuda()
                    else:
                        action_queue_cur = self.prev_action_queue
                    belief_t = self._belief_for(state_tensor.cuda(), current_route)
                    action, log_prob, entropy, alpha_dist, beta_dist = self.policy_net.get_actionrl(
                        state_tensor.cuda(), route=current_route, return_alphabeta=True, belief=belief_t)
                    action = self._apply_accel_hold(action)

                    action_buffer = action[:,:-1]
                    self._advance_filter(action_buffer)   # FULL_FILTER only

                    action = torch.cat([action[:,0].unsqueeze(-1),action[:,-1].unsqueeze(-1)], dim=1)
                    action = action.detach().cpu()

                self.prev_prev_state = self.prev_state
                self.prev_state = state_tensor
                self.prev_prev_action_queue = self.prev_action_queue
                self.prev_action_queue = action_queue_tensor
                self.prev_action = action_buffer[0].detach().cpu()

                self.prev_log_prob = log_prob
                self.prev_entropy = entropy
                self.prev_bev = current_bev_uint8
                self.prev_boxes = current_boxes
                self.prev_route = current_route

                if self.step_count % self.update_freq == 0 or self.end:
                    if not self.eval_mode:
                        if not self.eval_act and len(self.replay_buffer) > 1:
                            self.update()
                            self.cnt_env = 0

                action = action.numpy().squeeze()
                steer_traj, throttle_traj  = action.tolist()
                throttle_traj, brake_traj, reverse_traj = Discrete_Actions_DICT[throttle_traj]
                steer_traj = steer_traj*2 - 1
                temp_throttle = throttle_traj
                # Cache the executed control so held (non-decision) frames re-emit exactly this action.
                self._held_control = (steer_traj, throttle_traj, brake_traj, reverse_traj, temp_throttle)
            else:
                # Held frame: re-emit the last decision's control. No sampling, no push, no chain advance
                # (state_queue is NOT appended, so the next stored state stays DECISION_EVERY frames out).
                if self._held_control is not None:
                    steer_traj, throttle_traj, brake_traj, reverse_traj, temp_throttle = self._held_control
                else:
                    steer_traj, throttle_traj, brake_traj, reverse_traj = [steer, throttle, brake, reverse]
                    temp_throttle = throttle_traj - brake_traj
            
            
        self.last_thbk = torch.tensor(temp_throttle).cuda().float()
        self.last_st = torch.tensor(steer_traj).cuda().float()
        self.last_th = torch.tensor(throttle_traj).cuda().float()
        self.last_bk = torch.tensor(brake_traj).cuda().float()
        self.last_reverse = reverse_traj
        self.last_sts.append(self.last_st)
        self.last_speeds.append(speed[0])
        self.last_alpha = torch.min(alpha_dist)
        self.last_beta = torch.min(beta_dist)

        if self.cnt<30:
            brake_traj = 1
            throttle_traj = 0

        steer_traj = np.clip(steer_traj, -1, 1)
        throttle_traj = np.clip(throttle_traj, 0, 1)
        brake_traj = np.clip(brake_traj, 0, 1)
        reverse_traj = True if reverse_traj else False 
        
        control = carla.VehicleControl()
        if not PLANNER_TYPE:
            raise 'please set PLANNER_TYPE'
        if PLANNER_TYPE == 'only_traj':
            self.pid_metadata = metadata_traj
            self.pid_metadata['agent'] = 'only_traj'
            control.steer = np.clip(float(steer_traj), -1, 1)
            control.throttle = np.clip(float(throttle_traj), 0, 1.0)
            control.brake = np.clip(float(brake_traj), 0, 1)
        elif PLANNER_TYPE == 'only_ctrl':
            self.pid_metadata = metadata
            self.pid_metadata['agent'] = 'only_ctrl'
            control.steer = np.clip(float(steer_traj), -1, 1)
            control.throttle = np.clip(float(throttle_traj), 0, 1.0)
            control.brake = np.clip(float(brake_traj), 0, 1)
            control.reverse = reverse_traj
        elif PLANNER_TYPE == 'merge_ctrl_traj':
            self.pid_metadata = metadata_traj
            self.pid_metadata['agent'] = 'merge_ctrl_traj'
            self.alpha = 0.5
            control.steer = np.clip(
                self.alpha*steer_traj + (1-self.alpha)*steer_ctrl, -1, 1)
            control.throttle = np.clip(
                self.alpha*throttle_traj + (1-self.alpha)*throttle_ctrl, 0, 0.75)
            control.brake = max(np.clip(float(brake_ctrl), 0, 1),
                                np.clip(float(brake_traj), 0, 1))

        self.pid_metadata['steer_ctrl'] = float(steer_ctrl)
        self.pid_metadata['steer_traj'] = float(steer_traj)
        self.pid_metadata['throttle_ctrl'] = float(throttle_ctrl)
        self.pid_metadata['throttle_traj'] = float(throttle_traj)
        self.pid_metadata['brake_ctrl'] = float(brake_ctrl)
        self.pid_metadata['brake_traj'] = float(brake_traj)

        self.pid_metadata['steer'] = control.steer
        self.pid_metadata['throttle'] = control.throttle
        self.pid_metadata['brake'] = control.brake
        metric_info = self.get_metric_info()
        self.metric_info[self.step] = metric_info
        if SAVE_PATH is not None and self.step % 1 == 0:
            self.save(tick_data)
        return control

    def save(self, tick_data):
        frame = self.step

        Image.fromarray(tick_data['rgb']).save(
            self.save_path / 'rgb' / ('%04d.png' % frame))

        Image.fromarray(tick_data['rgb_front']).save(
            self.save_path / 'rgb_front' / ('%04d.png' % frame))

        Image.fromarray(tick_data['bev']).save(
            self.save_path / 'bev' / ('%04d.png' % frame))

        outfile = open(self.save_path / 'meta' / ('%04d.json' % frame), 'w')
        json.dump(self.pid_metadata, outfile, indent=4)
        outfile.close()

        outfile = open(self.save_path / 'metric_info.json', 'w')
        json.dump(self.metric_info, outfile, indent=4)
        outfile.close()

    def destroy(self):
        if getattr(self, "_destroyed", False):
            return
        self._flush_pending_replay(reason="route_teardown")
        if hasattr(self, "net"):
            del self.net
        self._destroyed = True
        torch.cuda.empty_cache()

    def gps_to_location(self, gps):
        lat, lon = gps
        scale = math.cos(self.lat_ref * math.pi / 180.0)
        my = math.log(math.tan((lat+90) * math.pi / 360.0)) * \
            (EARTH_RADIUS_EQUA * scale)
        mx = (lon * (math.pi * EARTH_RADIUS_EQUA * scale)) / 180.0
        y = scale * EARTH_RADIUS_EQUA * \
            math.log(math.tan((90.0 + self.lat_ref) * math.pi / 360.0)) - my
        x = mx - scale * self.lon_ref * math.pi * EARTH_RADIUS_EQUA / 180.0
        return np.array([x, y])

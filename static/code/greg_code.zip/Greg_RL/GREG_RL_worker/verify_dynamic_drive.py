#!/usr/bin/env python
"""Test real-motion behavior: lane centering, emergency detection, and desired speed."""
import argparse, math, time, carla
from verify_reward_geometry import offset_axis, offset_perp, emergency_same_lane, desired_speed, yaw_bin

def true_lateral(loc, wp):
    r = wp.transform.get_right_vector()
    return abs((loc.x - wp.transform.location.x) * r.x + (loc.y - wp.transform.location.y) * r.y)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=3000)
    ap.add_argument("--town", default="Town03")
    ap.add_argument("--secs", type=float, default=60.0)
    args = ap.parse_args()

    client = carla.Client("localhost", args.port); client.set_timeout(60.0)
    world = client.load_world(args.town); time.sleep(2.0)
    amap = world.get_map()
    s = world.get_settings(); s.synchronous_mode = True; s.fixed_delta_seconds = 0.05
    world.apply_settings(s)
    tm = client.get_trafficmanager(8000); tm.set_synchronous_mode(True)

    bp = world.get_blueprint_library()
    sps = amap.get_spawn_points()
    ego = None
    for sp in sps:
        ego = world.try_spawn_actor(bp.filter("vehicle.tesla.model3")[0], sp)
        if ego: ego_sp = sp; break
    ego.set_autopilot(True, 8000)

    # Spawn emergency vehicle a few points away, also autopilot
    ebp = [b for b in bp.filter("vehicle.*") if b.has_attribute("special_type") and
           b.get_attribute("special_type").as_str() == "emergency"][0]
    emerg = None
    for sp in sps:
        if sp.location.distance(ego_sp.location) < 60 and sp.location.distance(ego_sp.location) > 8:
            emerg = world.try_spawn_actor(ebp, sp)
            if emerg: break
    if emerg is None:
        for sp in sps:
            emerg = world.try_spawn_actor(ebp, sp)
            if emerg: break
    emerg.set_autopilot(True, 8000)
    tm.ignore_lights_percentage(emerg, 100); tm.vehicle_percentage_speed_difference(emerg, -40)
    print("setup ok: ego + emergency spawned, warming up...", flush=True)
    for _ in range(20): world.tick()
    print("warmup done, logging:", flush=True)

    print(f"{'t':>4} {'orient':<14} {'axis':>6} {'perp':>6} {'true':>6} {'bet2lane':>8} {'Rds':>5} "
          f"{'emerg(same,near)':>18} {'v*':>6} {'v_lim':>6} {'spd':>5}")
    print("-" * 100)
    n_same = 0; n_near = 0; axis_err = []; perp_err = []
    steps = int(args.secs / 0.05)
    for i in range(steps):
        world.tick()
        if i % 20 != 0:   # log ~1 Hz
            continue
        if not (ego.is_alive and emerg.is_alive):
            print("an actor died (collision/despawn) -> stopping log early"); break
        try:
            loc = ego.get_location()
        except RuntimeError:
            break
        wp = amap.get_waypoint(loc, project_to_road=True, lane_type=carla.LaneType.Driving)
        if wp is None:
            continue
        o_axis = offset_axis(loc, wp); o_perp = offset_perp(loc, wp); tl = true_lateral(loc, wp)
        hw = max(wp.lane_width * 0.5, 0.1)
        bet = min(max(o_perp / hw, 0.0), 1.0)          # 0 = centered .. 1 = over the lane marking
        rds = 1 - 0.9 * bet
        same, near = emergency_same_lane(ego, world)
        vstar, vlim = desired_speed(ego, world)
        vel = ego.get_velocity(); spd = (vel.x**2 + vel.y**2 + vel.z**2) ** 0.5
        n_same += int(same); n_near += int(near)
        axis_err.append(abs(o_axis - tl)); perp_err.append(abs(o_perp - tl))
        print(f"{i*0.05:>4.0f} {yaw_bin(wp.transform.rotation.yaw):<14} {o_axis:>6.2f} {o_perp:>6.2f} "
              f"{tl:>6.2f} {bet:>8.2f} {rds:>5.2f} {str((same,near)):>18} {vstar:>6.1f} {vlim:>6.1f} {spd:>5.1f}")

    m = len(perp_err) or 1
    print("-" * 100)
    print(f"samples={len(perp_err)}  emergency same-lane ticks={n_same}  near ticks={n_near}")
    print(f"mean |perp - true| = {sum(perp_err)/m:.3f} m  (should be ~0)")
    print(f"mean |axis - true| = {sum(axis_err)/m:.3f} m  (large on non-E-W headings)")
    ego.destroy(); emerg.destroy()
    s.synchronous_mode = False; world.apply_settings(s); tm.set_synchronous_mode(False)
    print("DONE.")

if __name__ == "__main__":
    main()

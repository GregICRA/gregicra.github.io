"""Oncoming head-on collision with dramatic barrel-roll flip — Town04."""

import math
import time
from typing import Optional

import carla
import py_trees

from srunner.scenarios.basic_scenario import BasicScenario
from srunner.scenariomanager.carla_data_provider import CarlaDataProvider
from srunner.scenariomanager.scenarioatomics.atomic_criteria import CollisionTest
from srunner.scenariomanager.scenarioatomics.atomic_trigger_conditions import (
    InTriggerDistanceToLocation,
)
from srunner.scenariomanager.scenarioatomics.custom_atomics import (
    EgoSpeedGovernor,
    HoldUntilEgoMoves,
)
from srunner.scenariomanager.timer import GameTime, TimeOut


def _speed_mps(actor):
    if actor is None or not actor.is_alive:
        return 0.0
    v = actor.get_velocity()
    return math.sqrt(v.x ** 2 + v.y ** 2 + v.z ** 2)


def _planar_distance(loc_a, loc_b):
    return math.hypot(loc_a.x - loc_b.x, loc_a.y - loc_b.y)


class _RunOncomingFlipManeuver(py_trees.behaviour.Behaviour):
    """
    Oncoming vehicle drives toward ego in the opposite lane, then swerves
    across the center line.  On collision, applies dramatic barrel-roll
    flip physics.
    """

    def __init__(self, scenario, name="RunOncomingFlipManeuver"):
        super().__init__(name)
        self._scenario = scenario
        self._start_time = None
        self._crossover_started = False
        self._flip_applied = False
        self._last_log = -999.0

    def initialise(self):
        self._start_time = GameTime.get_time()

    def _apply_flip_physics(self):
        """Apply dramatic barrel-roll flip on collision."""
        if self._flip_applied:
            return
        self._flip_applied = True

        scenario = self._scenario
        adv = scenario._adversary
        if adv is not None and adv.is_alive:
            # Stop the adversary after collision (flip removed to avoid TickRuntime crash)
            adv.set_target_velocity(carla.Vector3D(0, 0, 0))
            print(f"[HeadOnFlip] Adversary stopped after head-on collision", flush=True)

    def update(self):
        scenario = self._scenario
        if scenario._impact_detected:
            print(f"[HeadOnFlip] *** HEAD-ON COLLISION ***", flush=True)
            self._apply_flip_physics()
            return py_trees.common.Status.SUCCESS

        elapsed = GameTime.get_time() - self._start_time if self._start_time else 0.0

        adv = scenario._adversary
        ego = scenario._ego
        if adv is None or not adv.is_alive or ego is None or not ego.is_alive:
            return py_trees.common.Status.FAILURE

        ego_loc = ego.get_location()
        adv_loc = adv.get_location()
        dist = _planar_distance(ego_loc, adv_loc)

        # Phase 1: oncoming vehicle drives straight toward ego
        # Phase 2: when close enough, swerve across centerline
        if not self._crossover_started and dist <= scenario._crossover_trigger_distance:
            self._crossover_started = True
            print(f"[HeadOnFlip] Distance {dist:.1f}m — adversary crosses centerline!", flush=True)

        if self._crossover_started:
            # Aim directly at ego using set_target_velocity
            dx = ego_loc.x - adv_loc.x
            dy = ego_loc.y - adv_loc.y
            mag = math.sqrt(dx * dx + dy * dy)
            if mag > 0.5:
                speed = scenario._adversary_speed
                adv.set_target_velocity(carla.Vector3D(
                    speed * dx / mag, speed * dy / mag, 0.0))
        else:
            # Drive straight in forward direction at target speed
            fwd = adv.get_transform().get_forward_vector()
            speed = scenario._adversary_speed
            adv.set_target_velocity(carla.Vector3D(
                speed * fwd.x, speed * fwd.y, 0.0))

        if elapsed - self._last_log >= 1.0:
            self._last_log = elapsed
            ego_spd = _speed_mps(ego) * 3.6
            adv_spd = _speed_mps(adv) * 3.6
            print(f"[HeadOnFlip] t={elapsed:.1f}s  ego={ego_spd:.0f}km/h  "
                  f"adv={adv_spd:.0f}km/h  dist={dist:.1f}m  "
                  f"xover={self._crossover_started}  impact={scenario._impact_detected}",
                  flush=True)

        if elapsed >= scenario._max_run_time:
            return py_trees.common.Status.FAILURE
        return py_trees.common.Status.RUNNING


class _PostImpactHold(py_trees.behaviour.Behaviour):
    def __init__(self, duration, name="PostImpactHold"):
        super().__init__(name)
        self._duration = float(duration)
        self._start_time = None

    def initialise(self):
        self._start_time = GameTime.get_time()

    def update(self):
        elapsed = GameTime.get_time() - self._start_time if self._start_time else 0.0
        if elapsed >= self._duration:
            return py_trees.common.Status.SUCCESS
        return py_trees.common.Status.RUNNING


class _EgoMinSpeedForcer(py_trees.behaviour.Behaviour):
    """Override autopilot braking — force ego to maintain minimum speed."""

    def __init__(self, ego, min_speed_kmh=68.0, throttle=0.8,
                 name="EgoMinSpeedForcer"):
        super().__init__(name)
        self._ego = ego
        self._min_mps = float(min_speed_kmh) / 3.6
        self._throttle = float(throttle)

    def update(self):
        if self._ego is None or not self._ego.is_alive:
            return py_trees.common.Status.RUNNING
        v = self._ego.get_velocity()
        speed = math.sqrt(v.x ** 2 + v.y ** 2 + v.z ** 2)
        if speed > 5.0 and speed < self._min_mps:
            ctrl = self._ego.get_control()
            ctrl.brake = 0.0
            ctrl.throttle = self._throttle
            self._ego.apply_control(ctrl)
        return py_trees.common.Status.RUNNING


class OncomingHeadOnFlip(BasicScenario):
    """
    Variant of the oncoming head-on scenario with dramatic barrel-roll
    flip physics on impact.  An oncoming vehicle crosses the center line
    at high speed into ego's lane.  The combined closing speed (160+ km/h)
    results in a dramatic flip when collision is detected.

    XML other_parameters:
      activation_distance_m         - trigger proximity
      adversary_speed_kmh           - oncoming vehicle speed
      crossover_trigger_distance_m  - distance at which adversary starts swerving
      crossover_steer_gain          - gain for steering toward ego
      flip_launch_z_mps             - upward velocity on collision
      flip_roll_rate                - roll angular velocity (rad/s)
      flip_pitch_rate               - pitch angular velocity (rad/s)
      ego_speed_cap_kmh             - ego speed governor cap
      ego_cap_brake                 - brake force when above cap
      road_friction_scale           - global friction modifier
      max_run_time                  - scenario timeout
      post_impact_hold              - hold duration after collision (extended for flip)
    """

    timeout = 120

    @staticmethod
    def _get_param(op, name, default, cast=float):
        if not op or name not in op:
            return default
        raw = op[name]
        try:
            if isinstance(raw, dict):
                return cast(raw.get("value", default))
            return cast(raw)
        except (TypeError, ValueError):
            return default

    def __init__(self, world, ego_vehicles, config,
                 randomize=False, debug_mode=False, criteria_enable=True,
                 timeout=120):
        self._world = world
        self._map = CarlaDataProvider.get_map()
        self._ego = ego_vehicles[0]

        op = config.other_parameters if hasattr(config, "other_parameters") else {}
        self._activation_distance = self._get_param(op, "activation_distance_m", 100.0)
        self._adversary_speed = self._get_param(op, "adversary_speed_kmh", 90.0) / 3.6
        self._crossover_trigger_distance = self._get_param(
            op, "crossover_trigger_distance_m", 30.0)
        self._crossover_steer_gain = self._get_param(op, "crossover_steer_gain", 1.5)
        self._flip_launch_z = self._get_param(op, "flip_launch_z_mps", 7.0)
        self._flip_roll_rate = self._get_param(op, "flip_roll_rate", 6.0)
        self._flip_pitch_rate = self._get_param(op, "flip_pitch_rate", 3.0)
        self._ego_speed_cap_kmh = self._get_param(op, "ego_speed_cap_kmh", 72.0)
        self._ego_min_speed_kmh = self._get_param(op, "ego_min_speed_kmh", 68.0)
        self._ego_cap_brake = self._get_param(op, "ego_cap_brake", 0.10)
        self._road_friction_scale = self._get_param(op, "road_friction_scale", 0.6)
        self._max_run_time = self._get_param(op, "max_run_time", 10.0)
        self._post_impact_hold = self._get_param(op, "post_impact_hold", 5.0)

        self._trigger_wp = self._map.get_waypoint(config.trigger_points[0].location)
        self._adversary: Optional[carla.Vehicle] = None
        self._collision_sensor = None
        self._impact_detected = False

        super().__init__(
            name="OncomingHeadOnFlip",
            ego_vehicles=ego_vehicles,
            config=config,
            world=world,
            debug_mode=debug_mode,
            terminate_on_failure=True,
            criteria_enable=criteria_enable,
        )

    def _initialize_environment(self, world):
        super()._initialize_environment(world)
        friction = max(0.1, float(self._road_friction_scale))
        if abs(friction - 1.0) < 1e-6:
            return
        bp = world.get_blueprint_library().find("static.trigger.friction")
        bp.set_attribute("friction", str(friction))
        bp.set_attribute("extent_x", "1000000.0")
        bp.set_attribute("extent_y", "1000000.0")
        bp.set_attribute("extent_z", "1000000.0")
        try:
            world.spawn_actor(bp, carla.Transform(carla.Location(-10000.0, -10000.0, 0.0)))
        except RuntimeError:
            pass

    def _initialize_actors(self, config):
        # Adversary spawns in the opposite lane, facing ego
        if config.other_actors and len(config.other_actors) > 0:
            actor_config = config.other_actors[0]
            adv_transform = carla.Transform(
                carla.Location(
                    x=actor_config.transform.location.x,
                    y=actor_config.transform.location.y,
                    z=actor_config.transform.location.z + 0.5,
                ),
                actor_config.transform.rotation,
            )
        else:
            # Fallback: use trigger point on opposite lane
            ego_wp = self._map.get_waypoint(self._ego.get_location())
            # Find opposite lane
            opp_wp = ego_wp.get_left_lane()
            if opp_wp is None:
                opp_wp = ego_wp.get_right_lane()
            if opp_wp is None:
                opp_wp = ego_wp
            # Spawn ahead in opposite direction
            adv_wp = opp_wp
            for _ in range(10):
                nexts = adv_wp.next(8.0)
                if nexts:
                    adv_wp = nexts[0]
            adv_transform = carla.Transform(
                carla.Location(
                    adv_wp.transform.location.x,
                    adv_wp.transform.location.y,
                    adv_wp.transform.location.z + 0.5,
                ),
                carla.Rotation(
                    yaw=adv_wp.transform.rotation.yaw + 180.0,
                ),
            )

        adv_models = [
            "vehicle.dodge.charger_2020",
            "vehicle.ford.mustang",
            "vehicle.chevrolet.impala",
            "vehicle.tesla.model3",
        ]
        self._adversary = None
        for model in adv_models:
            self._adversary = CarlaDataProvider.request_new_actor(
                model, adv_transform, rolename="oncoming_vehicle",
            )
            if self._adversary is not None:
                break
        if self._adversary is None:
            raise RuntimeError("[HeadOnFlip] Adversary spawn failed")

        self._adversary.set_simulate_physics(True)
        self.other_actors.append(self._adversary)

        # Collision sensor
        collision_bp = self._world.get_blueprint_library().find("sensor.other.collision")
        self._collision_sensor = self._world.spawn_actor(
            collision_bp, carla.Transform(), attach_to=self._ego,
        )
        self._collision_sensor.listen(lambda event: self._on_collision(event))

        print(
            f"\n[HeadOnFlip] Spawn\n"
            f"  Adversary at ({adv_transform.location.x:.1f}, "
            f"{adv_transform.location.y:.1f}) yaw={adv_transform.rotation.yaw:.1f}\n"
            f"  speed={self._adversary_speed * 3.6:.0f}km/h  "
            f"xover_dist={self._crossover_trigger_distance:.0f}m  "
            f"friction={self._road_friction_scale:.2f}\n"
            f"  flip: z={self._flip_launch_z:.1f}  roll={self._flip_roll_rate:.1f}  "
            f"pitch={self._flip_pitch_rate:.1f}\n",
            flush=True,
        )

    def _on_collision(self, event):
        if not self._impact_detected:
            self._impact_detected = True
            print(f"[HeadOnFlip] *** COLLISION: {event.other_actor.type_id} ***", flush=True)

    def _setup_scenario_trigger(self, config):
        return InTriggerDistanceToLocation(
            self._ego,
            self._trigger_wp.transform.location,
            self._activation_distance,
            name="ActivateOncomingHeadOnFlip",
        )

    def _create_behavior(self):
        root = py_trees.composites.Sequence("OncomingHeadOnFlipSequence")

        sync = py_trees.composites.Parallel(
            "Phase0_Sync",
            policy=py_trees.common.ParallelPolicy.SUCCESS_ON_ALL,
        )
        sync.add_child(HoldUntilEgoMoves(self._adversary, self._ego))
        root.add_child(sync)

        main_loop = py_trees.composites.Parallel(
            "Phase1_MainLoop",
            policy=py_trees.common.ParallelPolicy.SUCCESS_ON_ONE,
        )
        main_loop.add_child(_RunOncomingFlipManeuver(self))
        main_loop.add_child(EgoSpeedGovernor(
            self._ego,
            speed_cap_kmh=self._ego_speed_cap_kmh,
            brake_force=self._ego_cap_brake,
        ))
        main_loop.add_child(_EgoMinSpeedForcer(
            self._ego, min_speed_kmh=self._ego_min_speed_kmh))
        main_loop.add_child(TimeOut(self._max_run_time))
        root.add_child(main_loop)

        root.add_child(_PostImpactHold(self._post_impact_hold))
        return root

    def _create_test_criteria(self):
        criteria = py_trees.composites.Parallel(
            "OncomingHeadOnFlipCriteria",
            policy=py_trees.common.ParallelPolicy.SUCCESS_ON_ONE,
        )
        criteria.add_child(CollisionTest(self._ego))
        return criteria

    def remove_all_actors(self):
        if self._collision_sensor is not None and self._collision_sensor.is_alive:
            self._collision_sensor.stop()
            self._collision_sensor.destroy()
            self._collision_sensor = None
        super().remove_all_actors()

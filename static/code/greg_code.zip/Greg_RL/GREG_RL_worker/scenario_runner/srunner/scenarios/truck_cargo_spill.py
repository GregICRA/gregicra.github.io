"""Truck cargo spill collision for Town04 highway — debris falls from truck ahead."""

import math

import carla
import py_trees

from srunner.scenariomanager.carla_data_provider import CarlaDataProvider
from srunner.scenariomanager.scenarioatomics.atomic_behaviors import ActorDestroy
from srunner.scenariomanager.scenarioatomics.atomic_criteria import CollisionTest
from srunner.scenariomanager.scenarioatomics.atomic_trigger_conditions import (
    InTriggerDistanceToLocation,
)
from srunner.scenariomanager.scenarioatomics.custom_atomics import (
    EgoSpeedGovernor,
    HoldUntilEgoMoves,
)
from srunner.scenariomanager.timer import GameTime, TimeOut
from srunner.scenarios.basic_scenario import BasicScenario


def _speed_mps(actor):
    if actor is None or not actor.is_alive:
        return 0.0
    v = actor.get_velocity()
    return math.sqrt(v.x ** 2 + v.y ** 2 + v.z ** 2)


def _planar_distance(loc_a, loc_b):
    return math.hypot(loc_a.x - loc_b.x, loc_a.y - loc_b.y)


class _EgoMinSpeedForcer(py_trees.behaviour.Behaviour):
    """Override autopilot braking — force ego to maintain minimum speed."""

    def __init__(self, ego, min_speed_kmh=75.0, throttle=0.8,
                 name="EgoMinSpeedForcer"):
        super().__init__(name)
        self._ego = ego
        self._min_mps = float(min_speed_kmh) / 3.6
        self._throttle = float(throttle)

    def update(self):
        if self._ego is None or not self._ego.is_alive:
            return py_trees.common.Status.RUNNING
        v = self._ego.get_velocity()
        speed = math.sqrt(v.x ** 2 + v.y ** 2 + v.z ** 2)
        if speed > 5.0 and speed < self._min_mps:
            ctrl = self._ego.get_control()
            ctrl.brake = 0.0
            ctrl.throttle = self._throttle
            self._ego.apply_control(ctrl)
        return py_trees.common.Status.RUNNING


class _RunCargoSpill(py_trees.behaviour.Behaviour):
    """
    Drive the truck ahead at cruise speed.  After a delay, spawn debris
    objects behind the truck that tumble into ego's path.
    """

    def __init__(self, scenario, name="RunCargoSpill"):
        super().__init__(name)
        self._scenario = scenario
        self._start_time = None
        self._brake_started = False
        self._debris_spawned = False
        self._last_log = -999.0

    def initialise(self):
        self._start_time = GameTime.get_time()

    def _spawn_debris(self):
        """Spawn debris objects behind the truck."""
        scenario = self._scenario
        truck = scenario._truck
        if truck is None or not truck.is_alive:
            return

        truck_t = truck.get_transform()
        truck_fwd = truck_t.get_forward_vector()
        truck_right = truck_t.get_right_vector()
        truck_loc = truck_t.location

        # Spawn debris behind truck (negative forward) with some spread
        offsets = [
            (-8.0, 0.0, 1.5),    # center, slightly behind
            (-10.0, 1.5, 2.0),   # right offset
            (-9.0, -1.2, 1.8),   # left offset
        ]

        prop_models = [
            "static.prop.box01",
            "static.prop.box02",
            "static.prop.box03",
        ]

        for i, (fwd_off, lat_off, z_off) in enumerate(offsets):
            spawn_x = truck_loc.x + truck_fwd.x * fwd_off + truck_right.x * lat_off
            spawn_y = truck_loc.y + truck_fwd.y * fwd_off + truck_right.y * lat_off
            spawn_z = truck_loc.z + z_off

            spawn_t = carla.Transform(
                carla.Location(x=spawn_x, y=spawn_y, z=spawn_z),
                truck_t.rotation,
            )

            model = prop_models[i % len(prop_models)]
            try:
                debris = CarlaDataProvider.request_new_actor(
                    model, spawn_t, rolename=f"debris_{i}",
                )
                if debris is not None:
                    debris.set_simulate_physics(True)
                    # Give debris some forward velocity matching truck, plus tumble
                    truck_v = truck.get_velocity()
                    debris.set_target_velocity(carla.Vector3D(
                        truck_v.x * 0.3,
                        truck_v.y * 0.3,
                        scenario._debris_launch_z,
                    ))
                    if hasattr(debris, "set_angular_velocity"):
                        debris.set_angular_velocity(carla.Vector3D(
                            3.0 * (1 if i % 2 == 0 else -1),
                            2.0,
                            1.0,
                        ))
                    scenario._debris_actors.append(debris)
                    scenario.other_actors.append(debris)
                    print(f"[CargoSpill] Spawned debris {i}: {model} at "
                          f"({spawn_x:.1f}, {spawn_y:.1f}, {spawn_z:.1f})", flush=True)
            except RuntimeError as e:
                print(f"[CargoSpill] Debris {i} spawn failed: {e}", flush=True)

    def update(self):
        scenario = self._scenario
        if scenario._impact_detected:
            print(f"[CargoSpill] *** IMPACT DETECTED ***", flush=True)
            return py_trees.common.Status.SUCCESS

        elapsed = GameTime.get_time() - self._start_time if self._start_time else 0.0

        truck = scenario._truck
        ego = scenario._ego
        if truck is None or not truck.is_alive:
            return py_trees.common.Status.FAILURE

        ego_loc = ego.get_location()
        truck_loc = truck.get_location()
        dist = _planar_distance(ego_loc, truck_loc)

        if not self._brake_started:
            # Mirror ego's velocity to maintain constant following distance
            ego_v = ego.get_velocity()
            truck.set_target_velocity(carla.Vector3D(ego_v.x, ego_v.y, ego_v.z))

            # When ego is at speed and has been driving for a few seconds, brake
            ego_speed_kmh = _speed_mps(ego) * 3.6
            if ego_speed_kmh > 65 and elapsed > 5.0:
                self._brake_started = True
                # Instant stop via set_target_velocity
                truck.set_target_velocity(carla.Vector3D(0, 0, 0))
                truck.apply_control(carla.VehicleControl(
                    throttle=0, brake=1.0, steer=0.0))
                # Skip debris spawning (causes simulator freeze)
                self._debris_spawned = True
                print(f"[CargoSpill] TRUCK EMERGENCY BRAKE! dist={dist:.1f}m "
                      f"ego={ego_speed_kmh:.0f}km/h", flush=True)
        else:
            # Keep truck stopped
            truck.set_target_velocity(carla.Vector3D(0, 0, 0))
            truck.apply_control(carla.VehicleControl(
                throttle=0, brake=1.0, steer=0.0))

        # Status log
        if elapsed - self._last_log >= 2.0:
            self._last_log = elapsed
            ego_spd = _speed_mps(scenario._ego) * 3.6
            truck_spd = _speed_mps(scenario._truck) * 3.6 if scenario._truck else 0
            print(f"[CargoSpill] t={elapsed:.1f}s  ego={ego_spd:.0f}km/h  "
                  f"truck={truck_spd:.0f}km/h  dist={dist:.1f}m  "
                  f"brake={self._brake_started}  impact={scenario._impact_detected}",
                  flush=True)

        if elapsed >= scenario._max_run_time:
            return py_trees.common.Status.FAILURE
        return py_trees.common.Status.RUNNING


class _PostImpactHold(py_trees.behaviour.Behaviour):
    """Hold the crash scene for video."""

    def __init__(self, scenario, duration, name="PostImpactHold"):
        super().__init__(name)
        self._scenario = scenario
        self._duration = float(duration)
        self._start_time = None

    def initialise(self):
        self._start_time = GameTime.get_time()

    def update(self):
        elapsed = GameTime.get_time() - self._start_time if self._start_time else 0.0
        if elapsed >= self._duration:
            return py_trees.common.Status.SUCCESS
        return py_trees.common.Status.RUNNING


class TruckCargoSpill(BasicScenario):
    """
    A truck ahead of ego loses cargo on the highway.  Debris objects fall
    and tumble into ego's lane.  Ego collides with the debris at high speed.

    XML other_parameters:
      activation_distance_m       - trigger proximity
      truck_ahead_distance_m      - truck spawn offset ahead of ego (m)
      truck_speed_kmh             - truck cruise speed
      debris_spawn_delay_s        - seconds before debris falls from truck
      debris_launch_z_mps         - upward velocity of debris on spawn
      ego_speed_cap_kmh           - ego speed governor cap
      ego_cap_brake               - brake force when above cap
      max_run_time                - scenario timeout
      post_impact_hold            - hold duration after collision
      road_friction_scale         - global friction modifier
    """

    timeout = 180

    @staticmethod
    def _get_param(op, name, default, cast=float):
        if not op or name not in op:
            return default
        raw = op[name]
        try:
            if isinstance(raw, dict):
                return cast(raw.get("value", default))
            return cast(raw)
        except (TypeError, ValueError):
            return default

    def __init__(self, world, ego_vehicles, config,
                 randomize=False, debug_mode=False, criteria_enable=True,
                 timeout=180):
        self._world = world
        self._map = CarlaDataProvider.get_map()
        self._ego = ego_vehicles[0]

        op = config.other_parameters if hasattr(config, "other_parameters") else {}
        self._activation_distance = self._get_param(op, "activation_distance_m", 130.0)
        self._truck_ahead_distance = self._get_param(op, "truck_ahead_distance_m", 20.0)
        self._truck_speed = self._get_param(op, "truck_speed_kmh", 70.0) / 3.6
        self._debris_spawn_delay = self._get_param(op, "debris_spawn_delay_s", 4.0)
        self._debris_launch_z = self._get_param(op, "debris_launch_z_mps", 3.0)
        self._ego_speed_cap_kmh = self._get_param(op, "ego_speed_cap_kmh", 80.0)
        self._ego_min_speed_kmh = self._get_param(op, "ego_min_speed_kmh", 75.0)
        self._ego_cap_brake = self._get_param(op, "ego_cap_brake", 0.10)
        self._brake_trigger_distance = self._get_param(op, "brake_trigger_distance_m", 18.0)
        self._max_run_time = self._get_param(op, "max_run_time", 20.0)
        self._post_impact_hold = self._get_param(op, "post_impact_hold", 6.0)
        self._road_friction_scale = self._get_param(op, "road_friction_scale", 1.0)
        self._truck_model = str(self._get_param(
            op, "truck_model", "vehicle.carlamotors.european_hgv", cast=str))

        self._trigger_wp = self._map.get_waypoint(config.trigger_points[0].location)
        self._truck = None
        self._debris_actors = []
        self._collision_sensor = None
        self._impact_detected = False

        super().__init__(
            name="TruckCargoSpill",
            ego_vehicles=ego_vehicles,
            config=config,
            world=world,
            debug_mode=debug_mode,
            terminate_on_failure=True,
            criteria_enable=criteria_enable,
        )

    def _initialize_environment(self, world):
        super()._initialize_environment(world)
        friction = max(0.1, float(self._road_friction_scale))
        if abs(friction - 1.0) < 1e-6:
            return
        bp = world.get_blueprint_library().find("static.trigger.friction")
        bp.set_attribute("friction", str(friction))
        bp.set_attribute("extent_x", "1000000.0")
        bp.set_attribute("extent_y", "1000000.0")
        bp.set_attribute("extent_z", "1000000.0")
        try:
            world.spawn_actor(bp, carla.Transform(carla.Location(-10000.0, -10000.0, 0.0)))
        except RuntimeError:
            pass

    @staticmethod
    def _walk_waypoint(waypoint, distance, forward=True):
        remaining = abs(float(distance))
        cursor = waypoint
        while remaining > 0.2 and cursor is not None:
            step = min(8.0, remaining)
            candidates = cursor.next(step) if forward else cursor.previous(step)
            if not candidates:
                break
            cursor = candidates[0]
            remaining -= step
        return cursor

    def _initialize_actors(self, config):
        ego_wp = self._map.get_waypoint(
            self._ego.get_location(), project_to_road=True,
            lane_type=carla.LaneType.Driving,
        )

        # Truck ahead in same lane
        truck_wp = self._walk_waypoint(
            ego_wp, self._truck_ahead_distance, forward=True
        ) or ego_wp

        truck_transform = carla.Transform(
            carla.Location(
                truck_wp.transform.location.x,
                truck_wp.transform.location.y,
                truck_wp.transform.location.z + 0.5,
            ),
            truck_wp.transform.rotation,
        )

        truck_models = [self._truck_model, "vehicle.carlamotors.carlacola",
                        "vehicle.tesla.cybertruck"]
        self._truck = None
        for model in truck_models:
            self._truck = CarlaDataProvider.request_new_actor(
                model, truck_transform, rolename="cargo_truck",
            )
            if self._truck is not None:
                break

        if self._truck is None:
            raise RuntimeError("[CargoSpill] Truck spawn failed")
        self._truck.set_simulate_physics(True)
        self.other_actors.append(self._truck)

        # Attach collision sensor to ego
        collision_bp = self._world.get_blueprint_library().find("sensor.other.collision")
        self._collision_sensor = self._world.spawn_actor(
            collision_bp, carla.Transform(), attach_to=self._ego,
        )
        self._collision_sensor.listen(lambda event: self._on_collision(event))

        print(
            f"\n[CargoSpill] Spawn\n"
            f"  Ego road={ego_wp.road_id} lane={ego_wp.lane_id}\n"
            f"  Truck road={truck_wp.road_id} lane={truck_wp.lane_id} "
            f"ahead={self._truck_ahead_distance:.1f}m speed={self._truck_speed * 3.6:.1f} km/h\n"
            f"  debris_delay={self._debris_spawn_delay:.1f}s\n",
            flush=True,
        )

    def _on_collision(self, event):
        if not self._impact_detected:
            self._impact_detected = True
            print(f"[CargoSpill] *** COLLISION: {event.other_actor.type_id} ***", flush=True)

    def _setup_scenario_trigger(self, config):
        return InTriggerDistanceToLocation(
            self._ego,
            self._trigger_wp.transform.location,
            self._activation_distance,
            name="ActivateTruckCargoSpill",
        )

    def _create_behavior(self):
        root = py_trees.composites.Sequence("TruckCargoSpillSequence")

        # Phase 0: wait for ego to start moving
        sync = py_trees.composites.Parallel(
            "Phase0_Sync",
            policy=py_trees.common.ParallelPolicy.SUCCESS_ON_ALL,
        )
        sync.add_child(HoldUntilEgoMoves(self._truck, self._ego))
        root.add_child(sync)

        # Phase 1: main scenario loop (truck drives, debris spawns, collision detected)
        main_loop = py_trees.composites.Parallel(
            "Phase1_MainLoop",
            policy=py_trees.common.ParallelPolicy.SUCCESS_ON_ONE,
        )
        main_loop.add_child(_RunCargoSpill(self))
        main_loop.add_child(EgoSpeedGovernor(
            self._ego,
            speed_cap_kmh=self._ego_speed_cap_kmh,
            brake_force=self._ego_cap_brake,
        ))
        main_loop.add_child(_EgoMinSpeedForcer(
            self._ego, min_speed_kmh=self._ego_min_speed_kmh))
        main_loop.add_child(TimeOut(self._max_run_time))
        root.add_child(main_loop)

        # Phase 2: post-impact hold
        root.add_child(_PostImpactHold(self, self._post_impact_hold))

        # Cleanup
        root.add_child(ActorDestroy(self._truck, name="DestroyTruck"))
        return root

    def _create_test_criteria(self):
        criteria = py_trees.composites.Parallel(
            "TruckCargoSpillCriteria",
            policy=py_trees.common.ParallelPolicy.SUCCESS_ON_ONE,
        )
        criteria.add_child(CollisionTest(self._ego))
        return criteria

    def remove_all_actors(self):
        if self._collision_sensor is not None and self._collision_sensor.is_alive:
            self._collision_sensor.stop()
            self._collision_sensor.destroy()
            self._collision_sensor = None
        for debris in self._debris_actors:
            if debris is not None and debris.is_alive:
                try:
                    debris.destroy()
                except RuntimeError:
                    pass
        self._debris_actors.clear()
        super().remove_all_actors()

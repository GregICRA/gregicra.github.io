"""Truck blind-spot lane-change collision with heavy surrounding traffic – Town04."""

import math

import carla
import py_trees

from srunner.scenariomanager.carla_data_provider import CarlaDataProvider
from srunner.scenariomanager.scenarioatomics.atomic_behaviors import (
    ActorDestroy,
    WaypointFollower,
)
from srunner.scenariomanager.scenarioatomics.atomic_criteria import CollisionTest
from srunner.scenariomanager.scenarioatomics.atomic_trigger_conditions import (
    InTriggerDistanceToLocation,
)
from srunner.scenariomanager.scenarioatomics.custom_atomics import (
    EgoSpeedGovernor,
    HoldUntilEgoMoves,
    LaneCleaner,
    PeriodicStatusLogger,
    StopActorsOnEgoCollision,
)
from srunner.scenariomanager.timer import TimeOut
from srunner.scenarios.basic_scenario import BasicScenario


# ── tiny helpers (same as base scenario) ─────────────────────────────────────

class _OneShot(py_trees.behaviour.Behaviour):
    def __init__(self, callback, name="OneShot"):
        super().__init__(name)
        self._callback = callback
        self._done = False

    def update(self):
        if not self._done:
            self._callback()
            self._done = True
        return py_trees.common.Status.SUCCESS


class _WaitUntilAlongside(py_trees.behaviour.Behaviour):
    """SUCCESS when the truck is alongside the ego (small forward offset)."""

    def __init__(self, ego, truck, max_forward_m=4.0,
                 name="WaitUntilAlongside"):
        super().__init__(name)
        self._ego = ego
        self._truck = truck
        self._max_fwd = float(max_forward_m)

    def update(self):
        if not (self._ego and self._truck
                and self._ego.is_alive and self._truck.is_alive):
            return py_trees.common.Status.RUNNING

        truck_t = self._truck.get_transform()
        ego_loc = self._ego.get_location()
        truck_loc = truck_t.location

        dx = ego_loc.x - truck_loc.x
        dy = ego_loc.y - truck_loc.y

        fwd = truck_t.get_forward_vector()
        forward_offset = dx * fwd.x + dy * fwd.y

        if abs(forward_offset) <= self._max_fwd:
            return py_trees.common.Status.SUCCESS
        return py_trees.common.Status.RUNNING


class _ForcedLaneChange(py_trees.behaviour.Behaviour):
    """Override velocity each tick: forward + lateral drift."""

    def __init__(self, actor, forward_speed_ms, lateral_speed_ms=4.0,
                 duration=1.0, lateral_sign=1.0, name="ForcedLaneChange"):
        super().__init__(name)
        self._actor = actor
        self._forward_speed = float(forward_speed_ms)
        self._lateral_speed = float(lateral_speed_ms)
        self._duration = float(duration)
        self._lateral_sign = float(lateral_sign)
        self._start_time = None

    def initialise(self):
        from srunner.scenariomanager.timer import GameTime
        self._start_time = GameTime.get_time()

    def update(self):
        from srunner.scenariomanager.timer import GameTime
        if self._actor is None or not self._actor.is_alive:
            return py_trees.common.Status.SUCCESS
        elapsed = GameTime.get_time() - self._start_time if self._start_time else 0.0
        if elapsed >= self._duration:
            return py_trees.common.Status.SUCCESS

        t = self._actor.get_transform()
        fwd = t.get_forward_vector()
        right = t.get_right_vector()
        lat = self._lateral_speed * self._lateral_sign
        vx = self._forward_speed * fwd.x + lat * right.x
        vy = self._forward_speed * fwd.y + lat * right.y
        self._actor.set_target_velocity(carla.Vector3D(vx, vy, 0.0))
        self._actor.apply_control(carla.VehicleControl(
            throttle=0.25, brake=0.0,
            steer=0.28 * self._lateral_sign))
        return py_trees.common.Status.RUNNING


class _EgoMinSpeedForcer(py_trees.behaviour.Behaviour):
    """Prevent the ego autopilot from braking below a minimum speed."""

    def __init__(self, ego, min_speed_kmh=68.0, throttle=1.0,
                 name="EgoMinSpeedForcer"):
        super().__init__(name)
        self._ego = ego
        self._min_mps = float(min_speed_kmh) / 3.6
        self._throttle = float(throttle)

    def update(self):
        if self._ego is None or not self._ego.is_alive:
            return py_trees.common.Status.RUNNING
        v = self._ego.get_velocity()
        speed = math.sqrt(v.x ** 2 + v.y ** 2 + v.z ** 2)
        if speed < self._min_mps:
            ctrl = self._ego.get_control()
            ctrl.brake = 0.0
            ctrl.throttle = self._throttle
            self._ego.apply_control(ctrl)
        return py_trees.common.Status.RUNNING


class _MirrorEgoFollower(py_trees.behaviour.Behaviour):
    """Drive a follower vehicle at the ego's speed, maintaining safe distance.

    The follower never exceeds the ego's current speed, so it cannot
    rear-end the ego. If the gap shrinks below min_gap, the follower
    brakes. This keeps the follower visible in the camera without
    causing unwanted collisions.
    """

    def __init__(self, follower, ego, max_speed_kmh=55.0, min_gap_m=8.0,
                 name="MirrorEgoFollower"):
        super().__init__(name)
        self._follower = follower
        self._ego = ego
        self._max_speed = float(max_speed_kmh) / 3.6
        self._min_gap = float(min_gap_m)

    def update(self):
        if (self._follower is None or not self._follower.is_alive
                or self._ego is None or not self._ego.is_alive):
            return py_trees.common.Status.RUNNING

        # ego speed
        ev = self._ego.get_velocity()
        ego_speed = math.sqrt(ev.x ** 2 + ev.y ** 2 + ev.z ** 2)

        # gap
        el = self._ego.get_location()
        fl = self._follower.get_location()
        gap = math.sqrt((el.x - fl.x) ** 2 + (el.y - fl.y) ** 2)

        # target speed: match ego but never exceed max, brake if too close
        if gap < self._min_gap:
            target_speed = max(0.0, ego_speed - 2.0)
        else:
            target_speed = min(ego_speed, self._max_speed)

        # apply as velocity along follower's forward vector
        ft = self._follower.get_transform()
        fwd = ft.get_forward_vector()
        self._follower.set_target_velocity(
            carla.Vector3D(fwd.x * target_speed, fwd.y * target_speed, 0.0))

        if gap < self._min_gap:
            self._follower.apply_control(
                carla.VehicleControl(throttle=0.0, brake=0.3))
        else:
            self._follower.apply_control(
                carla.VehicleControl(throttle=0.4, brake=0.0))

        return py_trees.common.Status.RUNNING


# ── main scenario ────────────────────────────────────────────────────────────

class TruckSuddenLaneChangeHeavyTraffic(BasicScenario):
    """
    Same truck-cuts-into-ego-lane collision as TruckSuddenLaneChange, but
    with additional vehicles boxing the ego in:
      - right-lane blocker  (prevents swerve right)
      - rear follower       (prevents hard braking)
      - slow lead in truck lane (motivation for truck's lane change)
    """
    timeout = 180

    @staticmethod
    def _get_param(op, name, default, cast=float):
        if not op or name not in op:
            return default
        raw = op[name]
        try:
            if isinstance(raw, dict):
                return cast(raw.get("value", default))
            return cast(raw)
        except (TypeError, ValueError):
            return default

    def __init__(self, world, ego_vehicles, config,
                 randomize=False, debug_mode=False, criteria_enable=True,
                 timeout=180):
        self._world = world
        self._map = CarlaDataProvider.get_map()
        self._ego = ego_vehicles[0]

        op = config.other_parameters if hasattr(config, "other_parameters") else {}

        # ── truck params (same as base) ──
        self._activation_distance = self._get_param(op, "activation_distance_m", 120.0)
        self._truck_spawn_ahead = self._get_param(op, "truck_spawn_ahead_m", 12.0)
        self._truck_speed_kmh = self._get_param(op, "truck_speed_kmh", 45.0)
        self._lane_change_duration = self._get_param(op, "truck_lane_change_duration_s", 1.2)
        self._aftermath_duration = self._get_param(op, "aftermath_duration_s", 6.0)
        self._ego_speed_cap_kmh = self._get_param(op, "ego_speed_cap_kmh", 65.0)
        self._ego_cap_brake = self._get_param(op, "ego_cap_brake", 0.15)
        self._road_friction_scale = self._get_param(op, "road_friction_scale", 1.0)
        self._alongside_threshold_m = self._get_param(op, "alongside_threshold_m", 6.0)
        self._lateral_speed_ms = self._get_param(op, "lateral_speed_ms", 4.5)
        self._truck_lanechange_speed_kmh = self._get_param(op, "truck_lanechange_speed_kmh", 38.0)
        self._ego_min_speed_kmh = self._get_param(op, "ego_min_speed_kmh", 55.0)
        self._lateral_sign = self._get_param(op, "lateral_sign", 1.0)
        self._truck_model = str(self._get_param(
            op, "truck_model", "vehicle.carlamotors.carlacola", cast=str))

        # ── additional traffic params ──
        self._right_blocker_offset_m = self._get_param(op, "right_blocker_offset_m", -2.0)
        self._right_blocker_speed_kmh = self._get_param(op, "right_blocker_speed_kmh", 55.0)
        self._rear_follower_behind_m = self._get_param(op, "rear_follower_behind_m", 12.0)
        self._rear_follower_speed_kmh = self._get_param(op, "rear_follower_speed_kmh", 60.0)
        self._slow_lead_ahead_m = self._get_param(op, "slow_lead_ahead_m", 35.0)
        self._slow_lead_speed_kmh = self._get_param(op, "slow_lead_speed_kmh", 30.0)

        self._trigger_wp = self._map.get_waypoint(config.trigger_points[0].location)
        self._truck = None
        self._right_blocker = None
        self._rear_follower = None
        self._slow_lead = None
        self._truck_plan = []
        self._truck_spawn_wp = None
        self._runtime_lateral_sign = self._lateral_sign

        # plans for additional actors
        self._right_blocker_plan = []
        self._rear_follower_plan = []
        self._slow_lead_plan = []
        self._right_blocker_wp = None
        self._rear_follower_wp = None
        self._slow_lead_wp = None

        super().__init__(
            name="TruckSuddenLaneChangeHeavyTraffic",
            ego_vehicles=ego_vehicles, config=config, world=world,
            debug_mode=debug_mode, terminate_on_failure=True,
            criteria_enable=criteria_enable)

    # ── environment ──────────────────────────────────────────────────────────

    def _initialize_environment(self, world):
        super()._initialize_environment(world)
        friction = max(0.1, float(self._road_friction_scale))
        if abs(friction - 1.0) < 1e-6:
            return
        bp = world.get_blueprint_library().find("static.trigger.friction")
        bp.set_attribute("friction", str(friction))
        bp.set_attribute("extent_x", "1000000.0")
        bp.set_attribute("extent_y", "1000000.0")
        bp.set_attribute("extent_z", "1000000.0")
        try:
            world.spawn_actor(bp, carla.Transform(
                carla.Location(-10000.0, -10000.0, 0.0)))
        except RuntimeError:
            pass

    # ── helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _walk_waypoint(waypoint, distance, forward=True):
        remaining = abs(float(distance))
        cursor = waypoint
        while remaining > 0.2 and cursor is not None:
            step = min(8.0, remaining)
            candidates = cursor.next(step) if forward else cursor.previous(step)
            if not candidates:
                break
            cursor = candidates[0]
            remaining -= step
        return cursor

    def _spawn_vehicle(self, transform, rolename, models=None):
        if models is None:
            models = [
                "vehicle.tesla.model3",
                "vehicle.nissan.patrol_2021",
                "vehicle.mercedes.coupe_2020",
                "vehicle.audi.a2",
            ]
        for model in dict.fromkeys(models):
            actor = CarlaDataProvider.request_new_actor(
                model, transform, rolename=rolename)
            if actor is not None:
                return actor
        return None

    def _spawn_truck(self, transform, rolename):
        models = [self._truck_model,
                  "vehicle.carlamotors.carlacola",
                  "vehicle.carlamotors.european_hgv",
                  "vehicle.tesla.cybertruck",
                  "vehicle.carla.firetruck"]
        for model in dict.fromkeys(models):
            actor = CarlaDataProvider.request_new_actor(
                model, transform, rolename=rolename)
            if actor is not None:
                return actor
        return None

    def _build_plan(self, start_wp, distance=800.0, step=2.0):
        waypoints, cursor, travelled = [], start_wp, 0.0
        while cursor is not None and travelled < distance:
            candidates = cursor.next(step)
            if not candidates:
                break
            cursor = candidates[0]
            waypoints.append(cursor)
            travelled += step
        return waypoints

    def _make_spawn_transform(self, wp, z_offset=0.5):
        return carla.Transform(
            carla.Location(
                wp.transform.location.x,
                wp.transform.location.y,
                wp.transform.location.z + z_offset),
            wp.transform.rotation)

    # ── actor spawning ───────────────────────────────────────────────────────

    def _initialize_actors(self, config):
        ego_wp = self._map.get_waypoint(
            self._ego.get_location(), project_to_road=True,
            lane_type=carla.LaneType.Driving)

        # ── truck (same as base scenario) ────────────────────────────────────
        spawn_lane = ego_wp.get_left_lane()
        if spawn_lane is None or spawn_lane.lane_type != carla.LaneType.Driving:
            spawn_lane = ego_wp.get_right_lane()
        if spawn_lane is None or spawn_lane.lane_type != carla.LaneType.Driving:
            raise RuntimeError("[TruckLaneChangeHeavy] No adjacent driving lane")

        if self._truck_spawn_ahead >= 0:
            self._truck_spawn_wp = self._walk_waypoint(
                spawn_lane, self._truck_spawn_ahead, forward=True) or spawn_lane
        else:
            self._truck_spawn_wp = self._walk_waypoint(
                spawn_lane, abs(self._truck_spawn_ahead), forward=False) or spawn_lane

        self._truck_plan = self._build_plan(self._truck_spawn_wp)
        self._truck = self._spawn_truck(
            self._make_spawn_transform(self._truck_spawn_wp), "lane_change_truck")
        if self._truck is None:
            raise RuntimeError("[TruckLaneChangeHeavy] Truck spawn failed")
        self._truck.set_simulate_physics(True)
        self._truck.set_target_velocity(carla.Vector3D(0, 0, 0))
        self.other_actors.append(self._truck)

        # compute lateral sign (ego relative to truck)
        truck_right = self._truck_spawn_wp.transform.get_right_vector()
        ego_loc = ego_wp.transform.location
        truck_loc = self._truck_spawn_wp.transform.location
        ego_dx = ego_loc.x - truck_loc.x
        ego_dy = ego_loc.y - truck_loc.y
        self._runtime_lateral_sign = (
            1.0 if (ego_dx * truck_right.x + ego_dy * truck_right.y) >= 0.0
            else -1.0)

        # ── right-lane blocker ───────────────────────────────────────────────
        right_lane = ego_wp.get_right_lane()
        if right_lane is not None and right_lane.lane_type == carla.LaneType.Driving:
            offset = self._right_blocker_offset_m
            if offset >= 0:
                self._right_blocker_wp = self._walk_waypoint(
                    right_lane, offset, forward=True) or right_lane
            else:
                self._right_blocker_wp = self._walk_waypoint(
                    right_lane, abs(offset), forward=False) or right_lane
            self._right_blocker_plan = self._build_plan(self._right_blocker_wp)
            self._right_blocker = self._spawn_vehicle(
                self._make_spawn_transform(self._right_blocker_wp),
                "right_blocker",
                models=["vehicle.nissan.patrol_2021",
                        "vehicle.mercedes.coupe_2020",
                        "vehicle.audi.a2"])
            if self._right_blocker is not None:
                self._right_blocker.set_simulate_physics(True)
                self._right_blocker.set_target_velocity(carla.Vector3D(0, 0, 0))
                self.other_actors.append(self._right_blocker)
                print(f"  [TruckLaneChangeHeavy] Right blocker spawned "
                      f"road={self._right_blocker_wp.road_id} "
                      f"lane={self._right_blocker_wp.lane_id}", flush=True)
            else:
                print("  [TruckLaneChangeHeavy] WARNING: right blocker spawn failed",
                      flush=True)
        else:
            print("  [TruckLaneChangeHeavy] No right driving lane, skipping blocker",
                  flush=True)

        # ── rear follower ────────────────────────────────────────────────────
        self._rear_follower_wp = self._walk_waypoint(
            ego_wp, self._rear_follower_behind_m, forward=False)
        if self._rear_follower_wp is not None:
            self._rear_follower_plan = self._build_plan(self._rear_follower_wp)
            self._rear_follower = self._spawn_vehicle(
                self._make_spawn_transform(self._rear_follower_wp),
                "rear_follower",
                models=["vehicle.mercedes.coupe_2020",
                        "vehicle.tesla.model3",
                        "vehicle.audi.a2"])
            if self._rear_follower is not None:
                self._rear_follower.set_simulate_physics(True)
                self._rear_follower.set_target_velocity(carla.Vector3D(0, 0, 0))
                self.other_actors.append(self._rear_follower)
                print(f"  [TruckLaneChangeHeavy] Rear follower spawned "
                      f"road={self._rear_follower_wp.road_id} "
                      f"lane={self._rear_follower_wp.lane_id}", flush=True)
            else:
                print("  [TruckLaneChangeHeavy] WARNING: rear follower spawn failed",
                      flush=True)

        # ── slow lead in truck's lane ────────────────────────────────────────
        self._slow_lead_wp = self._walk_waypoint(
            self._truck_spawn_wp, self._slow_lead_ahead_m, forward=True)
        if self._slow_lead_wp is not None:
            self._slow_lead_plan = self._build_plan(self._slow_lead_wp)
            self._slow_lead = self._spawn_vehicle(
                self._make_spawn_transform(self._slow_lead_wp),
                "slow_lead",
                models=["vehicle.nissan.patrol_2021",
                        "vehicle.mercedes.coupe_2020",
                        "vehicle.audi.a2"])
            if self._slow_lead is not None:
                self._slow_lead.set_simulate_physics(True)
                self._slow_lead.set_target_velocity(carla.Vector3D(0, 0, 0))
                self.other_actors.append(self._slow_lead)
                print(f"  [TruckLaneChangeHeavy] Slow lead spawned "
                      f"road={self._slow_lead_wp.road_id} "
                      f"lane={self._slow_lead_wp.lane_id}", flush=True)
            else:
                print("  [TruckLaneChangeHeavy] WARNING: slow lead spawn failed",
                      flush=True)

        print(
            f"\n[TruckLaneChangeHeavy] Spawn summary\n"
            f"  Ego road={ego_wp.road_id} lane={ego_wp.lane_id}\n"
            f"  Truck road={self._truck_spawn_wp.road_id} "
            f"lane={self._truck_spawn_wp.lane_id} "
            f"ahead={self._truck_spawn_ahead:.1f}m "
            f"speed={self._truck_speed_kmh:.1f} km/h\n"
            f"  lateral_speed={self._lateral_speed_ms:.1f} m/s "
            f"duration={self._lane_change_duration:.2f}s "
            f"alongside_threshold={self._alongside_threshold_m:.1f}m\n"
            f"  lanechange_speed={self._truck_lanechange_speed_kmh:.1f} km/h"
            f"  ego_min_speed={self._ego_min_speed_kmh:.1f} km/h"
            f"  lateral_sign={self._runtime_lateral_sign:+.1f}\n"
            f"  Right blocker: {'YES' if self._right_blocker else 'NO'}\n"
            f"  Rear follower: {'YES' if self._rear_follower else 'NO'}\n"
            f"  Slow lead:     {'YES' if self._slow_lead else 'NO'}\n",
            flush=True)

    # ── trigger ──────────────────────────────────────────────────────────────

    def _setup_scenario_trigger(self, config):
        return InTriggerDistanceToLocation(
            self._ego, self._trigger_wp.transform.location,
            self._activation_distance,
            name="ActivateTruckLaneChangeHeavy")

    # ── launch helpers ───────────────────────────────────────────────────────

    def _launch_truck(self):
        if self._truck is None or not self._truck.is_alive:
            return
        fwd = self._truck_spawn_wp.transform.get_forward_vector()
        speed = self._truck_speed_kmh / 3.6
        self._truck.set_target_velocity(
            carla.Vector3D(fwd.x * speed, fwd.y * speed, 0.0))

    def _launch_ambient(self):
        """Kick all ambient actors forward at their target speeds."""
        for actor, wp, speed_kmh in [
            (self._right_blocker, self._right_blocker_wp,
             self._right_blocker_speed_kmh),
            (self._rear_follower, self._rear_follower_wp,
             self._rear_follower_speed_kmh),
            (self._slow_lead, self._slow_lead_wp,
             self._slow_lead_speed_kmh),
        ]:
            if actor is None or not actor.is_alive or wp is None:
                continue
            fwd = wp.transform.get_forward_vector()
            speed = speed_kmh / 3.6
            actor.set_target_velocity(
                carla.Vector3D(fwd.x * speed, fwd.y * speed, 0.0))

    # ── behavior tree ────────────────────────────────────────────────────────

    def _create_behavior(self):
        from agents.navigation.local_planner import RoadOption
        P = py_trees.common.ParallelPolicy

        truck_plan = [(wp, RoadOption.LANEFOLLOW) for wp in self._truck_plan]

        root = py_trees.composites.Sequence("TruckLaneChangeHeavy_Root")

        # Phase 0 — hold until ego moves (all actors stationary)
        phase0 = py_trees.composites.Parallel(
            "Phase0_Sync", policy=P.SUCCESS_ON_ONE)
        phase0.add_child(TimeOut(8.0, name="Phase0_Timeout"))
        phase0.add_child(HoldUntilEgoMoves(
            self._truck, self._ego, name="HoldTruck"))
        root.add_child(phase0)

        # Launch all actors (truck + ambient)
        root.add_child(_OneShot(self._launch_truck, name="LaunchTruck"))
        root.add_child(_OneShot(self._launch_ambient, name="LaunchAmbient"))

        # ── build ambient followers (start AFTER phase 0 launch) ─────────────
        ambient_followers = py_trees.composites.Parallel(
            "AmbientFollowers", policy=P.SUCCESS_ON_ALL)
        for label, actor, plan, speed_kmh in [
            ("RightBlockerFollow", self._right_blocker,
             self._right_blocker_plan, self._right_blocker_speed_kmh),
            ("SlowLeadFollow", self._slow_lead,
             self._slow_lead_plan, self._slow_lead_speed_kmh),
        ]:
            if actor is not None and plan:
                wp_plan = [(wp, RoadOption.LANEFOLLOW) for wp in plan]
                ambient_followers.add_child(WaypointFollower(
                    actor, target_speed=speed_kmh / 3.6,
                    plan=wp_plan, name=label))
        # rear follower: mirror ego speed to avoid rear-ending
        if self._rear_follower is not None:
            ambient_followers.add_child(_MirrorEgoFollower(
                self._rear_follower, self._ego,
                max_speed_kmh=self._rear_follower_speed_kmh,
                min_gap_m=8.0, name="RearFollowerMirror"))

        # ── truck behavior sequence (phase 1–3) ─────────────────────────────
        truck_seq = py_trees.composites.Sequence("TruckPhases")

        # Phase 1 — truck cruises until alongside ego
        phase1 = py_trees.composites.Parallel(
            "Phase1_Cruise", policy=P.SUCCESS_ON_ONE)
        phase1.add_child(WaypointFollower(
            self._truck, target_speed=self._truck_speed_kmh / 3.6,
            plan=truck_plan, name="TruckLaneFollow"))
        phase1.add_child(_WaitUntilAlongside(
            self._ego, self._truck,
            max_forward_m=self._alongside_threshold_m,
            name="AlongsideTrigger"))
        phase1.add_child(TimeOut(30.0, name="Phase1_MaxTimeout"))
        truck_seq.add_child(phase1)

        # Phase 2 — forced lane change (same as base)
        lc_fwd = self._truck_lanechange_speed_kmh / 3.6
        phase2 = py_trees.composites.Parallel(
            "Phase2_LaneChange", policy=P.SUCCESS_ON_ONE)
        phase2.add_child(_ForcedLaneChange(
            self._truck, forward_speed_ms=lc_fwd,
            lateral_speed_ms=self._lateral_speed_ms,
            duration=self._lane_change_duration,
            lateral_sign=self._runtime_lateral_sign,
            name="ForceTruckIntoEgoLane"))
        phase2.add_child(TimeOut(
            self._lane_change_duration + 1.0, name="Phase2_Timeout"))
        truck_seq.add_child(phase2)

        # Phase 3 — aftermath
        truck_seq.add_child(_ForcedLaneChange(
            self._truck, forward_speed_ms=lc_fwd,
            lateral_speed_ms=0.0, duration=self._aftermath_duration,
            name="TruckBlockEgoLane"))

        # ── combine truck + ambient in parallel (both start after launch) ────
        active_phase = py_trees.composites.Parallel(
            "ActivePhase", policy=P.SUCCESS_ON_ONE)
        active_phase.add_child(truck_seq)
        if ambient_followers.children:
            active_phase.add_child(ambient_followers)
        root.add_child(active_phase)

        # Cleanup all actors
        cleanup = py_trees.composites.Sequence("Cleanup")
        cleanup.add_child(ActorDestroy(self._truck, name="DestroyTruck"))
        for label, actor in [("RightBlocker", self._right_blocker),
                             ("RearFollower", self._rear_follower),
                             ("SlowLead", self._slow_lead)]:
            if actor is not None:
                cleanup.add_child(ActorDestroy(actor, name=f"Destroy{label}"))
        root.add_child(cleanup)

        # ── protected actors for LaneCleaner ─────────────────────────────────
        protected = [self._ego, self._truck]
        for a in [self._right_blocker, self._rear_follower, self._slow_lead]:
            if a is not None:
                protected.append(a)

        # ── lane waypoints to clean ──────────────────────────────────────────
        lanes = [self._trigger_wp]
        left_lane = self._trigger_wp.get_left_lane()
        if left_lane is not None and left_lane.lane_type == carla.LaneType.Driving:
            lanes.append(left_lane)
        right_lane = self._trigger_wp.get_right_lane()
        if right_lane is not None and right_lane.lane_type == carla.LaneType.Driving:
            lanes.append(right_lane)

        # ── outer parallel ───────────────────────────────────────────────────
        outer = py_trees.composites.Parallel(
            "TruckLaneChangeHeavy_Outer", policy=P.SUCCESS_ON_ONE)
        outer.add_child(root)
        outer.add_child(LaneCleaner(
            protected_actors=protected,
            lane_waypoints=lanes,
            center_location=self._trigger_wp.transform.location,
            radius=500.0, interval=1.0, name="ScenarioLaneCleaner"))
        outer.add_child(PeriodicStatusLogger(
            self._ego, self._truck, None, interval=1.0, name="StatusLogger"))
        outer.add_child(EgoSpeedGovernor(
            self._ego, speed_cap_kmh=self._ego_speed_cap_kmh,
            brake_force=self._ego_cap_brake, name="EgoSpeedGovernor"))
        outer.add_child(_EgoMinSpeedForcer(
            self._ego, min_speed_kmh=self._ego_min_speed_kmh,
            name="EgoMinSpeedForcer"))
        outer.add_child(StopActorsOnEgoCollision(
            self._ego, actors_to_stop=[self._truck],
            name="StopOnCollision"))
        return outer

    # ── criteria ─────────────────────────────────────────────────────────────

    def _create_test_criteria(self):
        return [CollisionTest(self._ego)]

    def __del__(self):
        self.remove_all_actors()

#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Undivided-road head-on crossover scenario.
"""

from __future__ import annotations

import math
import time
from typing import Optional

import carla
import py_trees

from srunner.scenarios.basic_scenario import BasicScenario
from srunner.scenariomanager.carla_data_provider import CarlaDataProvider
from srunner.scenariomanager.scenarioatomics.atomic_criteria import Criterion
from srunner.scenariomanager.scenarioatomics.custom_atomics import LaneCleaner
from srunner.scenariomanager.timer import GameTime


def get_value_parameter(config, name, p_type, default):
    """Read a scalar custom XML parameter."""
    if name in config.other_parameters:
        return p_type(config.other_parameters[name]["value"])
    return default


def get_bool_parameter(config, name, default):
    """Read a boolean custom XML parameter."""
    if name not in config.other_parameters:
        return default
    value = str(config.other_parameters[name]["value"]).strip().lower()
    return value in ("1", "true", "yes", "y", "on")


def normalize_optional_model(raw_value):
    """Normalize optional model names from XML. Empty/none values disable spawning."""
    value = "" if raw_value is None else str(raw_value).strip()
    if value.lower() in ("", "none", "null", "false", "0"):
        return None
    return value


def clamp_steer(value: float) -> float:
    """Clamp steering to CARLA's valid range."""
    return max(-1.0, min(1.0, float(value)))


def planar_distance(location_a: carla.Location, location_b: carla.Location) -> float:
    """2D distance between two CARLA locations."""
    return math.hypot(location_a.x - location_b.x, location_a.y - location_b.y)


def actor_speed_mps(actor: Optional[carla.Actor]) -> float:
    """Return actor speed in m/s."""
    if actor is None or not actor.is_alive:
        return 0.0
    velocity = actor.get_velocity()
    return math.sqrt((velocity.x * velocity.x) + (velocity.y * velocity.y) + (velocity.z * velocity.z))


class CollisionFlagCriterion(Criterion):
    """Criterion that succeeds only if the ego collision sensor fired."""

    def __init__(self, actor: carla.Actor, scenario_ref, optional=False, name="CollisionFlagCriterion"):
        super().__init__(name, actor, optional=optional)
        self._scenario_ref = scenario_ref
        self.success_value = 1
        self.actual_value = 0
        self.units = "bool"

    def update(self):
        self.actual_value = 1 if self._scenario_ref._impact_detected else 0  # pylint: disable=protected-access
        if self.actual_value:
            self.test_status = "SUCCESS"
            return py_trees.common.Status.SUCCESS
        self.test_status = "RUNNING"
        return py_trees.common.Status.RUNNING

    def terminate(self, new_status):
        if self.test_status != "SUCCESS":
            self.test_status = "FAILURE"
        super().terminate(new_status)


class ApplyVehicleControlOnce(py_trees.behaviour.Behaviour):
    """Apply a one-shot control update."""

    def __init__(self, vehicle: carla.Vehicle, throttle: float = 0.0, brake: float = 0.0,
                 steer: float = 0.0, hand_brake: bool = False, name: str = "ApplyVehicleControlOnce"):
        super().__init__(name)
        self._vehicle = vehicle
        self._throttle = float(throttle)
        self._brake = float(brake)
        self._steer = float(steer)
        self._hand_brake = bool(hand_brake)

    def update(self):
        if self._vehicle is None or not self._vehicle.is_alive:
            return py_trees.common.Status.SUCCESS

        control = carla.VehicleControl(
            throttle=self._throttle,
            brake=self._brake,
            steer=self._steer,
            hand_brake=self._hand_brake,
        )
        self._vehicle.apply_control(control)
        return py_trees.common.Status.SUCCESS


class PacedIdle(py_trees.behaviour.Behaviour):
    """Idle for a duration while maintaining wall-clock pacing."""

    def __init__(self, scenario_ref, duration: float, name: str = "PacedIdle"):
        super().__init__(name)
        self._scenario = scenario_ref
        self._duration = float(duration)
        self._start_time = None

    def initialise(self):
        self._start_time = GameTime.get_time()

    def update(self):
        now = GameTime.get_time()
        elapsed = 0.0 if self._start_time is None else max(0.0, now - self._start_time)
        self._scenario._pace_to_wall_clock(now)  # pylint: disable=protected-access
        if elapsed >= self._duration:
            return py_trees.common.Status.SUCCESS
        return py_trees.common.Status.RUNNING


class RunUndividedCrossoverManeuver(py_trees.behaviour.Behaviour):
    """Drive the ego straight while the adversary crosses the center line at the last second."""

    def __init__(self, scenario_ref, name: str = "RunUndividedCrossoverManeuver"):
        super().__init__(name)
        self._scenario = scenario_ref
        self._start_time = None
        self._merge_started_at = None

    def initialise(self):
        self._start_time = GameTime.get_time()
        self._scenario._wall_start_time = time.monotonic()  # pylint: disable=protected-access
        self._merge_started_at = None

    def update(self):
        ego = self._scenario.ego_vehicles[0]
        adversary = self._scenario._adversary  # pylint: disable=protected-access
        if ego is None or adversary is None:
            return py_trees.common.Status.FAILURE
        if not ego.is_alive or not adversary.is_alive:
            return py_trees.common.Status.SUCCESS
        if self._scenario._impact_detected:  # pylint: disable=protected-access
            return py_trees.common.Status.SUCCESS

        now = GameTime.get_time()
        elapsed = 0.0 if self._start_time is None else max(0.0, now - self._start_time)
        self._scenario._pace_to_wall_clock(elapsed)  # pylint: disable=protected-access
        # self._scenario._update_spectator()  # pylint: disable=protected-access

        if self._merge_started_at is None and self._scenario._should_start_crossover():  # pylint: disable=protected-access
            self._merge_started_at = elapsed
            self._scenario._lock_crossover_target()  # pylint: disable=protected-access

        crossover_elapsed = None if self._merge_started_at is None else max(0.0, elapsed - self._merge_started_at)
        if not self._scenario._external_ego_control:  # pylint: disable=protected-access
            ego.apply_control(self._scenario._build_ego_control())  # pylint: disable=protected-access
        adversary.apply_control(self._scenario._build_adversary_control(crossover_elapsed))  # pylint: disable=protected-access
        self._scenario._drive_front_actors()  # pylint: disable=protected-access

        if elapsed >= self._scenario._max_run_time:  # pylint: disable=protected-access
            return py_trees.common.Status.FAILURE

        return py_trees.common.Status.RUNNING


class HighVelocityThreadingCollision(BasicScenario):
    """
    On an undivided two-lane road, the oncoming vehicle abruptly crosses the center line
    into the ego lane at very short time-to-collision.
    """

    timeout = 60

    def __init__(self, world, ego_vehicles, config, randomize=False, debug_mode=False,
                 criteria_enable=True, timeout=60):
        self.timeout = timeout
        self._world = world
        self._wall_start_time = None

        self._adversary: Optional[carla.Vehicle] = None
        self._ego_front_actor: Optional[carla.Vehicle] = None
        self._adversary_front_actor: Optional[carla.Vehicle] = None
        self._adversary_initial_heading_yaw: Optional[float] = None
        self._collision_sensor = None
        self._impact_detected = False
        self._ego_seed_wp = None
        self._meeting_ego_wp = None
        self._meeting_oncoming_wp = None

        self._meeting_point_distance = get_value_parameter(config, "meeting_point_distance", float, 45.0)
        self._adversary_spawn_distance = get_value_parameter(config, "adversary_spawn_distance", float, 70.0)
        self._trigger_distance = get_value_parameter(config, "trigger_distance", float, 35.0)
        self._trigger_ttc = get_value_parameter(config, "trigger_ttc", float, 1.4)
        self._ego_target_speed_mps = get_value_parameter(config, "ego_speed", float, 72.0) / 3.6
        self._adversary_target_speed_mps = get_value_parameter(config, "adversary_speed", float, 92.0) / 3.6
        self._ego_front_actor_model = normalize_optional_model(
            get_value_parameter(config, "ego_front_actor_model", str, "vehicle.audi.a2")
        )
        self._adversary_front_actor_model = normalize_optional_model(
            get_value_parameter(config, "adversary_front_actor_model", str, "vehicle.audi.a2")
        )
        self._ego_front_actor_distance = get_value_parameter(config, "ego_front_actor_distance", float, 28.0)
        self._adversary_front_actor_distance = get_value_parameter(
            config, "adversary_front_actor_distance", float, 28.0
        )
        self._ego_front_actor_target_speed_mps = get_value_parameter(
            config, "ego_front_actor_speed", float, 68.0
        ) / 3.6
        self._adversary_front_actor_target_speed_mps = get_value_parameter(
            config, "adversary_front_actor_speed", float, 80.0
        ) / 3.6
        self._front_actor_max_throttle = get_value_parameter(config, "front_actor_max_throttle", float, 0.55)
        self._front_actor_heading_steer_gain = get_value_parameter(
            config, "front_actor_heading_steer_gain", float, 0.45
        )
        self._front_actor_max_steer = get_value_parameter(config, "front_actor_max_steer", float, 0.35)
        self._lane_follow_lookahead = get_value_parameter(config, "lane_follow_lookahead", float, 10.0)
        self._crossover_lookahead = get_value_parameter(config, "crossover_lookahead", float, 8.0)
        self._crossover_duration = get_value_parameter(config, "crossover_duration", float, 0.55)
        self._lane_follow_steer_gain = get_value_parameter(config, "lane_follow_steer_gain", float, 1.1)
        self._crossover_steer_gain = get_value_parameter(config, "crossover_steer_gain", float, 1.8)
        self._crossover_settle_fraction = get_value_parameter(config, "crossover_settle_fraction", float, 0.3)
        self._crossover_lane_offset = get_value_parameter(config, "crossover_lane_offset", float, 0.4)
        self._dynamic_crossover_target = get_bool_parameter(config, "dynamic_crossover_target", False)
        self._target_ego_front_actor_on_crossover = get_bool_parameter(
            config, "target_ego_front_actor_on_crossover", False
        )
        self._base_throttle = get_value_parameter(config, "base_throttle", float, 0.52)
        self._speed_error_gain = get_value_parameter(config, "speed_error_gain", float, 0.04)
        self._max_steer = get_value_parameter(config, "max_steer", float, 0.9)
        self._max_run_time = get_value_parameter(config, "max_run_time", float, 12.0)
        self._cleanup_delay = get_value_parameter(config, "cleanup_delay", float, 1.0)
        self._external_ego_control = get_bool_parameter(config, "external_ego_control", True)
        self._locked_crossover_target: Optional[carla.Location] = None
        self._spectator_distance = get_value_parameter(config, "spectator_distance", float, 8.0)
        self._spectator_height = get_value_parameter(config, "spectator_height", float, 3.5)
        self._spectator_pitch = get_value_parameter(config, "spectator_pitch", float, -12.0)

        super().__init__(
            name="HighVelocityThreadingCollision",
            ego_vehicles=ego_vehicles,
            config=config,
            world=world,
            debug_mode=debug_mode,
            terminate_on_failure=False,
            criteria_enable=criteria_enable,
        )

    def _configure_vehicle_physics(self, vehicle):
        """Keep vehicle physics in a stable default state."""
        if vehicle is None or not vehicle.is_alive:
            return
        try:
            vehicle.set_simulate_physics(True)
        except RuntimeError:
            return
        try:
            vehicle.set_enable_gravity(True)
        except RuntimeError:
            pass
        try:
            physics = vehicle.get_physics_control()
        except RuntimeError:
            return
        changed = False
        if hasattr(physics, "use_sweep_wheel_collision") and not physics.use_sweep_wheel_collision:
            physics.use_sweep_wheel_collision = True
            changed = True
        if changed:
            try:
                vehicle.apply_physics_control(physics)
            except RuntimeError:
                pass

    def _initialize_environment(self, world):
        """Use scenario runner defaults for world settings."""
        super()._initialize_environment(world)


    @staticmethod
    def _yaw_delta_deg(yaw_a, yaw_b):
        delta = (yaw_a - yaw_b + 180.0) % 360.0 - 180.0
        return abs(delta)

    def _walk_waypoint(self, waypoint, distance, forward=True):
        if waypoint is None:
            return None

        remaining = max(0.1, float(distance))
        cursor = waypoint
        step_fn = cursor.next if forward else cursor.previous
        while remaining > 0.2:
            step = min(8.0, remaining)
            next_wps = step_fn(step)
            if not next_wps:
                break
            cursor = next_wps[0]
            remaining -= step
            step_fn = cursor.next if forward else cursor.previous
        return cursor

    def _find_oncoming_lane(self, base_wp):
        if base_wp is None:
            return None

        best_wp = None
        best_delta = -1.0
        for getter in ("get_left_lane", "get_right_lane"):
            walker = base_wp
            for _ in range(4):
                walker = getattr(walker, getter)()
                if walker is None:
                    break
                if walker.lane_type != carla.LaneType.Driving:
                    continue
                yaw_delta = self._yaw_delta_deg(walker.transform.rotation.yaw, base_wp.transform.rotation.yaw)
                if yaw_delta > 120.0 and yaw_delta > best_delta:
                    best_wp = walker
                    best_delta = yaw_delta
        return best_wp

    @staticmethod
    def _spawn_actor_with_fallback(model, transform, rolename, color=None):
        """Spawn an actor with a few safe retries around the requested transform."""
        attempts = []
        base_transform = carla.Transform(
            carla.Location(transform.location.x, transform.location.y, transform.location.z),
            transform.rotation,
        )
        attempts.append((base_transform, color))

        elevated_transform = carla.Transform(
            carla.Location(transform.location.x, transform.location.y, transform.location.z + 0.6),
            transform.rotation,
        )
        attempts.append((elevated_transform, color))

        if color is not None:
            attempts.append((base_transform, None))
            attempts.append((elevated_transform, None))

        for spawn_transform, spawn_color in attempts:
            actor = CarlaDataProvider.request_new_actor(
                model,
                spawn_transform,
                rolename=rolename,
                autopilot=False,
                color=spawn_color,
            )
            if actor is not None:
                return actor
        return None

    def _initialize_actors(self, config):
        if not self.ego_vehicles:
            raise ValueError("HighVelocityThreadingCollision requires one ego vehicle")
        if self.ego_vehicles[0] is None:
            if not config.ego_vehicles:
                raise ValueError("HighVelocityThreadingCollision could not spawn the ego vehicle")
            ego_config = config.ego_vehicles[0]
            world_map = CarlaDataProvider.get_map()
            ego_seed_wp = world_map.get_waypoint(
                ego_config.transform.location,
                project_to_road=True,
                lane_type=carla.LaneType.Driving,
            )
            ego_spawn_transform = ego_config.transform if ego_seed_wp is None else ego_seed_wp.transform
            ego_spawn_transform.location.z += 0.5
            ego_actor = self._spawn_actor_with_fallback(
                ego_config.model,
                ego_spawn_transform,
                ego_config.rolename,
                ego_config.color,
            )
            if ego_actor is None:
                raise ValueError("HighVelocityThreadingCollision could not spawn the ego vehicle")
            self.ego_vehicles[0] = ego_actor
        if len(config.other_actors) < 1:
            raise ValueError("HighVelocityThreadingCollision requires one <other_actor> adversary")

        world_map = CarlaDataProvider.get_map()
        ego = self.ego_vehicles[0]
        self._ego_seed_wp = world_map.get_waypoint(
            ego.get_location(),
            project_to_road=True,
            lane_type=carla.LaneType.Driving,
        )
        if self._ego_seed_wp is None:
            raise ValueError("Unable to find a driving lane for the ego start")

        ego_transform = self._ego_seed_wp.transform
        ego_transform.location.z += 0.3
        ego.set_transform(ego_transform)

        self._meeting_ego_wp = self._walk_waypoint(self._ego_seed_wp, self._meeting_point_distance, forward=True)
        self._meeting_oncoming_wp = self._find_oncoming_lane(self._meeting_ego_wp)
        if self._meeting_oncoming_wp is None:
            self._meeting_oncoming_wp = self._find_oncoming_lane(self._ego_seed_wp)
        if self._meeting_oncoming_wp is None:
            raise ValueError("Unable to find an oncoming driving lane")

        adversary_spawn_wp = self._walk_waypoint(self._meeting_oncoming_wp, self._adversary_spawn_distance, forward=False)
        adversary_transform = adversary_spawn_wp.transform
        adversary_transform.location.z += 0.3
        self._adversary_initial_heading_yaw = float(adversary_transform.rotation.yaw)

        self._adversary = CarlaDataProvider.request_new_actor(
            config.other_actors[0].model,
            adversary_transform,
            rolename=config.other_actors[0].rolename,
            autopilot=False,
            color=config.other_actors[0].color,
        )
        if self._adversary is None:
            raise ValueError("Unable to spawn the adversary")
        self.other_actors.append(self._adversary)
        self._spawn_front_actors(adversary_spawn_wp)
        self._configure_vehicle_physics(ego)
        self._configure_vehicle_physics(self._adversary)
        self._configure_vehicle_physics(self._ego_front_actor)
        self._configure_vehicle_physics(self._adversary_front_actor)

        bp = self._world.get_blueprint_library().find("sensor.other.collision")
        self._collision_sensor = self._world.spawn_actor(bp, carla.Transform(), attach_to=ego)
        self.other_actors.append(self._collision_sensor)
        self._collision_sensor.listen(self._on_collision)

    def _on_collision(self, event):
        other = event.other_actor
        if other is None:
            return
        adv_id = self._adversary.id if self._adversary is not None else None
        if adv_id is not None and other.id == adv_id:
            if not self._impact_detected:
                self._impact_detected = True
                print(f"[HighVelocityThreading] *** ADVERSARY COLLISION: {other.type_id} (oncoming car) ***", flush=True)
            return
        print(f"[HighVelocityThreading] Ignoring non-adversary collision: {other.type_id} (id={other.id})", flush=True)

    def _spawn_front_actors(self, adversary_spawn_wp):
        if self._ego_front_actor_model and self._ego_seed_wp is not None:
            ego_front_candidates = self._ego_seed_wp.next(max(1.0, float(self._ego_front_actor_distance)))
            if ego_front_candidates:
                ego_front_tf = ego_front_candidates[0].transform
                ego_front_tf.location.z += 0.3
                self._ego_front_actor = self._spawn_actor_with_fallback(
                    self._ego_front_actor_model,
                    ego_front_tf,
                    "ego_front_actor",
                )
                if self._ego_front_actor is not None:
                    self.other_actors.append(self._ego_front_actor)

        if self._adversary_front_actor_model and adversary_spawn_wp is not None:
            adv_front_candidates = adversary_spawn_wp.next(max(1.0, float(self._adversary_front_actor_distance)))
            if adv_front_candidates:
                adv_front_tf = adv_front_candidates[0].transform
                adv_front_tf.location.z += 0.3
                if self._adversary is not None:
                    # Skip support actor if it would overlap/stack near the adversary.
                    if planar_distance(adv_front_tf.location, self._adversary.get_location()) < 8.0:
                        return
                self._adversary_front_actor = self._spawn_actor_with_fallback(
                    self._adversary_front_actor_model,
                    adv_front_tf,
                    "adversary_front_actor",
                )
                if self._adversary_front_actor is not None:
                    self.other_actors.append(self._adversary_front_actor)

    def _pace_to_wall_clock(self, sim_elapsed):
        if self._wall_start_time is None:
            self._wall_start_time = time.monotonic()
        expected_wall_elapsed = sim_elapsed
        current_wall_elapsed = time.monotonic() - self._wall_start_time
        sleep_time = expected_wall_elapsed - current_wall_elapsed
        if sleep_time > 0.0:
            time.sleep(min(sleep_time, 0.1))

    def _update_spectator(self):
        return
        # ego = self.ego_vehicles[0]
        # if ego is None or not ego.is_alive:
        #     return

        # transform = ego.get_transform()
        # forward = transform.rotation.get_forward_vector()
        # location = transform.location - carla.Location(
        #     x=forward.x * self._spectator_distance,
        #     y=forward.y * self._spectator_distance,
        #     z=0.0,
        # )
        # location.z += self._spectator_height
        # rotation = carla.Rotation(
        #     pitch=self._spectator_pitch,
        #     yaw=transform.rotation.yaw,
        #     roll=0.0,
        # )
        # self._world.get_spectator().set_transform(carla.Transform(location, rotation))

    def _target_throttle(self, actor, target_speed):
        speed_error = max(0.0, target_speed - actor_speed_mps(actor))
        return max(0.0, min(1.0, self._base_throttle + (speed_error * self._speed_error_gain)))

    def _steer_to_location(self, actor, target_location, steer_gain):
        if actor is None or not actor.is_alive:
            return 0.0

        transform = actor.get_transform()
        delta = target_location - transform.location
        desired_yaw = math.degrees(math.atan2(delta.y, delta.x))
        heading_delta = (desired_yaw - transform.rotation.yaw + 180.0) % 360.0 - 180.0
        steer = (heading_delta / 90.0) * steer_gain
        return clamp_steer(max(-self._max_steer, min(self._max_steer, steer)))

    def _lane_target_location(self, actor, lookahead):
        world_map = CarlaDataProvider.get_map()
        waypoint = world_map.get_waypoint(
            actor.get_location(),
            project_to_road=True,
            lane_type=carla.LaneType.Driving,
        )
        target_wp = self._walk_waypoint(waypoint, lookahead, forward=True)
        return target_wp.transform.location if target_wp is not None else actor.get_location()

    def _build_ego_control(self):
        ego = self.ego_vehicles[0]
        target_location = self._lane_target_location(ego, self._lane_follow_lookahead)
        return carla.VehicleControl(
            throttle=self._target_throttle(ego, self._ego_target_speed_mps),
            steer=self._steer_to_location(ego, target_location, self._lane_follow_steer_gain),
            brake=0.0,
        )

    def _build_crossover_target(self):
        if (
            self._target_ego_front_actor_on_crossover
            and self._ego_front_actor is not None
            and self._ego_front_actor.is_alive
        ):
            return self._ego_front_actor.get_location()

        if (not self._dynamic_crossover_target) and self._locked_crossover_target is not None:
            return self._locked_crossover_target

        ego = self.ego_vehicles[0]
        world_map = CarlaDataProvider.get_map()
        ego_wp = world_map.get_waypoint(
            ego.get_location(),
            project_to_road=True,
            lane_type=carla.LaneType.Driving,
        )
        target_wp = self._walk_waypoint(ego_wp, self._crossover_lookahead, forward=True)
        target_location = target_wp.transform.location if target_wp is not None else ego.get_location()
        ego_right = ego.get_transform().rotation.get_right_vector()
        return target_location + carla.Location(
            x=ego_right.x * self._crossover_lane_offset,
            y=ego_right.y * self._crossover_lane_offset,
            z=0.0,
        )

    def _lock_crossover_target(self):
        """Freeze crossover target at merge start for less ego-chasing behavior."""
        self._locked_crossover_target = self._build_crossover_target()

    def _build_adversary_control(self, crossover_elapsed):
        adversary = self._adversary
        if crossover_elapsed is None:
            target_location = self._lane_target_location(adversary, self._lane_follow_lookahead)
            steer_gain = self._lane_follow_steer_gain
        else:
            target_location = self._build_crossover_target()
            steer_gain = self._crossover_steer_gain
            if crossover_elapsed > self._crossover_duration:
                steer_gain *= self._crossover_settle_fraction

        return carla.VehicleControl(
            throttle=self._target_throttle(adversary, self._adversary_target_speed_mps),
            steer=self._steer_to_location(adversary, target_location, steer_gain),
            brake=0.0,
        )

    @staticmethod
    def _normalize_yaw(yaw):
        return ((float(yaw) + 180.0) % 360.0) - 180.0

    def _build_heading_hold_control(self, actor, target_speed, heading_yaw):
        if actor is None or not actor.is_alive:
            return None

        yaw_error = self._normalize_yaw(heading_yaw - actor.get_transform().rotation.yaw)
        steer = clamp_steer(max(
            -self._front_actor_max_steer,
            min(self._front_actor_max_steer, (yaw_error / 90.0) * self._front_actor_heading_steer_gain),
        ))
        speed_error = float(target_speed) - actor_speed_mps(actor)
        throttle = max(0.0, min(
            self._front_actor_max_throttle,
            0.35 + (0.08 * speed_error),
        ))
        brake = 0.0 if speed_error >= -0.8 else max(0.0, min(0.5, (-speed_error - 0.8) * 0.12))
        return carla.VehicleControl(
            throttle=throttle,
            steer=steer,
            brake=brake,
            hand_brake=False,
        )

    def _build_lane_follow_front_control(self, actor, target_speed):
        if actor is None or not actor.is_alive:
            return None

        target_location = self._lane_target_location(actor, self._lane_follow_lookahead)
        steer = self._steer_to_location(actor, target_location, self._lane_follow_steer_gain)
        steer = clamp_steer(max(-self._front_actor_max_steer, min(self._front_actor_max_steer, steer)))
        speed_error = float(target_speed) - actor_speed_mps(actor)
        throttle = max(0.0, min(
            self._front_actor_max_throttle,
            0.35 + (0.08 * speed_error),
        ))
        brake = 0.0 if speed_error >= -0.8 else max(0.0, min(0.5, (-speed_error - 0.8) * 0.12))
        return carla.VehicleControl(
            throttle=throttle,
            steer=steer,
            brake=brake,
            hand_brake=False,
        )

    def _drive_front_actors(self):
        if self._ego_front_actor is not None and self._ego_front_actor.is_alive:
            ego_front_control = self._build_lane_follow_front_control(
                self._ego_front_actor,
                self._ego_front_actor_target_speed_mps,
            )
            if ego_front_control is not None:
                self._ego_front_actor.apply_control(ego_front_control)

        if self._adversary_front_actor is not None and self._adversary_front_actor.is_alive:
            heading = self._adversary_initial_heading_yaw
            if heading is None and self._adversary is not None and self._adversary.is_alive:
                heading = self._adversary.get_transform().rotation.yaw
            if heading is None:
                heading = 0.0
            adv_front_control = self._build_heading_hold_control(
                self._adversary_front_actor,
                self._adversary_front_actor_target_speed_mps,
                heading,
            )
            if adv_front_control is not None:
                self._adversary_front_actor.apply_control(adv_front_control)

    def _compute_front_gap(self):
        ego = self.ego_vehicles[0]
        adversary = self._adversary
        distance = planar_distance(ego.get_location(), adversary.get_location())
        ego_extent = ego.bounding_box.extent.x if ego.bounding_box else 2.0
        adversary_extent = adversary.bounding_box.extent.x if adversary.bounding_box else 2.0
        return max(0.0, distance - ego_extent - adversary_extent)

    def _should_start_crossover(self):
        gap = self._compute_front_gap()
        if gap <= self._trigger_distance:
            return True

        closing_speed = actor_speed_mps(self.ego_vehicles[0]) + actor_speed_mps(self._adversary)
        if closing_speed <= 0.1:
            return False
        ttc = gap / closing_speed
        return ttc <= self._trigger_ttc

    def _create_behavior(self):
        sequence = py_trees.composites.Sequence(name="HighVelocityThreadingCollisionSequence")
        sequence.add_child(py_trees.behaviours.Success(name="StartImmediately"))
        sequence.add_child(RunUndividedCrossoverManeuver(self))
        sequence.add_child(PacedIdle(self, self._cleanup_delay, name="CleanupDelay"))
        sequence.add_child(ApplyVehicleControlOnce(
            self.ego_vehicles[0],
            throttle=0.0,
            brake=0.9,
            steer=0.0,
            hand_brake=False,
            name="BrakeEgo",
        ))
        sequence.add_child(ApplyVehicleControlOnce(
            self._adversary,
            throttle=0.0,
            brake=0.6,
            steer=0.0,
            hand_brake=False,
            name="BrakeAdversary",
        ))
        sequence.add_child(PacedIdle(self, 0.5, name="HoldCrash"))

        # Outer: run the maneuver in parallel with a lane cleaner so ambient
        # traffic (mercedes/etc) never gets between the ego and the adversary.
        lanes = []
        if self._ego_seed_wp is not None:
            lanes.append(self._ego_seed_wp)
        if self._meeting_oncoming_wp is not None:
            lanes.append(self._meeting_oncoming_wp)
        center_loc = self._ego_seed_wp.transform.location if self._ego_seed_wp else carla.Location()
        protected = [self.ego_vehicles[0], self._adversary]
        if self._ego_front_actor is not None:
            protected.append(self._ego_front_actor)
        if self._adversary_front_actor is not None:
            protected.append(self._adversary_front_actor)

        outer = py_trees.composites.Parallel(
            "HeadOn_Outer",
            policy=py_trees.common.ParallelPolicy.SUCCESS_ON_ONE,
        )
        outer.add_child(sequence)
        outer.add_child(LaneCleaner(
            protected_actors=protected,
            lane_waypoints=lanes,
            center_location=center_loc,
            radius=200.0, interval=0.5, name="HeadOnLaneCleaner",
        ))
        return outer

    def _setup_scenario_trigger(self, config):
        _ = config
        return None

    def _create_test_criteria(self):
        return [CollisionFlagCriterion(self.ego_vehicles[0], self)]

    def __del__(self):
        try:
            self.remove_all_actors()
        except Exception:
            pass

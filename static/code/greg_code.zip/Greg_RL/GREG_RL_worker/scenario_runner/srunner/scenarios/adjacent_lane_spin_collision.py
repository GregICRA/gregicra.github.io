"""Adjacent-lane loss-of-control spin collision for Town04 highways."""

import carla
import py_trees

from srunner.scenariomanager.carla_data_provider import CarlaDataProvider
from srunner.scenariomanager.scenarioatomics.atomic_behaviors import (
    ActorDestroy,
    WaypointFollower,
)
from srunner.scenariomanager.scenarioatomics.atomic_criteria import CollisionTest
from srunner.scenariomanager.scenarioatomics.atomic_trigger_conditions import (
    InTriggerDistanceToLocation,
)
from srunner.scenariomanager.scenarioatomics.custom_atomics import (
    EgoSpeedGovernor,
    HoldUntilEgoMoves,
    LaneCleaner,
    PeriodicStatusLogger,
    SpinOutControl,
    WaitUntilAheadOfEgo,
)
from srunner.scenariomanager.timer import TimeOut
from srunner.scenarios.basic_scenario import BasicScenario


class AdjacentLaneSpinCollision(BasicScenario):
    """A vehicle in the adjacent lane loses control and spins into ego's lane."""

    timeout = 180

    @staticmethod
    def _get_param(op, name, default, cast=float):
        if not op or name not in op:
            return default
        raw = op[name]
        try:
            if isinstance(raw, dict):
                return cast(raw.get("value", default))
            return cast(raw)
        except (TypeError, ValueError):
            return default

    def __init__(self, world, ego_vehicles, config,
                 randomize=False, debug_mode=False, criteria_enable=True,
                 timeout=180):
        self._world = world
        self._map = CarlaDataProvider.get_map()
        self._ego = ego_vehicles[0]

        op = config.other_parameters if hasattr(config, "other_parameters") else {}
        self._activation_distance = self._get_param(op, "activation_distance_m", 140.0)
        self._adv_spawn_behind = self._get_param(op, "adv_spawn_behind_ego", 55.0)
        self._approach_speed = self._get_param(op, "approach_speed_kmh", 104.0) / 3.6
        self._ahead_trigger_dist = self._get_param(op, "ahead_trigger_distance_m", 2.0)
        self._road_friction_scale = self._get_param(op, "road_friction_scale", 0.78)
        self._ego_speed_cap_kmh = self._get_param(op, "ego_speed_cap_kmh", 88.0)
        self._ego_cap_brake = self._get_param(op, "ego_cap_brake", 0.12)
        self._aftermath_duration = self._get_param(op, "aftermath_duration_s", 6.0)
        self._lead_distance = self._get_param(op, "ego_lead_vehicle_distance_m", 0.0)
        self._lead_speed_kmh = self._get_param(op, "ego_lead_vehicle_speed_kmh", 58.0)

        self._cut_in_steer = self._get_param(op, "cut_in_steer", 0.45)
        self._cut_in_throttle = self._get_param(op, "cut_in_throttle", 0.75)
        self._cut_in_duration = self._get_param(op, "cut_in_duration", 0.35)
        self._drift_steer = self._get_param(op, "drift_steer", 1.00)
        self._drift_steer_sign = self._get_param(op, "drift_steer_sign", -1.0)
        self._drift_throttle = self._get_param(op, "drift_throttle", 0.20)
        self._drift_brake = self._get_param(op, "drift_brake", 0.30)
        self._drift_duration = self._get_param(op, "drift_duration", 0.85)
        self._spin_throttle = self._get_param(op, "spin_throttle", 0.15)
        self._spin_duration = self._get_param(op, "spin_duration", 1.20)
        self._block_duration = self._get_param(op, "block_duration", 5.50)

        self._trigger_wp = self._map.get_waypoint(config.trigger_points[0].location)
        self._adversarial = None
        self._lead_vehicle = None
        self._left_lane_wps = []

        super().__init__(
            name="AdjacentLaneSpinCollision",
            ego_vehicles=ego_vehicles,
            config=config,
            world=world,
            debug_mode=debug_mode,
            terminate_on_failure=True,
            criteria_enable=criteria_enable,
        )

    def _initialize_environment(self, world):
        super()._initialize_environment(world)
        friction = max(0.1, float(self._road_friction_scale))
        bp = world.get_blueprint_library().find("static.trigger.friction")
        bp.set_attribute("friction", str(friction))
        bp.set_attribute("extent_x", "1000000.0")
        bp.set_attribute("extent_y", "1000000.0")
        bp.set_attribute("extent_z", "1000000.0")
        try:
            world.spawn_actor(bp, carla.Transform(carla.Location(-10000.0, -10000.0, 0.0)))
        except RuntimeError:
            pass

    @staticmethod
    def _walk_waypoint(waypoint, distance, forward=True):
        remaining = abs(float(distance))
        cursor = waypoint
        while remaining > 0.2 and cursor is not None:
            step = min(8.0, remaining)
            candidates = cursor.next(step) if forward else cursor.previous(step)
            if not candidates:
                break
            cursor = candidates[0]
            remaining -= step
        return cursor

    def _build_plan(self, start_wp, distance=800.0, step=2.0):
        waypoints = []
        cursor = start_wp
        travelled = 0.0
        while cursor is not None and travelled < distance:
            candidates = cursor.next(step)
            if not candidates:
                break
            cursor = candidates[0]
            waypoints.append(cursor)
            travelled += step
        return waypoints

    def _initialize_actors(self, config):
        ego_wp = self._map.get_waypoint(
            self._ego.get_location(), project_to_road=True,
            lane_type=carla.LaneType.Driving,
        )
        left_wp = ego_wp.get_left_lane()
        if left_wp is None or left_wp.lane_type != carla.LaneType.Driving:
            raise RuntimeError(
                f"[AdjacentSpin] No drivable adjacent lane from "
                f"road={ego_wp.road_id} lane={ego_wp.lane_id}"
            )

        adv_spawn_wp = self._walk_waypoint(left_wp, self._adv_spawn_behind, forward=False) or left_wp
        self._left_lane_wps = self._build_plan(adv_spawn_wp)
        adv_transform = carla.Transform(
            carla.Location(
                adv_spawn_wp.transform.location.x,
                adv_spawn_wp.transform.location.y,
                adv_spawn_wp.transform.location.z + 0.5,
            ),
            adv_spawn_wp.transform.rotation,
        )
        self._adversarial = CarlaDataProvider.request_new_actor(
            "vehicle.tesla.model3", adv_transform, rolename="unstable_adjacent_vehicle",
        )
        if self._adversarial is None:
            raise RuntimeError("[AdjacentSpin] Adversary spawn failed")
        self._adversarial.set_simulate_physics(True)
        self._adversarial.set_target_velocity(carla.Vector3D(0.0, 0.0, 0.0))
        self.other_actors.append(self._adversarial)

        if self._lead_distance > 0.0:
            lead_wp = self._walk_waypoint(ego_wp, self._lead_distance, forward=True) or ego_wp
            lead_transform = carla.Transform(
                carla.Location(
                    lead_wp.transform.location.x,
                    lead_wp.transform.location.y,
                    lead_wp.transform.location.z + 0.5,
                ),
                lead_wp.transform.rotation,
            )
            self._lead_vehicle = CarlaDataProvider.request_new_actor(
                "vehicle.tesla.cybertruck", lead_transform, rolename="ego_lane_lead",
            )
            if self._lead_vehicle is not None:
                self._lead_vehicle.set_simulate_physics(True)
                tm_port = CarlaDataProvider.get_traffic_manager_port()
                tm = CarlaDataProvider.get_client().get_trafficmanager(tm_port)
                self._lead_vehicle.set_autopilot(True, tm_port)
                tm.set_desired_speed(self._lead_vehicle, self._lead_speed_kmh)
                tm.auto_lane_change(self._lead_vehicle, False)
                tm.ignore_vehicles_percentage(self._lead_vehicle, 100)
                tm.ignore_walkers_percentage(self._lead_vehicle, 100)
                tm.ignore_lights_percentage(self._lead_vehicle, 100)
                tm.ignore_signs_percentage(self._lead_vehicle, 100)
                self.other_actors.append(self._lead_vehicle)

        print(
            f"\n[AdjacentSpin] Spawn\n"
            f"  Ego road={ego_wp.road_id} lane={ego_wp.lane_id}\n"
            f"  ADV road={adv_spawn_wp.road_id} lane={adv_spawn_wp.lane_id} "
            f"behind={self._adv_spawn_behind:.1f}m approach={self._approach_speed * 3.6:.1f} km/h\n"
            f"  trigger_ahead={self._ahead_trigger_dist:.1f}m friction={self._road_friction_scale:.2f}\n",
            flush=True,
        )

    def _setup_scenario_trigger(self, config):
        return InTriggerDistanceToLocation(
            self._ego,
            self._trigger_wp.transform.location,
            self._activation_distance,
            name="ActivateAdjacentLaneSpinCollision",
        )

    def _create_behavior(self):
        from agents.navigation.local_planner import RoadOption

        P = py_trees.common.ParallelPolicy
        root = py_trees.composites.Sequence("AdjacentSpin_Root")
        plan = [(wp, RoadOption.LANEFOLLOW) for wp in self._left_lane_wps]

        phase0 = py_trees.composites.Parallel("Phase0_Sync", policy=P.SUCCESS_ON_ONE)
        phase0.add_child(TimeOut(8.0, name="Phase0_Timeout"))
        phase0.add_child(HoldUntilEgoMoves(self._adversarial, self._ego, name="HoldADV"))
        root.add_child(phase0)

        phase1 = py_trees.composites.Parallel("Phase1_Approach", policy=P.SUCCESS_ON_ONE)
        phase1.add_child(TimeOut(25.0, name="Phase1_Timeout"))
        phase1.add_child(WaitUntilAheadOfEgo(
            self._adversarial, self._ego,
            ahead_distance=self._ahead_trigger_dist,
            name="WaitADVAhead",
        ))
        phase1.add_child(WaypointFollower(
            self._adversarial,
            target_speed=self._approach_speed,
            plan=plan,
            name="ADV_Approach",
        ))
        root.add_child(phase1)

        phase2_timeout = (
            self._cut_in_duration + self._drift_duration +
            self._spin_duration + self._block_duration + 2.0
        )
        phase2 = py_trees.composites.Parallel("Phase2_SpinIntoEgoLane", policy=P.SUCCESS_ON_ONE)
        phase2.add_child(SpinOutControl(
            self._adversarial,
            steer_direction=1.0,
            cut_in_steer=self._cut_in_steer,
            cut_in_throttle=self._cut_in_throttle,
            cut_in_duration=self._cut_in_duration,
            drift_steer=self._drift_steer,
            drift_steer_sign=self._drift_steer_sign,
            drift_throttle=self._drift_throttle,
            drift_brake=self._drift_brake,
            drift_duration=self._drift_duration,
            spin_throttle=self._spin_throttle,
            spin_duration=self._spin_duration,
            block_duration=self._block_duration,
            name="ADV_SpinOut",
        ))
        phase2.add_child(TimeOut(phase2_timeout, name="Phase2_Timeout"))
        root.add_child(phase2)

        root.add_child(TimeOut(self._aftermath_duration, name="Phase3_Aftermath"))

        cleanup = py_trees.composites.Sequence("Cleanup")
        cleanup.add_child(ActorDestroy(self._adversarial, name="DestroyADV"))
        if self._lead_vehicle is not None:
            cleanup.add_child(ActorDestroy(self._lead_vehicle, name="DestroyLead"))
        root.add_child(cleanup)

        lanes = [self._trigger_wp]
        left_lane = self._trigger_wp.get_left_lane()
        if left_lane is not None and left_lane.lane_type == carla.LaneType.Driving:
            lanes.append(left_lane)
        protected = [self._ego, self._adversarial, self._lead_vehicle]

        outer = py_trees.composites.Parallel("AdjacentSpin_Outer", policy=P.SUCCESS_ON_ONE)
        outer.add_child(root)
        outer.add_child(LaneCleaner(
            protected_actors=protected,
            lane_waypoints=lanes,
            center_location=self._trigger_wp.transform.location,
            radius=500.0,
            interval=1.0,
            name="ScenarioLaneCleaner",
        ))
        outer.add_child(PeriodicStatusLogger(
            self._ego, self._adversarial, self._lead_vehicle,
            interval=1.0, name="StatusLogger",
        ))
        outer.add_child(EgoSpeedGovernor(
            self._ego,
            speed_cap_kmh=self._ego_speed_cap_kmh,
            brake_force=self._ego_cap_brake,
            name="EgoSpeedGovernor",
        ))
        return outer

    def _create_test_criteria(self):
        return [CollisionTest(self._ego)]

    def __del__(self):
        self.remove_all_actors()

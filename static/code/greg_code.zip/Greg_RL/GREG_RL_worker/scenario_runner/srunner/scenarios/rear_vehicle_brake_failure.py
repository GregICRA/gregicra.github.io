"""Rear vehicle fails to stop during sudden highway traffic slowdown."""

import math

import carla
import py_trees

from srunner.scenariomanager.carla_data_provider import CarlaDataProvider
from srunner.scenariomanager.scenarioatomics.atomic_behaviors import ActorDestroy
from srunner.scenariomanager.scenarioatomics.atomic_criteria import CollisionTest
from srunner.scenariomanager.scenarioatomics.atomic_trigger_conditions import (
    InTriggerDistanceToLocation,
)
from srunner.scenariomanager.scenarioatomics.custom_atomics import EgoSpeedGovernor
from srunner.scenariomanager.timer import GameTime
from srunner.scenarios.basic_scenario import BasicScenario


def _clamp(value, low, high):
    return max(low, min(high, value))


def _speed_mps(actor):
    if actor is None or not actor.is_alive:
        return 0.0
    velocity = actor.get_velocity()
    return math.sqrt(velocity.x ** 2 + velocity.y ** 2 + velocity.z ** 2)


class _RunRearBrakeFailure(py_trees.behaviour.Behaviour):
    """Directly control lead and rear vehicles until rear impact or timeout."""

    def __init__(self, scenario, name="RunRearBrakeFailure"):
        super().__init__(name)
        self._scenario = scenario
        self._start_time = None
        self._last_log = -999.0

    def initialise(self):
        self._start_time = GameTime.get_time()

    def update(self):
        scenario = self._scenario
        if scenario._impact_detected:
            print(f"[RearBrakeFailure] *** IMPACT DETECTED ***", flush=True)
            return py_trees.common.Status.SUCCESS

        elapsed = GameTime.get_time() - self._start_time if self._start_time is not None else 0.0
        scenario._apply_support_controls(elapsed)

        # Periodic status log every second for timing/reaction-window checks.
        if elapsed - self._last_log >= 1.0:
            self._last_log = elapsed
            ego_spd = _speed_mps(scenario._ego) * 3.6
            rear_spd = _speed_mps(scenario._rear_vehicle) * 3.6 if scenario._rear_vehicle else 0
            lead_spd = _speed_mps(scenario._lead_vehicle) * 3.6 if scenario._lead_vehicle else 0
            gap = 0.0
            if scenario._rear_vehicle and scenario._ego:
                rl = scenario._rear_vehicle.get_location()
                el = scenario._ego.get_location()
                gap = math.sqrt((rl.x - el.x)**2 + (rl.y - el.y)**2 + (rl.z - el.z)**2)
            print(f"[RearBrakeFailure] t={elapsed:.1f}s  ego={ego_spd:.0f}km/h  rear={rear_spd:.0f}km/h  lead={lead_spd:.0f}km/h  gap={gap:.1f}m  impact={scenario._impact_detected}", flush=True)

        if elapsed >= scenario._max_run_time:
            return py_trees.common.Status.FAILURE
        return py_trees.common.Status.RUNNING


class _PostImpactHold(py_trees.behaviour.Behaviour):
    """Hold the crash scene for video after the ego collision sensor fires."""

    def __init__(self, scenario, duration, name="PostImpactHold"):
        super().__init__(name)
        self._scenario = scenario
        self._duration = float(duration)
        self._start_time = None

    def initialise(self):
        self._start_time = GameTime.get_time()

    def update(self):
        elapsed = GameTime.get_time() - self._start_time if self._start_time is not None else 0.0
        self._scenario._freeze_controlled_traffic()
        if elapsed >= self._duration:
            return py_trees.common.Status.SUCCESS
        return py_trees.common.Status.RUNNING


class RearVehicleBrakeFailure(BasicScenario):
    """Traffic ahead slows; a fast rear vehicle keeps closing and hits ego."""

    timeout = 180

    @staticmethod
    def _get_param(op, name, default, cast=float):
        if not op or name not in op:
            return default
        raw = op[name]
        try:
            if isinstance(raw, dict):
                return cast(raw.get("value", default))
            return cast(raw)
        except (TypeError, ValueError):
            return default

    def __init__(self, world, ego_vehicles, config,
                 randomize=False, debug_mode=False, criteria_enable=True,
                 timeout=180):
        self._world = world
        self._map = CarlaDataProvider.get_map()
        self._ego = ego_vehicles[0]

        op = config.other_parameters if hasattr(config, "other_parameters") else {}
        self._activation_distance = self._get_param(op, "activation_distance_m", 150.0)
        self._lead_distance = self._get_param(op, "lead_vehicle_ahead_distance_m", 48.0)
        self._second_lead_distance = self._get_param(op, "second_lead_vehicle_ahead_distance_m", 78.0)
        self._rear_distance = self._get_param(op, "rear_vehicle_behind_distance_m", 62.0)
        self._lead_speed = self._get_param(op, "lead_vehicle_speed_kmh", 72.0) / 3.6
        self._lead_target_speed = self._get_param(op, "lead_vehicle_target_speed_kmh", 4.0) / 3.6
        self._lead_brake_delay = self._get_param(op, "lead_vehicle_brake_delay_s", 1.4)
        self._lead_brake_duration = self._get_param(op, "lead_vehicle_brake_duration_s", 1.6)
        self._lead_brake_force = self._get_param(op, "lead_vehicle_brake_force", 0.85)
        self._second_lead_speed = self._get_param(op, "second_lead_vehicle_speed_kmh", 22.0) / 3.6
        self._rear_speed = self._get_param(op, "rear_vehicle_speed_kmh", 104.0) / 3.6
        self._rear_brake_delay = self._get_param(op, "rear_vehicle_brake_delay_s", 99.0)
        self._rear_brake_force = self._get_param(op, "rear_vehicle_brake_force", 0.0)
        self._max_run_time = self._get_param(op, "max_run_time", 24.0)
        self._post_impact_hold = self._get_param(op, "post_impact_hold", 6.0)
        self._ego_speed_cap_kmh = self._get_param(op, "ego_speed_cap_kmh", 82.0)
        self._ego_cap_brake = self._get_param(op, "ego_cap_brake", 0.08)
        self._road_friction_scale = self._get_param(op, "road_friction_scale", 1.0)
        self._lead_model = str(self._get_param(op, "lead_vehicle_model", "vehicle.tesla.model3", cast=str))
        self._rear_model = str(self._get_param(op, "rear_vehicle_model", "vehicle.audi.tt", cast=str))

        self._trigger_wp = self._map.get_waypoint(config.trigger_points[0].location)
        self._lead_vehicle = None
        self._second_lead_vehicle = None
        self._rear_vehicle = None
        self._collision_sensor = None
        self._impact_detected = False

        super().__init__(
            name="RearVehicleBrakeFailure",
            ego_vehicles=ego_vehicles,
            config=config,
            world=world,
            debug_mode=debug_mode,
            terminate_on_failure=True,
            criteria_enable=criteria_enable,
        )

    def _initialize_environment(self, world):
        super()._initialize_environment(world)
        friction = max(0.1, float(self._road_friction_scale))
        if abs(friction - 1.0) < 1e-6:
            return
        bp = world.get_blueprint_library().find("static.trigger.friction")
        bp.set_attribute("friction", str(friction))
        bp.set_attribute("extent_x", "1000000.0")
        bp.set_attribute("extent_y", "1000000.0")
        bp.set_attribute("extent_z", "1000000.0")
        try:
            world.spawn_actor(bp, carla.Transform(carla.Location(-10000.0, -10000.0, 0.0)))
        except RuntimeError:
            pass

    @staticmethod
    def _walk_waypoint(waypoint, distance, forward=True):
        remaining = abs(float(distance))
        cursor = waypoint
        while remaining > 0.2 and cursor is not None:
            step = min(8.0, remaining)
            candidates = cursor.next(step) if forward else cursor.previous(step)
            if not candidates:
                break
            cursor = candidates[0]
            remaining -= step
        return cursor

    @staticmethod
    def _spawn_vehicle(model, transform, rolename, color=None):
        candidates = [model, "vehicle.tesla.model3", "vehicle.audi.tt", "vehicle.lincoln.mkz_2020"]
        for candidate in dict.fromkeys(candidates):
            actor = CarlaDataProvider.request_new_actor(
                candidate, transform, rolename=rolename, autopilot=False, color=color,
            )
            if actor is not None:
                return actor
        return None

    def _spawn_at_waypoint(self, waypoint, model, rolename, color=None):
        transform = carla.Transform(
            carla.Location(
                waypoint.transform.location.x,
                waypoint.transform.location.y,
                waypoint.transform.location.z + 0.5,
            ),
            waypoint.transform.rotation,
        )
        actor = self._spawn_vehicle(model, transform, rolename, color=color)
        if actor is not None:
            actor.set_simulate_physics(True)
            self.other_actors.append(actor)
        return actor

    def _attach_collision_sensor(self):
        bp = self._world.get_blueprint_library().find("sensor.other.collision")
        self._collision_sensor = self._world.spawn_actor(bp, carla.Transform(), attach_to=self._ego)
        self.other_actors.append(self._collision_sensor)

        def _on_collision(event):
            if event.other_actor is not None and event.other_actor.type_id.startswith("vehicle."):
                self._impact_detected = True

        self._collision_sensor.listen(_on_collision)

    def _initialize_actors(self, config):
        ego_wp = self._map.get_waypoint(
            self._ego.get_location(), project_to_road=True,
            lane_type=carla.LaneType.Driving,
        )
        lead_wp = self._walk_waypoint(ego_wp, self._lead_distance, forward=True) or ego_wp
        second_lead_wp = self._walk_waypoint(ego_wp, self._second_lead_distance, forward=True) or lead_wp
        rear_wp = self._walk_waypoint(ego_wp, self._rear_distance, forward=False) or ego_wp

        self._lead_vehicle = self._spawn_at_waypoint(
            lead_wp, self._lead_model, "sudden_slowdown_lead", color="120,120,120",
        )
        self._second_lead_vehicle = self._spawn_at_waypoint(
            second_lead_wp, "vehicle.tesla.model3", "traffic_queue_lead", color="80,80,80",
        )
        self._rear_vehicle = self._spawn_at_waypoint(
            rear_wp, self._rear_model, "fast_rear_vehicle", color="220,30,30",
        )
        if self._lead_vehicle is None or self._rear_vehicle is None:
            raise RuntimeError("[RearBrakeFailure] Required actor spawn failed")

        self._attach_collision_sensor()
        print(
            f"\n[RearBrakeFailure] Spawn\n"
            f"  Ego road={ego_wp.road_id} lane={ego_wp.lane_id}\n"
            f"  Lead ahead={self._lead_distance:.1f}m speed={self._lead_speed * 3.6:.1f} km/h\n"
            f"  Rear behind={self._rear_distance:.1f}m speed={self._rear_speed * 3.6:.1f} km/h\n"
            f"  brake_delay={self._lead_brake_delay:.1f}s brake={self._lead_brake_force:.2f}\n",
            flush=True,
        )

    def _setup_scenario_trigger(self, config):
        return InTriggerDistanceToLocation(
            self._ego,
            self._trigger_wp.transform.location,
            self._activation_distance,
            name="ActivateRearVehicleBrakeFailure",
        )

    def _lane_follow_control(self, actor, target_speed_mps, max_steer=0.26):
        control = carla.VehicleControl()
        if actor is None or not actor.is_alive:
            return control

        waypoint = self._map.get_waypoint(
            actor.get_location(), project_to_road=True,
            lane_type=carla.LaneType.Driving,
        )
        if waypoint is not None:
            actor_transform = actor.get_transform()
            wp_transform = waypoint.transform
            right = wp_transform.rotation.get_right_vector()
            delta = actor_transform.location - wp_transform.location
            lateral_error = delta.x * right.x + delta.y * right.y
            heading_error = (
                (actor_transform.rotation.yaw - wp_transform.rotation.yaw + 180.0) % 360.0 - 180.0
            ) / 90.0
            control.steer = _clamp((-0.45 * lateral_error) + (-0.95 * heading_error), -max_steer, max_steer)

        speed_error = max(0.0, target_speed_mps - _speed_mps(actor))
        overspeed = max(0.0, _speed_mps(actor) - target_speed_mps)
        control.throttle = _clamp(speed_error * 0.18, 0.0, 1.0)
        control.brake = _clamp(overspeed * 0.16, 0.0, 0.45)
        return control

    def _apply_support_controls(self, elapsed):
        if self._second_lead_vehicle is not None and self._second_lead_vehicle.is_alive:
            self._second_lead_vehicle.apply_control(
                self._lane_follow_control(self._second_lead_vehicle, self._second_lead_speed, max_steer=0.20)
            )

        if self._lead_vehicle is not None and self._lead_vehicle.is_alive:
            if elapsed < self._lead_brake_delay:
                lead_control = self._lane_follow_control(self._lead_vehicle, self._lead_speed, max_steer=0.22)
            elif elapsed < self._lead_brake_delay + self._lead_brake_duration:
                lead_control = self._lane_follow_control(self._lead_vehicle, 0.0, max_steer=0.20)
                lead_control.throttle = 0.0
                lead_control.brake = _clamp(self._lead_brake_force, 0.0, 1.0)
            else:
                lead_control = self._lane_follow_control(self._lead_vehicle, self._lead_target_speed, max_steer=0.18)
            self._lead_vehicle.apply_control(lead_control)

        # Rear vehicle uses set_target_velocity for reliable high speed
        if self._rear_vehicle is not None and self._rear_vehicle.is_alive:
            if elapsed >= self._rear_brake_delay and self._rear_brake_force > 0.0:
                # Emergency brake (rarely used — delay is 99s)
                self._rear_vehicle.apply_control(
                    carla.VehicleControl(throttle=0.0, brake=self._rear_brake_force, steer=0.0)
                )
            else:
                wp = self._map.get_waypoint(
                    self._rear_vehicle.get_location(), project_to_road=True,
                    lane_type=carla.LaneType.Driving,
                )
                if wp is not None:
                    fwd = wp.transform.rotation.get_forward_vector()
                    speed = self._rear_speed
                    rear_control = self._lane_follow_control(self._rear_vehicle, self._rear_speed, max_steer=0.24)
                    rear_control.throttle = max(rear_control.throttle, 0.45)
                    rear_control.brake = 0.0
                    self._rear_vehicle.apply_control(rear_control)
                    self._rear_vehicle.set_target_velocity(
                        carla.Vector3D(fwd.x * speed, fwd.y * speed, 0.0)
                    )

    def _freeze_controlled_traffic(self):
        stop = carla.VehicleControl(throttle=0.0, brake=1.0, steer=0.0, hand_brake=True)
        for actor in [self._lead_vehicle, self._second_lead_vehicle, self._rear_vehicle]:
            if actor is not None and actor.is_alive:
                try:
                    actor.apply_control(stop)
                except RuntimeError:
                    pass

    def _create_behavior(self):
        P = py_trees.common.ParallelPolicy
        sequence = py_trees.composites.Sequence("RearBrakeFailure_Root")
        sequence.add_child(_RunRearBrakeFailure(self))
        sequence.add_child(_PostImpactHold(self, self._post_impact_hold))
        cleanup = py_trees.composites.Sequence("Cleanup")
        cleanup.add_child(ActorDestroy(self._rear_vehicle, name="DestroyRear"))
        cleanup.add_child(ActorDestroy(self._lead_vehicle, name="DestroyLead"))
        if self._second_lead_vehicle is not None:
            cleanup.add_child(ActorDestroy(self._second_lead_vehicle, name="DestroySecondLead"))
        sequence.add_child(cleanup)

        outer = py_trees.composites.Parallel("RearBrakeFailure_Outer", policy=P.SUCCESS_ON_ONE)
        outer.add_child(sequence)
        outer.add_child(EgoSpeedGovernor(
            self._ego,
            speed_cap_kmh=self._ego_speed_cap_kmh,
            brake_force=self._ego_cap_brake,
            name="EgoSpeedGovernor",
        ))
        return outer

    def _create_test_criteria(self):
        return [CollisionTest(self._ego)]

    def __del__(self):
        try:
            if self._collision_sensor is not None and self._collision_sensor.is_alive:
                self._collision_sensor.stop()
                self._collision_sensor.destroy()
        except RuntimeError:
            pass
        self.remove_all_actors()

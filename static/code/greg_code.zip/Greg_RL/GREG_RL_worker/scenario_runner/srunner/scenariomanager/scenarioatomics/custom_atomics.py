"""
Local custom atomic behaviors for the custom scenario set.

This file is the repository-owned source of truth for the shared atomics used
by the scenarios in this workspace. The runner syncs it into ScenarioRunner's
``srunner.scenariomanager.scenarioatomics`` package before launch so the
scenario imports do not need to change.
"""

from __future__ import annotations

import math
import os
from typing import List, Optional

import carla
import py_trees

from srunner.scenariomanager.carla_data_provider import CarlaDataProvider
from srunner.scenariomanager.timer import GameTime


class StopActorsOnEgoCollision(py_trees.behaviour.Behaviour):
    """
    Monitor an ego vehicle collision sensor. On first impact, apply full brake
    plus hand brake to every actor in ``actors_to_stop`` and return SUCCESS.
    """

    def __init__(
        self,
        ego_vehicle: carla.Vehicle,
        actors_to_stop: List[Optional[carla.Vehicle]],
        name: str = "StopActorsOnEgoCollision",
    ):
        super().__init__(name)
        self._ego = ego_vehicle
        self._actors = actors_to_stop
        self._collision_sensor = None
        self._impact_detected = False

    def initialise(self):
        if self._collision_sensor is not None:
            return

        world = CarlaDataProvider.get_world()
        if world is None:
            return

        bp = world.get_blueprint_library().find("sensor.other.collision")
        self._collision_sensor = world.spawn_actor(
            bp, carla.Transform(), attach_to=self._ego,
        )
        self._collision_sensor.listen(self._on_collision)

    def _on_collision(self, event):
        del event
        self._impact_detected = True

    def update(self):
        if not self._impact_detected:
            return py_trees.common.Status.RUNNING

        stop_control = carla.VehicleControl()
        stop_control.throttle = 0.0
        stop_control.brake = 1.0
        stop_control.steer = 0.0
        stop_control.hand_brake = True

        for actor in self._actors:
            if actor is not None and actor.is_alive:
                try:
                    actor.apply_control(stop_control)
                except RuntimeError:
                    pass

        return py_trees.common.Status.SUCCESS

    def terminate(self, new_status):
        if self._collision_sensor is not None and self._collision_sensor.is_alive:
            try:
                self._collision_sensor.stop()
                self._collision_sensor.destroy()
            except RuntimeError:
                pass
            self._collision_sensor = None
        super().terminate(new_status)


class HoldUntilEgoMoves(py_trees.behaviour.Behaviour):
    """Hold an actor stationary until the ego produces non-zero velocity."""

    def __init__(self, actor, ego, speed_threshold=0.5, name="HoldUntilEgoMoves"):
        super().__init__(name)
        self._actor = actor
        self._ego = ego
        self._speed_threshold = speed_threshold

    def update(self):
        if self._actor is not None and self._actor.is_alive:
            ctrl = carla.VehicleControl()
            ctrl.brake = 1.0
            ctrl.hand_brake = True
            self._actor.apply_control(ctrl)

        if self._ego is not None and self._ego.is_alive:
            velocity = self._ego.get_velocity()
            speed = math.sqrt(velocity.x ** 2 + velocity.y ** 2 + velocity.z ** 2)
            if speed > self._speed_threshold:
                return py_trees.common.Status.SUCCESS

        return py_trees.common.Status.RUNNING


class WaitUntilAheadOfEgo(py_trees.behaviour.Behaviour):
    """Return SUCCESS when an actor is sufficiently ahead of the ego."""

    def __init__(self, actor, ego, ahead_distance=5.0, name="WaitUntilAheadOfEgo"):
        super().__init__(name)
        self._actor = actor
        self._ego = ego
        self._ahead_distance = ahead_distance

    def update(self):
        if self._ego is None or self._actor is None:
            return py_trees.common.Status.FAILURE
        if not self._ego.is_alive or not self._actor.is_alive:
            return py_trees.common.Status.FAILURE

        ego_transform = self._ego.get_transform()
        forward = ego_transform.rotation.get_forward_vector()
        delta = self._actor.get_location() - ego_transform.location
        projection = delta.x * forward.x + delta.y * forward.y + delta.z * forward.z

        if projection >= self._ahead_distance:
            return py_trees.common.Status.SUCCESS
        return py_trees.common.Status.RUNNING


class WaitForActorCollision(py_trees.behaviour.Behaviour):
    """Wait until a collision sensor attached to an actor fires."""

    def __init__(self, actor, name="WaitForActorCollision"):
        super().__init__(name)
        self._actor = actor
        self._sensor = None
        self._collided = False

    def initialise(self):
        world = CarlaDataProvider.get_world()
        if world is None:
            return
        bp = world.get_blueprint_library().find("sensor.other.collision")
        self._sensor = world.spawn_actor(bp, carla.Transform(), attach_to=self._actor)
        self._sensor.listen(lambda _: setattr(self, "_collided", True))

    def update(self):
        if self._collided:
            return py_trees.common.Status.SUCCESS
        return py_trees.common.Status.RUNNING

    def terminate(self, new_status):
        if self._sensor is not None and self._sensor.is_alive:
            try:
                self._sensor.stop()
                self._sensor.destroy()
            except RuntimeError:
                pass
        super().terminate(new_status)


class InSameDrivingLaneAsActor(py_trees.behaviour.Behaviour):
    """Return SUCCESS when actor is in the same driving lane as reference_actor."""

    def __init__(self, actor, reference_actor, name="InSameDrivingLaneAsActor"):
        super().__init__(name)
        self._actor = actor
        self._ref = reference_actor

    def update(self):
        if self._actor is None or self._ref is None:
            return py_trees.common.Status.FAILURE
        world_map = CarlaDataProvider.get_map()
        waypoint_a = world_map.get_waypoint(self._actor.get_location())
        waypoint_b = world_map.get_waypoint(self._ref.get_location())
        if waypoint_a is not None and waypoint_b is not None:
            if waypoint_a.road_id == waypoint_b.road_id and waypoint_a.lane_id == waypoint_b.lane_id:
                return py_trees.common.Status.SUCCESS
        return py_trees.common.Status.RUNNING


class ApplyControlContinuous(py_trees.behaviour.Behaviour):
    """Apply a fixed VehicleControl every tick and always keep RUNNING."""

    def __init__(self, actor, throttle=0.0, brake=0.0, steer=0.0,
                 hand_brake=False, name="ApplyControlContinuous"):
        super().__init__(name)
        self._actor = actor
        self._ctrl = carla.VehicleControl()
        self._ctrl.throttle = float(throttle)
        self._ctrl.brake = float(brake)
        self._ctrl.steer = max(-1.0, min(1.0, float(steer)))
        self._ctrl.hand_brake = bool(hand_brake)

    def update(self):
        if self._actor is not None and self._actor.is_alive:
            self._actor.apply_control(self._ctrl)
        return py_trees.common.Status.RUNNING


class ApplyControlForDuration(py_trees.behaviour.Behaviour):
    """Apply a fixed VehicleControl for a fixed duration, then return SUCCESS."""

    def __init__(self, actor, throttle=0.0, brake=0.0, steer=0.0,
                 hand_brake=False, duration=1.0, name="ApplyControlForDuration"):
        super().__init__(name)
        self._actor = actor
        self._ctrl = carla.VehicleControl()
        self._ctrl.throttle = float(throttle)
        self._ctrl.brake = float(brake)
        self._ctrl.steer = max(-1.0, min(1.0, float(steer)))
        self._ctrl.hand_brake = bool(hand_brake)
        self._duration = float(duration)
        self._start_time = None

    def initialise(self):
        self._start_time = GameTime.get_time()

    def update(self):
        if self._actor is not None and self._actor.is_alive:
            self._actor.apply_control(self._ctrl)
        elapsed = GameTime.get_time() - self._start_time if self._start_time else 0.0
        if elapsed >= self._duration:
            return py_trees.common.Status.SUCCESS
        return py_trees.common.Status.RUNNING


class PhysicsLossOfControlBreach(py_trees.behaviour.Behaviour):
    """Placeholder physics loss-of-control behavior used by adversarial breach."""

    def __init__(self, actor, duration=3.0, name="PhysicsLossOfControlBreach"):
        super().__init__(name)
        self._actor = actor
        self._duration = duration
        self._start_time = None

    def initialise(self):
        self._start_time = GameTime.get_time()

    def update(self):
        if self._actor is not None and not self._actor.is_alive:
            return py_trees.common.Status.SUCCESS
        elapsed = GameTime.get_time() - self._start_time if self._start_time else 0.0
        if elapsed >= self._duration:
            return py_trees.common.Status.SUCCESS
        return py_trees.common.Status.RUNNING


class AdversarialSpeedChaser(py_trees.behaviour.Behaviour):
    """Accelerate an actor toward a high target speed before a breach maneuver."""

    def __init__(self, actor, target_speed=30.0, name="AdversarialSpeedChaser"):
        super().__init__(name)
        self._actor = actor
        self._target_speed = float(target_speed)

    def update(self):
        if self._actor is None or not self._actor.is_alive:
            return py_trees.common.Status.FAILURE

        velocity = self._actor.get_velocity()
        speed = math.sqrt(velocity.x ** 2 + velocity.y ** 2 + velocity.z ** 2)

        ctrl = carla.VehicleControl()
        if speed < self._target_speed:
            ctrl.throttle = 0.8
            ctrl.brake = 0.0
        else:
            ctrl.throttle = 0.0
            ctrl.brake = 0.3
        self._actor.apply_control(ctrl)
        return py_trees.common.Status.RUNNING


class PeriodicStatusLogger(py_trees.behaviour.Behaviour):
    """Print periodic scenario status lines and always keep RUNNING."""

    def __init__(self, ego, adv=None, npc=None, interval=2.0, name="PeriodicStatusLogger"):
        super().__init__(name)
        self._ego = ego
        self._adv = adv
        self._npc = npc
        self._interval = interval
        self._last_log_time = None

    def update(self):
        now = GameTime.get_time()
        if self._last_log_time is None or (now - self._last_log_time) >= self._interval:
            self._last_log_time = now
            try:
                if self._ego and self._ego.is_alive:
                    velocity = self._ego.get_velocity()
                    speed_kmh = 3.6 * math.sqrt(velocity.x ** 2 + velocity.y ** 2 + velocity.z ** 2)
                    parts = [f"[StatusLog] t={now:.1f}s  ego_speed={speed_kmh:.1f} km/h"]
                    if self._adv and self._adv.is_alive:
                        adv_velocity = self._adv.get_velocity()
                        adv_speed = 3.6 * math.sqrt(
                            adv_velocity.x ** 2 + adv_velocity.y ** 2 + adv_velocity.z ** 2
                        )
                        parts.append(f"adv_speed={adv_speed:.1f}")
                    print("  ".join(parts), flush=True)
            except Exception:
                pass
        return py_trees.common.Status.RUNNING


class PanicDriverControl(py_trees.behaviour.Behaviour):
    """Delayed overcorrection loop used by the adversarial breach scenario."""

    def __init__(self, actor, duration=3.0, reaction_delay=0.3, gain=1.5,
                 yaw_rate_scale=90.0, name="PanicDriverControl"):
        super().__init__(name)
        self._actor = actor
        self._duration = float(duration)
        self._reaction_delay = float(reaction_delay)
        self._gain = float(gain)
        self._yaw_rate_scale = float(yaw_rate_scale)
        self._start_time = None
        self._last_yaw = None

    def initialise(self):
        self._start_time = GameTime.get_time()
        if self._actor and self._actor.is_alive:
            self._last_yaw = self._actor.get_transform().rotation.yaw

    def update(self):
        if self._actor is None or not self._actor.is_alive:
            return py_trees.common.Status.SUCCESS

        now = GameTime.get_time()
        elapsed = now - self._start_time if self._start_time else 0.0
        if elapsed >= self._duration:
            return py_trees.common.Status.SUCCESS

        current_yaw = self._actor.get_transform().rotation.yaw
        yaw_rate = 0.0
        if self._last_yaw is not None:
            delta = (current_yaw - self._last_yaw + 180.0) % 360.0 - 180.0
            yaw_rate = delta * 20.0
        self._last_yaw = current_yaw

        steer = 0.0
        if elapsed > self._reaction_delay:
            normalized = yaw_rate / self._yaw_rate_scale
            steer = -self._gain * normalized
            steer = max(-1.0, min(1.0, steer))

        ctrl = carla.VehicleControl()
        ctrl.throttle = 0.3
        ctrl.steer = steer
        self._actor.apply_control(ctrl)

        return py_trees.common.Status.RUNNING


class SpinOutControl(py_trees.behaviour.Behaviour):
    """Multi-phase spin-out maneuver used by the adversarial breach scenario."""

    def __init__(self, actor, steer_direction=1.0,
                 cut_in_steer=0.85, cut_in_throttle=0.25, cut_in_duration=0.5,
                 drift_steer=0.25, drift_steer_sign=-1.0,
                 drift_throttle=0.0, drift_brake=0.4, drift_duration=2.0,
                 spin_throttle=0.4, spin_duration=1.5,
                 block_duration=5.0,
                 name="SpinOutControl"):
        super().__init__(name)
        self._actor = actor
        self._dir = float(steer_direction)
        self._ci_steer = float(cut_in_steer)
        self._ci_throttle = float(cut_in_throttle)
        self._ci_dur = float(cut_in_duration)
        self._dr_steer = float(drift_steer)
        self._dr_sign = float(drift_steer_sign)
        self._dr_throttle = float(drift_throttle)
        self._dr_brake = float(drift_brake)
        self._dr_dur = float(drift_duration)
        self._sp_throttle = float(spin_throttle)
        self._sp_dur = float(spin_duration)
        self._bl_dur = float(block_duration)
        self._start_time = None

    def initialise(self):
        self._start_time = GameTime.get_time()

    @property
    def _total_duration(self):
        return self._ci_dur + self._dr_dur + self._sp_dur + self._bl_dur

    def update(self):
        if self._actor is None or not self._actor.is_alive:
            return py_trees.common.Status.SUCCESS

        elapsed = GameTime.get_time() - self._start_time if self._start_time else 0.0
        if elapsed >= self._total_duration:
            return py_trees.common.Status.SUCCESS

        ctrl = carla.VehicleControl()

        if elapsed < self._ci_dur:
            ctrl.steer = max(-1.0, min(1.0, self._dir * self._ci_steer))
            ctrl.throttle = self._ci_throttle
        elif elapsed < self._ci_dur + self._dr_dur:
            ctrl.steer = max(-1.0, min(1.0, self._dir * self._dr_sign * self._dr_steer))
            ctrl.throttle = self._dr_throttle
            ctrl.brake = self._dr_brake
        elif elapsed < self._ci_dur + self._dr_dur + self._sp_dur:
            ctrl.throttle = self._sp_throttle
        else:
            ctrl.hand_brake = True

        self._actor.apply_control(ctrl)
        return py_trees.common.Status.RUNNING


class LaneCleaner(py_trees.behaviour.Behaviour):
    """Destroy ambient vehicles in protected lanes around the scenario area."""

    def __init__(self, protected_actors, lane_waypoints, center_location,
                 radius=500.0, interval=1.0, name="LaneCleaner"):
        super().__init__(name)
        self._protected = set(actor.id for actor in protected_actors if actor is not None)
        self._lane_wps = lane_waypoints
        self._center = center_location
        self._radius = float(radius)
        self._interval = float(interval)
        self._last_clean = None

    def update(self):
        now = GameTime.get_time()
        if self._last_clean is not None and (now - self._last_clean) < self._interval:
            return py_trees.common.Status.RUNNING
        self._last_clean = now

        world = CarlaDataProvider.get_world()
        if world is None:
            return py_trees.common.Status.RUNNING

        world_map = CarlaDataProvider.get_map()
        to_destroy = []

        for actor in world.get_actors().filter("vehicle.*"):
            if actor.id in self._protected:
                continue
            location = actor.get_location()
            distance = math.sqrt(
                (location.x - self._center.x) ** 2 +
                (location.y - self._center.y) ** 2
            )
            if distance > self._radius:
                continue

            waypoint = world_map.get_waypoint(location)
            if waypoint is None:
                continue
            for lane_wp in self._lane_wps:
                if waypoint.road_id == lane_wp.road_id and waypoint.lane_id == lane_wp.lane_id:
                    to_destroy.append(actor)
                    break

        for actor in to_destroy:
            try:
                actor.destroy()
            except RuntimeError:
                pass

        return py_trees.common.Status.RUNNING


class EgoSpeedGovernor(py_trees.behaviour.Behaviour):
    """Apply gentle braking when ego exceeds the configured speed cap."""

    def __init__(self, ego, speed_cap_kmh=33.0, brake_force=0.2, name="EgoSpeedGovernor"):
        super().__init__(name)
        self._ego = ego
        self._cap_mps = float(speed_cap_kmh) / 3.6
        self._brake = float(brake_force)

    def update(self):
        if self._ego is None or not self._ego.is_alive:
            return py_trees.common.Status.RUNNING

        velocity = self._ego.get_velocity()
        speed = math.sqrt(velocity.x ** 2 + velocity.y ** 2 + velocity.z ** 2)
        if speed > self._cap_mps:
            ctrl = self._ego.get_control()
            ctrl.brake = self._brake
            ctrl.throttle = 0.0
            self._ego.apply_control(ctrl)

        return py_trees.common.Status.RUNNING
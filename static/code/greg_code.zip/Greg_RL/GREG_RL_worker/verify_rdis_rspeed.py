#!/usr/bin/env python
"""Verify Rdis (exact route progress) and Rspeed (one-sided desired-speed) against ground truth."""
import os, sys, math, types
import numpy as np

# ---------------------------------------------------------------- environment
HERE = os.path.dirname(os.path.abspath(__file__))
for p in (HERE, f"{HERE}/leaderboard", f"{HERE}/leaderboard/team_code",
          f"{HERE}/leaderboard/our_team", f"{HERE}/scenario_runner",
          f"{HERE}/scenario_runner/srunner/tests/carla_mocks"):
    if p not in sys.path:
        sys.path.insert(0, p)
os.environ.setdefault("SCENARIO_RUNNER_ROOT", f"{HERE}/scenario_runner")
os.environ.setdefault("LEADERBOARD_ROOT", f"{HERE}/leaderboard")

import torch
FAILS = []


def check(name, ok, detail=""):
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f"  -- {detail}" if detail else ""))
    if not ok:
        FAILS.append(name)


class FakeLoc:
    def __init__(self, x, y, z=0.0):
        self.x, self.y, self.z = float(x), float(y), float(z)


class FakeTransform:
    def __init__(self, x, y):
        self.location = FakeLoc(x, y)


class FakeVehicle:
    """Ground-truth ego pose, exactly what _exact_route_progress reads."""
    def __init__(self, x=0.0, y=0.0):
        self._t = FakeTransform(x, y)

    def set(self, x, y):
        self._t = FakeTransform(x, y)

    def get_transform(self):
        return self._t


class RoadOption:
    def __init__(self, value=4):
        self.value = value


print("\nA. RoutePlanner world-frame plumbing")
from team_code.planner import RoutePlanner

# A route heading +x, nodes every 5 m. The GPS frame is offset from the world frame by a large
# constant, the worst case for a failed lat_ref/lon_ref solve.
GPS_OFFSET = np.array([2773.0, -1041.0])
world_nodes = [np.array([5.0 * i, 0.0]) for i in range(20)]
global_plan_world = [(FakeTransform(*w), RoadOption()) for w in world_nodes]
global_plan_gps = [({"lat": 0.0, "lon": 0.0}, RoadOption()) for _ in world_nodes]

rp = RoutePlanner(4.0, 50.0)
# Bypass gps_to_location and inject the offset GPS-frame nodes directly, exactly as set_route
# would have built them.
rp.set_route(global_plan_gps, True, global_plan_world)
rp.route.clear()
for w, (tf, cmd) in zip(world_nodes, global_plan_world):
    rp.route.append((w + GPS_OFFSET, cmd, tf))

step = rp.run_step(np.array([0.0, 0.0]) + GPS_OFFSET)
check("run_step returns a 3-tuple when world coords supplied", len(step) == 3, f"len={len(step)}")
check("3rd element is the WORLD-frame transform",
      abs(step[2].location.x - 5.0) < 1e-9 and abs(step[2].location.y) < 1e-9,
      f"world wp = ({step[2].location.x}, {step[2].location.y})")
check("GPS-frame element still carries the offset (selection path unchanged)",
      abs(step[0][0] - (5.0 + GPS_OFFSET[0])) < 1e-6)

print("\nB. _exact_route_progress vs ground truth")
import importlib
agent_mod = importlib.import_module("our_team.Greg_worker")
GregAgent = getattr(agent_mod, agent_mod.get_entry_point())


class ProgStub:
    """Minimal carrier for the real _exact_route_progress method."""
    def __init__(self):
        self._exact_prog_ok = True
        self._vehicle = FakeVehicle(0.0, 0.0)
        self._cur_route_wp = None
        self._prev_route_wp = None
        self._prev_ego_xy = None
        self._exact_route_progress = types.MethodType(GregAgent._exact_route_progress, self)


def run_prog(ego_path, wp_path):
    """Feed a trajectory; return the per-frame progress the shipped method emits."""
    s = ProgStub()
    out = []
    for (ex, ey), wp in zip(ego_path, wp_path):
        s._vehicle.set(ex, ey)
        s._cur_route_wp = np.asarray(wp, dtype=np.float64)
        out.append(s._exact_route_progress())
    return out


WP = np.array([50.0, 0.0])
# parked at the origin
p = run_prog([(0, 0)] * 5, [WP] * 5)
check("parked -> progress exactly 0", all(v is not None and abs(v) < 1e-12 for v in p[1:]),
      f"{p[1:]}")
# cruising at 6 m/s on a 20 Hz sim = 0.30 m per frame, straight at the waypoint
path = [(0.30 * i, 0.0) for i in range(6)]
p = run_prog(path, [WP] * 6)
check("6 m/s toward wp -> 0.30 m/frame", all(abs(v - 0.30) < 1e-9 for v in p[1:]), f"{p[1:]}")
# reversing at 2 m/s = -0.10 m per frame
path = [(-0.10 * i, 0.0) for i in range(6)]
p = run_prog(path, [WP] * 6)
check("reversing -> negative progress", all(v < 0 for v in p[1:]), f"{p[1:]}")
# Perpendicular motion. Moving sideways off the route line INCREASES the distance to a fixed
# waypoint, so the correct answer is slightly negative and grows quadratically with the lateral
# offset -- it is not ~0. What must hold is that sideways travel earns a vanishing fraction of what
# the same speed earns pointed at the target, and is never rewarded.
path = [(0.0, 0.30 * i) for i in range(6)]
p = run_prog(path, [WP] * 6)
fwd = 0.30
check("perpendicular -> never positive", all(v <= 0 for v in p[1:]), f"{[round(v,5) for v in p[1:]]}")
check("perpendicular -> <5% of the forward magnitude at the same speed",
      all(abs(v) < 0.05 * fwd for v in p[1:]),
      f"max |prog| = {max(abs(v) for v in p[1:]):.5f} vs forward {fwd}")
# GNSS invariance: the method never touches GPS, so identical ego truth -> identical output
path = [(0.30 * i, 0.0) for i in range(6)]
p1 = run_prog(path, [WP] * 6)
p2 = run_prog(path, [WP + np.array([0.0, 0.0])] * 6)
check("output independent of the GPS frame (no GNSS term in the path)",
      all(abs(a - b) < 1e-12 for a, b in zip(p1[1:], p2[1:])))

print("\nC. waypoint-switch artefact")
# The planner pops at frame 3: the target jumps from 5 m ahead to 10 m ahead. Progress must stay
# smooth because each frame is scored against the target that was current at the START of it.
path = [(0.30 * i, 0.0) for i in range(7)]
wps = [np.array([5.0, 0.0])] * 3 + [np.array([10.0, 0.0])] * 4
p = run_prog(path, wps)
vals = [v for v in p[1:] if v is not None]
check("no spike at the waypoint switch", max(vals) - min(vals) < 1e-6,
      f"spread={max(vals) - min(vals):.2e}, vals={[round(v,4) for v in vals]}")

print("\nD. Rdis ramp")
Rdis_floor, Rdis_ref = 0.1, 0.6


def rdis(prog):
    return Rdis_floor + (1.0 - Rdis_floor) * min(max(prog / Rdis_ref, 0.0), 1.0)


check("parked -> Rdis == floor 0.100", abs(rdis(0.0) - 0.100) < 1e-12, f"{rdis(0.0):.4f}")
check("reversing -> Rdis == floor 0.100", abs(rdis(-0.10) - 0.100) < 1e-12, f"{rdis(-0.10):.4f}")
check("6 m/s -> Rdis ~ 0.55", abs(rdis(0.30) - 0.55) < 1e-9, f"{rdis(0.30):.4f}")
check("12 m/s -> Rdis saturates at 1.0", abs(rdis(0.60) - 1.0) < 1e-9, f"{rdis(0.60):.4f}")
print(f"     ramp: {[f'{v:.0f}m/s->{rdis(v*0.05):.3f}' for v in (0, 2, 4, 6, 8, 10, 12, 14)]}")

print("\nE. Rspeed one-sidedness")
sigma = 0.20


def rspeed_one_sided(v, vstar):
    return math.exp(-(max(0.0, v - vstar) / sigma) ** 2)


def rspeed_two_sided(v, vstar):
    return math.exp(-((v - vstar) / sigma) ** 2)


vstar = 0.5  # normalized = 6 m/s
below = [0.0, 0.1, 0.25, 0.4, 0.499, 0.5]
check("exactly 1.0 for every v <= v*", all(abs(rspeed_one_sided(v, vstar) - 1.0) < 1e-15 for v in below),
      f"{[round(rspeed_one_sided(v,vstar),6) for v in below]}")
above = [0.55, 0.6, 0.7, 0.9]
check("strictly decreasing above v*",
      all(rspeed_one_sided(a, vstar) > rspeed_one_sided(b, vstar) for a, b in zip(above, above[1:])),
      f"{[round(rspeed_one_sided(v,vstar),4) for v in above]}")
check("identical to the two-sided form on the over-speed side",
      all(abs(rspeed_one_sided(v, vstar) - rspeed_two_sided(v, vstar)) < 1e-12 for v in above))
check("over-speed guard still bites (v = 2*v* -> < 0.01)", rspeed_one_sided(1.0, vstar) < 0.01,
      f"{rspeed_one_sided(1.0, vstar):.5f}")
# a stopped car whose desired-speed oracle is wrong
check("stopped car with a wrong oracle (v*=6 m/s) is not annihilated",
      rspeed_one_sided(0.0, vstar) == 1.0 and rspeed_two_sided(0.0, vstar) < 1e-2,
      f"one_sided={rspeed_one_sided(0.0,vstar):.4f} vs two_sided={rspeed_two_sided(0.0,vstar):.2e}")

print("\nF. learner step reward  ((Rdis^2 * Rspeed * Rds)^(1/4) + Rtime) * 9")
RDS = 1.0  # lane-centering at its best case -- the most generous assumption for a stopped car


def step_reward(prog, v, vstar, rtime, one_sided, reverse=False):
    rd = rdis(prog)
    rsp = (rspeed_one_sided if one_sided else rspeed_two_sided)(v, vstar)
    if reverse:
        rsp = 0.0                      # the learner zeroes Rspeed when reversing
    return (((rd ** 2) * rsp * RDS) ** 0.25 + rtime) * 9.0


rows = [
    ("stopped, oracle WRONG (v*=6)", 0.0, 0.0, 0.5, False),
    ("stopped, oracle RIGHT (v*=0)", 0.0, 0.0, 0.0, False),
    ("crawling 1 m/s",               0.05, 1 / 12, 0.5, False),
    ("cruising 6 m/s at target",     0.30, 0.5, 0.5, False),
    ("speeding 12 m/s, v*=6",        0.60, 1.0, 0.5, False),
    ("reversing 2 m/s",              -0.10, -2 / 12, 0.5, True),
]
print(f"     {'case':<32} {'2sided(-0.1)':>14} {'1sided(-0.1)':>14} {'1sided(-0.280)':>16}")
for name, prog, v, vstar, rev in rows:
    o = step_reward(prog, v, vstar, -0.1, False, rev)
    n1 = step_reward(prog, v, vstar, -0.1, True, rev)
    n2 = step_reward(prog, v, vstar, -0.280, True, rev)
    print(f"     {name:<32} {o:>10.3f} {n1:>10.3f} {n2:>12.3f}")

# Solve for the Rtime that zeroes the worst-case stopped car (best-case Rds, wrong oracle).
geo_stopped = ((rdis(0.0) ** 2) * 1.0 * RDS) ** 0.25
rtime_star = -geo_stopped
print(f"\n     stopped-car geo-mean (Rdis=0.100, Rspeed=1.0, Rds=1.0) = {geo_stopped:.4f}")
print(f"     => Rtime that zeroes a stopped car = {rtime_star:.4f}")
check("Rtime = -0.280 puts a stopped car at ~0/step",
      abs(step_reward(0.0, 0.0, 0.5, -0.280, True)) < 0.35,
      f"{step_reward(0.0, 0.0, 0.5, -0.280, True):+.3f}/step")
check("with Rtime = -0.280 driving still strictly beats standing still",
      step_reward(0.30, 0.5, 0.5, -0.280, True) > step_reward(0.0, 0.0, 0.5, -0.280, True) + 3.0,
      f"cruise {step_reward(0.30,0.5,0.5,-0.280,True):+.3f} vs stopped "
      f"{step_reward(0.0,0.0,0.5,-0.280,True):+.3f}")
check("with Rtime = -0.280 reversing is strictly worse than standing still",
      step_reward(-0.10, -2 / 12, 0.5, -0.280, True, True)
      < step_reward(0.0, 0.0, 0.5, -0.280, True),
      f"reverse {step_reward(-0.10,-2/12,0.5,-0.280,True,True):+.3f}")
check("one-sided Rspeed WITHOUT the Rtime change would pay a stopped car (the trap)",
      step_reward(0.0, 0.0, 0.5, -0.1, True) > 1.0,
      f"{step_reward(0.0, 0.0, 0.5, -0.1, True):+.3f}/step -- this is why they ship together")

print("\n" + "=" * 70)
if FAILS:
    print(f"FAILED {len(FAILS)}:")
    for f in FAILS:
        print("   -", f)
    sys.exit(1)
print("ALL CHECKS PASSED")

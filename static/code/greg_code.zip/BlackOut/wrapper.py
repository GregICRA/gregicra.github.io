"""BlackOut: camera corruption for CARLA and HugSim.

No-op when GREG_BLACKOUT_LEVEL is unset; zero cost to call unconditionally.
"""
import hashlib
import os

import cv2
import numpy as np

from .corruptions.augment_rain_dirt import _build_dirt_layers, _apply_dirt_layers
from .family_select import DEFAULT_SEED, pick_family
from .presets import FAMILIES, LEVEL_ALIASES, FAMILY_PRESETS, apply_preset

_DIRT_FAMILIES = frozenset(f for f in FAMILIES if f.startswith("dirt_"))

CAM_KEYS = ("CAM_FRONT", "CAM_FRONT_LEFT", "CAM_FRONT_RIGHT",
            "CAM_BACK", "CAM_BACK_LEFT", "CAM_BACK_RIGHT")

_STATIC_FAMILIES = frozenset(FAMILIES) - {"rain"}

_LEVELS = ("none", "low", "high")


def _stable_int(*parts, nbytes=8):
    """Deterministic seed from arbitrary parts -- stable across processes/runs (unlike hash())."""
    digest = hashlib.sha256(":".join(str(p) for p in parts).encode("utf-8")).digest()
    return int.from_bytes(digest[:nbytes], "big")


def _to_uint8(img):
    if img is None:
        return None
    arr = np.asarray(img)
    if arr.dtype == np.uint8:
        return arr
    if arr.size and arr.max() <= 1.0:
        return (arr * 255).astype(np.uint8)
    return arr.astype(np.uint8)


def _is_totally_black(img_uint8, max_threshold=0):
    """Check if image is a missing-camera placeholder."""
    if img_uint8 is None or img_uint8.size == 0:
        return True
    return int(img_uint8.max()) <= int(max_threshold)


class BlackOut:
    def __init__(self, level="none", seed=DEFAULT_SEED, family=None):
        level = (level or "none").strip().lower()
        if level not in _LEVELS:
            raise ValueError(f"GREG_BLACKOUT_LEVEL must be one of {_LEVELS}, got {level!r}")
        if family is not None and family not in FAMILIES:
            raise ValueError(f"GREG_BLACKOUT_FAMILY must be one of {FAMILIES}, got {family!r}")
        self.level = level
        self.seed = seed
        self._family_override = family
        self._episode_key = None
        self._family = None
        self._frame_counter = {}
        self._dirt_cache = {}  # cam_id -> (mask, color, grime), see _DIRT_FAMILIES comment above

    @classmethod
    def from_env(cls):
        return cls(
            level=os.environ.get("GREG_BLACKOUT_LEVEL", "none"),
            seed=int(os.environ.get("GREG_BLACKOUT_SEED", DEFAULT_SEED)),
            family=os.environ.get("GREG_BLACKOUT_FAMILY") or None,
        )

    @property
    def enabled(self):
        return self.level != "none"

    def new_episode(self, key):
        """Reset per-episode state and pick corruption family for this route/scenario."""
        self._episode_key = key
        self._frame_counter = {}
        self._dirt_cache = {}
        if not self.enabled:
            self._family = None
            return
        self._family = self._family_override or pick_family(key, self.seed)
        print(f"[BlackOut] episode={key!r} level={self.level} family={self._family} "
              f"seed={self.seed}", flush=True)

    def _rng_for(self, cam_id):
        if self._family in _STATIC_FAMILIES:
            seed = _stable_int(self.seed, self._episode_key, cam_id, self._family)
        else:
            n = self._frame_counter.get(cam_id, 0) + 1
            self._frame_counter[cam_id] = n
            seed = _stable_int(self.seed, self._episode_key, cam_id, self._family, n)
        return np.random.default_rng(seed)

    def _corrupt_bgr(self, img_bgr, cam_id):
        if self._family in _DIRT_FAMILIES:
            return self._corrupt_dirt_cached(img_bgr, cam_id)
        rng = self._rng_for(cam_id)
        return apply_preset(img_bgr, rng, self._family, self.level)

    def _corrupt_dirt_cached(self, img_bgr, cam_id):
        level_key = LEVEL_ALIASES.get(self.level, self.level)
        kwargs = FAMILY_PRESETS[self._family][level_key]
        if cam_id not in self._dirt_cache:
            rng = self._rng_for(cam_id)  # static family -> deterministic per (episode, cam)
            h, w = img_bgr.shape[:2]
            self._dirt_cache[cam_id] = _build_dirt_layers(h, w, rng, **kwargs)
        mask, color, grime = self._dirt_cache[cam_id]
        return _apply_dirt_layers(img_bgr, mask, color, grime, **kwargs)

    def apply_carla(self, input_data):
        """CARLA leaderboard sensor dict: cam_id -> (frame_number, HxWx4 BGRA uint8 array)."""
        if not self.enabled:
            return input_data
        out = dict(input_data)
        for cam_id in CAM_KEYS:
            if cam_id not in out:
                continue
            frame_no, arr = out[cam_id]
            bgr = arr[:, :, :3]
            if _is_totally_black(bgr):
                continue
            corrupted = self._corrupt_bgr(bgr, cam_id)
            new_arr = arr.copy()
            new_arr[:, :, :3] = corrupted
            out[cam_id] = (frame_no, new_arr)
        return out

    def apply_views(self, views):
        """HugSim obs['rgb'] dict: cam_id -> HxWx3 RGB array (uint8 or float [0,1]), or missing/None."""
        if not self.enabled:
            return views
        out = dict(views)
        for cam_id in CAM_KEYS:
            img = out.get(cam_id)
            img_u8 = _to_uint8(img)
            if _is_totally_black(img_u8):
                continue  # missing-camera placeholder -- leave it alone, don't fake "presence"
            bgr = cv2.cvtColor(img_u8, cv2.COLOR_RGB2BGR)
            corrupted_bgr = self._corrupt_bgr(bgr, cam_id)
            out[cam_id] = cv2.cvtColor(corrupted_bgr, cv2.COLOR_BGR2RGB)
        return out

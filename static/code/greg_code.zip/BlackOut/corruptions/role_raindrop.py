"""Photorealistic raindrops-on-lens using ROLE model (Chia-Tse Chang).

Teardrop drops with refracted, inverted background and soft meniscus halo.
Public API: generate_drops(img_bgr, rng, ...) -> BGR uint8 array.
Raindrop corruption used by the BlackOut robustness benchmark.
"""
import math
import numpy as np
import cv2


class Raindrop:
    """Teardrop drop with alpha map and refracted texture."""

    def __init__(self, radius, shape="default"):
        self.radius = int(radius)
        self.shape = shape
        R = self.radius
        # label/alpha canvas is 4R wide x 5R tall, drop centred at (2R, 3R)
        self.labelmap = np.zeros((R * 5, R * 4), dtype=np.uint8)
        self._create_default_drop()
        self.texture = None

    def _create_default_drop(self):
        R = self.radius
        # circle body + downward ellipse -> teardrop, value 128 like the original
        cv2.circle(self.labelmap, (R * 2, R * 3), R, 128, -1)
        if self.shape == "egg":
            # Evocargo "egg": narrower + taller lower lobe -> elongated drop
            cv2.ellipse(self.labelmap, (R * 2, R * 3),
                        (int(0.8 * R), int(1.8 * R)), 0, 180, 360, 128, -1)
        else:
            cv2.ellipse(self.labelmap, (R * 2, R * 3),
                        (R, int(1.3 * math.sqrt(3) * R)), 0, 180, 360, 128, -1)
        # soft alpha (pyblur.GaussianBlur(.,10) -> cv2 with a comparable sigma)
        a = cv2.GaussianBlur(self.labelmap.astype(np.float32), (0, 0), sigmaX=10)
        self.alphamap = a / a.max() * 255.0           # 0..255 soft teardrop
        self.labelmap = (self.labelmap > 0).astype(np.uint8)

    def update_texture(self, bg):
        """Refract a background patch (5R x 4R, BGR) into the drop."""
        R = self.radius
        fg = cv2.GaussianBlur(bg, (0, 0), sigmaX=5)
        # fish-eye lens model from ROLE: anisotropic K, cubic-root radius zoom
        K = np.array([[30 * R, 0, 2 * R],
                      [0, 20 * R, 3 * R],
                      [0, 0, 1]], dtype=np.float64)
        D = np.zeros(4, dtype=np.float64)
        Knew = K.copy()
        Knew[(0, 1), (0, 1)] = math.pow(R, 1.0 / 3) * 2 * Knew[(0, 1), (0, 1)]
        fisheye = cv2.fisheye.undistortImage(fg, K, D=D, Knew=Knew)
        # a real drop inverts the scene vertically
        self.texture = cv2.flip(fisheye, 0)


def generate_drops(img_bgr, rng, n_drops=60, min_r=14, max_r=42,
                   edge_ratio=0.5, shape="default"):
    """Render raindrops on the lens over a BGR uint8 image."""
    h, w = img_bgr.shape[:2]
    pad = int(max_r * 3) + 2                     # so every drop's ROI is valid
    bgp = cv2.copyMakeBorder(img_bgr, pad, pad, pad, pad,
                             cv2.BORDER_REFLECT)
    outp = bgp.astype(np.float32).copy()

    for _ in range(n_drops):
        R = int(rng.integers(min_r, max_r + 1))
        ix = int(rng.integers(0, w)) + pad
        iy = int(rng.integers(0, h)) + pad

        y0, y1 = iy - 3 * R, iy + 2 * R          # 5R tall
        x0, x1 = ix - 2 * R, ix + 2 * R          # 4R wide
        roi = bgp[y0:y1, x0:x1]
        if roi.shape[0] != 5 * R or roi.shape[1] != 4 * R:
            continue

        drop = Raindrop(R, shape=shape)
        drop.update_texture(roi)
        drop_rgb = drop.texture.astype(np.float32)
        a = (drop.alphamap / 255.0)[..., None]   # soft teardrop alpha 0..1

        dst = outp[y0:y1, x0:x1]
        # 1) dark meniscus halo (uses alpha^2 so it shows mostly at the edge)
        a_edge = a * a
        dst[...] = dst * (1 - a_edge) + (drop_rgb * edge_ratio) * a_edge
        # 2) the refracted, fish-eyed, flipped drop body on top
        dst[...] = dst * (1 - a) + drop_rgb * a

    out = outp[pad:pad + h, pad:pad + w]
    return np.clip(out, 0, 255).astype(np.uint8)

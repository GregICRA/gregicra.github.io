"""Synthetic rain and lens-dirt corruptions (rain, droplets, dust, mud, smudge, extreme).

Each family: {base, high} intensity levels via add_rain/add_dirt/add_lens_droplets.
No CARLA dependency; operates on HxWx3 uint8 BGR frames.
Camera-corruption augmentations used by the BlackOut robustness benchmark.
"""
import sys
import os
import numpy as np
import cv2

from .role_raindrop import generate_drops as _role_generate_drops

SEED = 42


def add_rain(img, rng, n_drops=900, slant=-8, drop_len=22, blur=5,
             haze=0.18, desat=0.25):
    """Overlay motion-blurred rain streaks plus a cool, hazy atmosphere."""
    h, w = img.shape[:2]
    rain_layer = np.zeros((h, w), dtype=np.uint8)

    for _ in range(n_drops):
        x = rng.integers(0, w)
        y = rng.integers(0, h)
        length = rng.integers(drop_len // 2, drop_len)
        x2 = int(x + slant * length / drop_len)
        y2 = int(y + length)
        cv2.line(rain_layer, (x, y), (x2, y2), color=200, thickness=1)

    # motion blur along the fall direction to make streaks
    k = max(3, blur)
    kernel = np.zeros((k, k), dtype=np.float32)
    kernel[:, k // 2] = 1.0 / k
    rain_layer = cv2.filter2D(rain_layer, -1, kernel)
    rain_layer = cv2.GaussianBlur(rain_layer, (3, 3), 0)

    out = img.astype(np.float32)

    # cool the scene and lower contrast/saturation (wet, overcast look)
    hsv = cv2.cvtColor(out.astype(np.uint8), cv2.COLOR_BGR2HSV).astype(np.float32)
    hsv[..., 1] *= (1.0 - desat)
    out = cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2BGR).astype(np.float32)

    # bluish haze layer blended on top
    haze_color = np.array([180, 170, 160], dtype=np.float32)  # BGR, slightly cool
    out = out * (1 - haze) + haze_color * haze

    # add the bright rain streaks (additive, slightly blue tint)
    streak = rain_layer.astype(np.float32)[..., None] * np.array([1.05, 1.0, 0.95])
    out = out + streak * 0.9

    return np.clip(out, 0, 255).astype(np.uint8)


def _value_noise(h, w, rng, octaves=5, persistence=0.55, base=3):
    """Fractal value noise in [0, 1]."""
    noise = np.zeros((h, w), dtype=np.float32)
    amp, total = 1.0, 0.0
    for o in range(octaves):
        s = base * (2 ** o)
        grid = rng.random((max(2, s), max(2, s))).astype(np.float32)
        noise += cv2.resize(grid, (w, h), interpolation=cv2.INTER_CUBIC) * amp
        total += amp
        amp *= persistence
    return np.clip(noise / total, 0.0, 1.0)


def _organic_blob(ph, pw, cx, cy, r, rng, roughness=0.95, falloff_power=1.4):
    """Soft, textured blob mask with noise-warped boundary and mottled interior."""
    ys, xs = np.mgrid[0:ph, 0:pw].astype(np.float32)
    d = np.sqrt((xs - cx) ** 2 + (ys - cy) ** 2) / max(1.0, r)
    warp = _value_noise(ph, pw, rng, octaves=3, base=2)
    d = d * (1.0 + (warp - 0.5) * roughness)               # ragged boundary
    m = np.clip(1.0 - d, 0.0, 1.0) ** falloff_power
    tex = 0.4 + 0.6 * _value_noise(ph, pw, rng, octaves=4, base=5)
    return m * tex                                          # mottled interior


def _build_dirt_layers(h, w, rng, n_blobs=160, max_radius=90, strength=0.95,
                       grit_density=0.985, streak_prob=0.4, min_opacity=0.45,
                       spray=True, n_spots=0, **_ignored):
    """Build dirt geometry (cached per episode/camera for performance)."""
    mask = np.zeros((h, w), dtype=np.float32)      # 0..1 opacity of dirt
    color = np.zeros((h, w, 3), dtype=np.float32)  # dirt color per pixel (BGR)

    def composite(cx, cy, r, opacity, dirt_bgr, roughness=0.95, fp=1.4):
        """Stamp one organic blob into the global mask/color (max-blend)."""
        cx, cy, r = int(cx), int(cy), max(2, int(r))
        R = int(r * 1.9) + 4
        x0, x1 = max(0, cx - R), min(w, cx + R)
        y0, y1 = max(0, cy - R), min(h, cy + R)
        if x1 <= x0 or y1 <= y0:
            return
        m = _organic_blob(y1 - y0, x1 - x0, cx - x0, cy - y0, r,
                          rng, roughness, fp) * opacity
        sm = mask[y0:y1, x0:x1]
        upd = m > sm
        sm[upd] = m[upd]
        sc = color[y0:y1, x0:x1]
        for c in range(3):
            sc[..., c][upd] = dirt_bgr[c]

    for _ in range(n_blobs):
        # ~half land anywhere (center included) so the view is genuinely
        # obstructed, not just vignetted at the edges
        if rng.random() < 0.45:
            cx = int(rng.choice([rng.integers(0, w // 3),
                                 rng.integers(2 * w // 3, w)]))
            cy = int(rng.choice([rng.integers(0, h // 3),
                                 rng.integers(2 * h // 3, h)]))
        else:
            cx = int(rng.integers(0, w))
            cy = int(rng.integers(0, h))

        r = int(rng.integers(8, max_radius))
        opacity = float(rng.uniform(min_opacity, strength))

        # muddy brown / grey-brown tones (BGR)
        base = rng.uniform(30, 100)
        dirt_bgr = np.array([base * 0.8, base * 0.9, base * 1.0]) + rng.uniform(-12, 12, 3)

        composite(cx, cy, r, opacity, dirt_bgr)

        # directional spray: specks thrown along one axis, like flung mud
        if spray:
            ang = rng.uniform(0, 2 * np.pi)
            dx, dy = np.cos(ang), np.sin(ang)
            for _ in range(int(rng.integers(4, 13))):
                dist = rng.uniform(0.5, 3.2) * r
                jx = cx + dx * dist + rng.uniform(-r, r)
                jy = cy + dy * dist + rng.uniform(-r, r)
                rr = max(2, int(r * rng.uniform(0.08, 0.38)))
                composite(jx, jy, rr, opacity * rng.uniform(0.5, 1.0),
                          dirt_bgr, roughness=1.15, fp=1.2)

        # wiped streak: blob dragged along a direction, tapering off
        if rng.random() < streak_prob:
            ang = rng.uniform(0, 2 * np.pi)
            dx, dy = np.cos(ang), np.sin(ang)
            steps = int(rng.integers(4, 9))
            for k in range(steps):
                t = k / steps
                composite(cx + dx * r * 3 * t, cy + dy * r * 3 * t,
                          max(2, int(r * (1 - t * 0.6))),
                          opacity * (1 - t * 0.7), dirt_bgr,
                          roughness=1.2, fp=1.1)

    # dried water-spot rings: translucent core, darker mottled rim
    for _ in range(n_spots):
        cx = int(rng.integers(0, w))
        cy = int(rng.integers(0, h))
        r = int(rng.integers(6, 34))
        ring = np.zeros((h, w), dtype=np.float32)
        cv2.circle(ring, (cx, cy), r, 1.0, max(1, r // 5))
        cv2.circle(ring, (cx, cy), r, 0.3, -1)            # faint fill
        ring = cv2.GaussianBlur(ring, (0, 0), sigmaX=1.3)
        ring *= rng.uniform(0.35, 0.7)
        upd = ring > mask
        mask = np.where(upd, ring, mask)
        spot_bgr = np.array([150.0, 158.0, 165.0])
        for c in range(3):
            color[..., c] = np.where(upd, spot_bgr[c], color[..., c])

    # dense fine grit spread everywhere
    grit = (rng.random((h, w)) > grit_density).astype(np.float32) * rng.uniform(0.4, 0.9)
    grit = cv2.GaussianBlur(grit, (0, 0), sigmaX=1.2)
    g_upd = grit > mask
    mask = np.where(g_upd, grit, mask)
    grit_bgr = np.array([70.0, 80.0, 90.0])
    for c in range(3):
        color[..., c] = np.where(g_upd, grit_bgr[c], color[..., c])

    mask = np.clip(mask, 0, 1)[..., None]
    grime = _value_noise(h, w, rng, octaves=5, base=3)        # 0..1 filth map, layer 1 below
    return mask, color, grime


def _apply_dirt_layers(img, mask, color, grime, film=0.35, smear_blur=11, contrast_crush=0.25,
                       veil_bgr=(150.0, 155.0, 160.0), color_mix=0.55, **_ignored):
    """Blend cached dirt geometry onto current frame."""
    out = img.astype(np.float32)

    # --- layer 1: UNEVEN grime film (some regions far filthier than others) ---
    grime_w = (0.35 + 0.65 * grime)[..., None]
    veil = np.array(veil_bgr, dtype=np.float32)
    mean = out.mean(axis=(0, 1), keepdims=True)
    out = out * (1 - contrast_crush) + mean * contrast_crush  # crush contrast
    film_map = film * grime_w
    out = out * (1 - film_map) + veil * film_map              # patchy film

    # --- layer 2: smears heavily blur AND tint what is behind them ---
    heavy_blur = cv2.GaussianBlur(out.astype(np.uint8), (0, 0),
                                  sigmaX=smear_blur).astype(np.float32)
    dirt_pixels = heavy_blur * (1 - color_mix) + color * color_mix
    out = out * (1 - mask) + dirt_pixels * mask

    return np.clip(out, 0, 255).astype(np.uint8)


def add_dirt(img, rng, n_blobs=160, max_radius=90, strength=0.95,
             film=0.35, smear_blur=11, contrast_crush=0.25,
             veil_bgr=(150.0, 155.0, 160.0), grit_density=0.985,
             color_mix=0.55, streak_prob=0.4, min_opacity=0.45,
             spray=True, n_spots=0):
    """Lens dirt with uneven grime film, smears, and optional water-spot rings."""
    h, w = img.shape[:2]
    mask, color, grime = _build_dirt_layers(
        h, w, rng, n_blobs=n_blobs, max_radius=max_radius, strength=strength,
        grit_density=grit_density, streak_prob=streak_prob, min_opacity=min_opacity,
        spray=spray, n_spots=n_spots)
    return _apply_dirt_layers(img, mask, color, grime, film=film, smear_blur=smear_blur,
                              contrast_crush=contrast_crush, veil_bgr=veil_bgr, color_mix=color_mix)


def add_lens_droplets(img, rng, n_drops=60, min_radius=16, max_radius=44,
                      edge_ratio=0.5):
    """Simulate rain *droplets sitting on the lens* (water clinging to the camera).

    Delegates to the vendored ROLE model (see role_raindrop.py): each drop is a
    teardrop whose interior shows the background refracted through a fish-eye
    lens and flipped vertically, ringed by a soft dark meniscus. This is the
    photorealistic path; unlike add_rain (falling streaks), the water is on the
    camera itself. Tune density with n_drops and size with min/max_radius.
    """
    return _role_generate_drops(img, rng, n_drops=n_drops, min_r=min_radius,
                                max_r=max_radius, edge_ratio=edge_ratio)



RAIN_LEVELS = {
    "base": dict(n_drops=1400, slant=-9, drop_len=26, blur=6,
                 haze=0.30, desat=0.38),
    "high": dict(n_drops=3200, slant=-12, drop_len=38, blur=9,
                 haze=0.52, desat=0.58),
}

DROPLET_LEVELS = {
    "base": dict(n_drops=70, min_radius=16, max_radius=46, edge_ratio=0.5),
    "high": dict(n_drops=180, min_radius=12, max_radius=40, edge_ratio=0.6),
}

# distinct dirt styles, each with a base and a heavier "high" preset.
# "extreme" is its own family (caked filth); its base is already severe and
# its high nearly blacks the view out.
DIRT_STYLES = {
    "dust": {            # dried dusty film + water spots, uneven haze
        "base": dict(
            n_blobs=140, max_radius=72, strength=0.80, min_opacity=0.30,
            film=0.52, contrast_crush=0.35, smear_blur=9, grit_density=0.95,
            streak_prob=0.2, color_mix=0.42, spray=False, n_spots=50,
            veil_bgr=(168.0, 178.0, 188.0)),
        "high": dict(
            n_blobs=240, max_radius=95, strength=0.95, min_opacity=0.50,
            film=0.68, contrast_crush=0.46, smear_blur=13, grit_density=0.92,
            streak_prob=0.35, color_mix=0.55, spray=False, n_spots=95,
            veil_bgr=(172.0, 182.0, 192.0)),
    },
    "mud": {             # flung brown mud, dense spray, opaque cores
        "base": dict(
            n_blobs=200, max_radius=100, strength=1.0, min_opacity=0.60,
            film=0.30, contrast_crush=0.25, smear_blur=11, grit_density=0.975,
            streak_prob=0.35, color_mix=0.80, spray=True, n_spots=10,
            veil_bgr=(80.0, 100.0, 122.0)),
        "high": dict(
            n_blobs=340, max_radius=125, strength=1.0, min_opacity=0.74,
            film=0.46, contrast_crush=0.36, smear_blur=15, grit_density=0.955,
            streak_prob=0.50, color_mix=0.88, spray=True, n_spots=22,
            veil_bgr=(70.0, 90.0, 112.0)),
    },
    "smudge": {          # greasy wipe smears, long streaks, very blurry
        "base": dict(
            n_blobs=110, max_radius=130, strength=0.85, min_opacity=0.35,
            film=0.40, contrast_crush=0.40, smear_blur=25, grit_density=0.99,
            streak_prob=0.85, color_mix=0.32, spray=False, n_spots=20,
            veil_bgr=(148.0, 153.0, 158.0)),
        "high": dict(
            n_blobs=175, max_radius=165, strength=0.95, min_opacity=0.50,
            film=0.55, contrast_crush=0.50, smear_blur=37, grit_density=0.985,
            streak_prob=0.95, color_mix=0.42, spray=False, n_spots=30,
            veil_bgr=(150.0, 155.0, 160.0)),
    },
    "extreme": {         # caked-on filth, view almost fully obstructed
        "base": dict(
            n_blobs=300, max_radius=120, strength=1.0, min_opacity=0.68,
            film=0.60, contrast_crush=0.40, smear_blur=17, grit_density=0.96,
            streak_prob=0.50, color_mix=0.65, spray=True, n_spots=30,
            veil_bgr=(135.0, 146.0, 155.0)),
        "high": dict(
            n_blobs=470, max_radius=155, strength=1.0, min_opacity=0.84,
            film=0.76, contrast_crush=0.52, smear_blur=23, grit_density=0.94,
            streak_prob=0.60, color_mix=0.76, spray=True, n_spots=46,
            veil_bgr=(130.0, 140.0, 150.0)),
    },
}


def main():
    """Standalone: generate all corruption variants for inspection."""
    default_in = os.environ.get(
        "BLACKOUT_SAMPLE_IMAGE",
        "./sample/Accident_Town06_Route280_Weather11/camera/rgb_front/00006.jpg")
    in_path = sys.argv[1] if len(sys.argv) > 1 else default_in
    out_dir = sys.argv[2] if len(sys.argv) > 2 else os.path.dirname(os.path.abspath(__file__))

    img = cv2.imread(in_path)
    if img is None:
        raise SystemExit(f"Could not read image: {in_path}")

    stem = os.path.splitext(os.path.basename(in_path))[0]
    outputs = {}

    for j, (lvl, kw) in enumerate(RAIN_LEVELS.items()):
        outputs[f"{stem}_rain_{lvl}.png"] = add_rain(
            img, np.random.default_rng(SEED + j), **kw)

    for j, (lvl, kw) in enumerate(DROPLET_LEVELS.items()):
        outputs[f"{stem}_droplets_{lvl}.png"] = add_lens_droplets(
            img, np.random.default_rng(SEED + 10 + j), **kw)

    for i, (name, levels) in enumerate(DIRT_STYLES.items()):
        for j, (lvl, kw) in enumerate(levels.items()):
            outputs[f"{stem}_dirt_{name}_{lvl}.png"] = add_dirt(
                img, np.random.default_rng(SEED + 100 + i * 2 + j), **kw)

    for name, im in outputs.items():
        p = os.path.join(out_dir, name)
        cv2.imwrite(p, im)
        print("saved", p)


if __name__ == "__main__":
    main()
